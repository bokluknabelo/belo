from __future__ import annotations

from dataclasses import dataclass
import random


@dataclass
class FaultProfile:
    loss: float = 0.0
    corruption: float = 0.0
    duplication: float = 0.0
    delay_steps: int = 0
    drop_ack: bool = False
    seed: int = 1


class DeterministicFaultLink:
    def __init__(self, profile: FaultProfile):
        self.profile = profile
        self.random = random.Random(profile.seed)
        self.delayed: list[tuple[int, bytes]] = []
        self.step = 0

    def transmit(self, frame: bytes, is_ack: bool = False) -> list[bytes]:
        self.step += 1
        ready = [value for due, value in self.delayed if due <= self.step]
        self.delayed = [(due, value) for due, value in self.delayed if due > self.step]
        if is_ack and self.profile.drop_ack:
            return ready
        if self.random.random() < self.profile.loss:
            return ready
        value = frame
        if value and self.random.random() < self.profile.corruption:
            at = self.random.randrange(len(value))
            value = value[:at] + bytes([value[at] ^ 0x01]) + value[at + 1:]
        copies = 2 if self.random.random() < self.profile.duplication else 1
        for _ in range(copies):
            if self.profile.delay_steps:
                self.delayed.append((self.step + self.profile.delay_steps, value))
            else:
                ready.append(value)
        return ready

    def flush(self) -> list[bytes]:
        values = [value for _, value in sorted(self.delayed)]
        self.delayed.clear()
        return values
