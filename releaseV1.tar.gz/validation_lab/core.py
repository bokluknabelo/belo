from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Iterable
import importlib.util
import json
import sys
import time

from .model import Event, Finding, RunResult, Status


Validator = Callable[["LabContext"], Iterable[Finding] | Finding | None]


@dataclass
class Plugin:
    key: str
    title: str
    description: str
    validator: Validator


class Registry:
    def __init__(self) -> None:
        self._plugins: dict[str, Plugin] = {}

    def register(self, key: str, title: str, description: str = ""):
        def decorator(func: Validator) -> Validator:
            if key in self._plugins:
                raise ValueError(f"Duplicate validator key: {key}")
            self._plugins[key] = Plugin(key, title, description, func)
            return func
        return decorator

    def get(self, key: str) -> Plugin:
        return self._plugins[key]

    def all(self) -> list[Plugin]:
        return list(self._plugins.values())


registry = Registry()


def discover_plugins(root: Path) -> list[str]:
    loaded = []
    directory = root / "validation_plugins"
    if not directory.is_dir():
        return loaded
    for path in sorted(directory.glob("*.py")):
        if path.name.startswith("_"):
            continue
        name = f"relay_validation_plugin_{path.stem}"
        spec = importlib.util.spec_from_file_location(name, path)
        if spec and spec.loader:
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            loaded.append(path.name)
    return loaded


class EventBus:
    def __init__(self) -> None:
        self.events: list[Event] = []
        self.listeners: list[Callable[[Event], None]] = []

    def emit(self, event: Event) -> None:
        self.events.append(event)
        for listener in tuple(self.listeners):
            listener(event)


class LabContext:
    def __init__(self, root: Path):
        self.root = root.resolve()
        self.data_dir = self.root / ".validation_lab"
        self.sessions_dir = self.data_dir / "sessions"
        self.golden_dir = self.data_dir / "golden"
        self.reports_dir = self.data_dir / "reports"
        for path in (self.sessions_dir, self.golden_dir, self.reports_dir):
            path.mkdir(parents=True, exist_ok=True)
        self.bus = EventBus()
        self.last_result: RunResult | None = None
        self.options: dict[str, object] = {}

    def emit(self, subsystem: str, **kwargs) -> None:
        self.bus.emit(Event.now(subsystem, **kwargs))

    def source(self, relative: str) -> str:
        return (self.root / relative).read_text(encoding="utf-8", errors="replace")

    def save_session(self, result: RunResult) -> Path:
        path = self.sessions_dir / f"{result.run_id}.json"
        payload = {
            "name": result.name, "run_id": result.run_id,
            "status": result.status.value, "started_ns": result.started_ns,
            "finished_ns": result.finished_ns,
            "findings": [vars(f) | {"status": f.status.value} for f in result.findings],
            "events": [event.as_dict() for event in result.events],
        }
        path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        return path


class Runner:
    def __init__(self, context: LabContext):
        self.context = context

    def run(self, keys: list[str], name: str) -> RunResult:
        result = RunResult(name)
        event_start = len(self.context.bus.events)
        for key in keys:
            plugin = registry.get(key)
            started = time.perf_counter_ns()
            self.context.emit("validator", function=key, state="STARTED", result=plugin.title)
            trace_count = 0
            production_names = {"relserver3.py", "protocol.py", "packet_router.py"}
            def profile(frame, action, arg):
                nonlocal trace_count
                if action not in ("call", "return") or trace_count >= 20000:
                    return
                path = Path(frame.f_code.co_filename)
                if path.name not in production_names:
                    return
                trace_count += 1
                self.context.emit("execution", function=frame.f_code.co_name,
                                  state=action.upper(), result=path.name,
                                  metadata={"line": frame.f_lineno})
            try:
                sys.setprofile(profile)
                produced = plugin.validator(self.context)
                if produced is None:
                    findings = []
                elif isinstance(produced, Finding):
                    findings = [produced]
                else:
                    findings = list(produced)
                if not findings:
                    findings = [Finding(key, Status.PASS, f"{plugin.title} completed")]
            except Exception as exc:
                findings = [Finding(key, Status.FAIL, f"{type(exc).__name__}: {exc}",
                                    recommendation="Inspect the validator event trace")]
            finally:
                sys.setprofile(None)
            elapsed = (time.perf_counter_ns() - started) / 1_000_000
            for finding in findings:
                finding.duration_ms = elapsed
                result.findings.append(finding)
                self.context.emit("validator", function=key, state="FINISHED",
                                  result=finding.summary, severity=finding.status.value)
        result.events = self.context.bus.events[event_start:]
        result.finish()
        self.context.last_result = result
        self.context.save_session(result)
        return result
