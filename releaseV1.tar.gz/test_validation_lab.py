from pathlib import Path

from validation_lab import plugins  # noqa: F401
from validation_lab.core import LabContext, Runner, registry
from validation_lab.faults import DeterministicFaultLink, FaultProfile
from validation_lab.reporting import markdown_report
from validation_lab.storage import compare, create_golden
from validation_lab.ui import COMPLETE_KEYS, MENU


def test_all_menu_validators_are_registered():
    registered = {plugin.key for plugin in registry.all()}
    requested = {action for _, _, action in MENU
                 if action not in {"complete", "replay", "record", "compare", "report", "tools", "exit"}}
    assert requested <= registered
    assert len(MENU) == 22


def test_packet_replay_can_return_to_main_menu(monkeypatch, tmp_path):
    from validation_lab.ui import TerminalLab

    lab = TerminalLab(Path(__file__).parent)
    lab.context.sessions_dir = tmp_path
    (tmp_path / "session.json").write_text('{"events": []}')
    monkeypatch.setattr("builtins.input", lambda prompt="": "0")
    assert lab.replay() is None


def test_complete_lab_run_has_no_failures(tmp_path):
    context = LabContext(Path(__file__).parent)
    context.data_dir = tmp_path
    context.sessions_dir = tmp_path / "sessions"
    context.golden_dir = tmp_path / "golden"
    context.reports_dir = tmp_path / "reports"
    for directory in (context.sessions_dir, context.golden_dir, context.reports_dir):
        directory.mkdir()
    result = Runner(context).run(COMPLETE_KEYS, "self-test")
    assert not [item for item in result.findings if item.status.value == "FAIL"]
    assert any(event.subsystem == "execution" for event in result.events)


def test_fault_injection_is_deterministic():
    profile = FaultProfile(loss=.2, corruption=.3, duplication=.2, delay_steps=2, seed=99)
    outputs = []
    for _ in range(2):
        link = DeterministicFaultLink(profile)
        run = []
        for index in range(20):
            run.extend(link.transmit(bytes([index])))
        run.extend(link.flush())
        outputs.append(run)
    assert outputs[0] == outputs[1]


def test_golden_comparison_and_report(tmp_path):
    context = LabContext(Path(__file__).parent)
    result = Runner(context).run(["protocol"], "golden")
    session = context.sessions_dir / f"{result.run_id}.json"
    golden = create_golden(session, tmp_path, "known-good")
    assert compare(session, golden) == []
    report = markdown_report(result, tmp_path / "report.md")
    assert "Overall status" in report.read_text()
