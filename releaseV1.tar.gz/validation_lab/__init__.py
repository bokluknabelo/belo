"""Interactive cross-language relay protocol laboratory."""

__version__ = "1.0.0"
