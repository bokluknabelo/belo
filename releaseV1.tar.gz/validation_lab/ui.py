from __future__ import annotations

from pathlib import Path
import json
import os
import sys
import time

from .core import LabContext, Runner, discover_plugins, registry
from .model import Event, Status
from .reporting import markdown_report
from .storage import compare, create_golden, list_json, load


MENU = [
    ("1", "Run Complete System Validation", "complete"),
    ("2", "Test Python Server", "python"),
    ("3", "Test Java Client", "java"),
    ("4", "Cross-Stack Synchronization", "cross_stack"),
    ("5", "Protocol Validation", "protocol"),
    ("6", "Session Lifecycle", "session"),
    ("7", "APDU Flow Validation", "apdu"),
    ("8", "Network Tests", "network"),
    ("9", "Timing Analysis", "timing"),
    ("10", "Thread Synchronization", "threads"),
    ("11", "Packet Replay", "replay"),
    ("12", "Record Live Session", "record"),
    ("13", "Compare Against Golden Session", "compare"),
    ("14", "State Machine Validator", "state"),
    ("15", "Callback Validator", "callbacks"),
    ("16", "Object Lifecycle Validator", "objects"),
    ("17", "Configuration Validator", "config"),
    ("18", "Stress Tests", "stress"),
    ("19", "Fault Injection", "faults"),
    ("20", "Generate Validation Report", "report"),
    ("21", "Developer Tools / Live Monitor", "tools"),
    ("22", "Exit", "exit"),
]

COMPLETE_KEYS = ["startup", "python", "java", "cross_stack", "protocol", "session",
                 "apdu", "network", "timing", "threads", "state", "callbacks",
                 "objects", "config", "stress", "faults"]


class TerminalLab:
    def __init__(self, root: Path):
        discover_plugins(root)
        self.context = LabContext(root)
        self.runner = Runner(self.context)

    def display_result(self, result) -> None:
        print(f"\n[{result.status.value}] {result.name} ({result.run_id})")
        for item in result.findings:
            icon = {Status.PASS: "+", Status.FAIL: "!", Status.WARN: "?", Status.INFO: "i"}[item.status]
            print(f" {icon} {item.validator:<12} {item.summary} [{item.duration_ms:.2f}ms]")
            if item.evidence and item.status != Status.PASS:
                print(f"   evidence: {item.evidence}")
        print(" summary:", result.counts())

    def run_validator(self, key: str, title: str | None = None) -> None:
        keys = COMPLETE_KEYS if key == "complete" else [key]
        result = self.runner.run(keys, title or registry.get(keys[0]).title)
        self.display_result(result)

    def replay(self) -> None:
        print("\nPACKET REPLAY")
        print("0. Back to Main Menu")
        sessions = list_json(self.context.sessions_dir)
        if not sessions:
            print("No recorded sessions.")
            return
        path = self.choose(sessions, "session")
        if not path: return
        payload = load(path)
        speed = input("Replay speed [1.0, 0=instant, B=back]: ").strip() or "1.0"
        if speed.lower() in {"b", "back"}:
            return
        factor = float(speed)
        previous = None
        for raw in payload.get("events", []):
            timestamp = raw.get("timestamp_ns", 0)
            if factor and previous is not None:
                time.sleep(min((timestamp - previous) / 1e9 / factor, 1.0))
            previous = timestamp
            print(f"{raw.get('subsystem','-'):12} {raw.get('direction','-'):8} "
                  f"{raw.get('function','-'):28} {raw.get('result','')}")

    def record(self) -> None:
        print("Recording a deterministic complete validation session...")
        self.run_validator("complete", "Recorded system session")
        if self.context.last_result:
            print("Saved under", self.context.sessions_dir)

    def golden(self) -> None:
        sessions, goldens = list_json(self.context.sessions_dir), list_json(self.context.golden_dir)
        if not sessions:
            print("Run or record a session first.")
            return
        if not goldens:
            session = self.choose(sessions, "session")
            if session:
                name = input("Golden name: ").strip() or "default"
                print("Created", create_golden(session, self.context.golden_dir, name))
            return
        actual = self.choose(sessions, "actual session")
        golden = self.choose(goldens, "golden session")
        if not actual or not golden: return
        differences = compare(actual, golden)
        print("MATCH" if not differences else f"{len(differences)} deviation(s)")
        for line in differences[:50]: print(" -", line)

    def report(self) -> None:
        if not self.context.last_result:
            print("No in-memory run; executing complete validation first.")
            self.run_validator("complete")
        result = self.context.last_result
        path = self.context.reports_dir / f"validation-{result.run_id}.md"
        print("Report:", markdown_report(result, path))

    def monitor(self) -> None:
        print("Live monitor: running complete validation (Ctrl-C to stop)\n")
        def show(event: Event):
            stamp = event.timestamp_ns / 1e9
            print(f"{stamp:.3f} {event.thread:<14} {event.subsystem:<12} "
                  f"{event.state:<9} {event.function:<24} {event.result}")
        self.context.bus.listeners.append(show)
        try:
            self.run_validator("complete")
        finally:
            self.context.bus.listeners.remove(show)

    def tools(self) -> None:
        print("\n1. Live monitor\n2. List validators\n3. Show data directories\n4. Back")
        choice = input("Tool: ").strip()
        if choice == "1": self.monitor()
        elif choice == "2":
            for plugin in registry.all(): print(f"{plugin.key:<14} {plugin.title}")
        elif choice == "3": print(self.context.data_dir)

    @staticmethod
    def choose(paths: list[Path], label: str) -> Path | None:
        print("0. Back to Main Menu")
        for index, path in enumerate(paths, 1): print(f"{index}. {path.name}")
        raw = input(f"Choose {label} [0/B/blank = back]: ").strip()
        if not raw or raw.lower() in {"0", "b", "back"}: return None
        index = int(raw) - 1
        return paths[index] if 0 <= index < len(paths) else None

    def main(self) -> int:
        actions = {number: action for number, _, action in MENU}
        while True:
            print("\n" + "=" * 62 + "\n RELAY PROTOCOL LAB\n" + "=" * 62)
            for number, title, _ in MENU: print(f"{number:>2}. {title}")
            choice = input("\nSelect: ").strip()
            action = actions.get(choice)
            if action == "exit": return 0
            if action is None: print("Invalid selection."); continue
            try:
                if action in {plugin.key for plugin in registry.all()} or action == "complete":
                    self.run_validator(action)
                elif action == "replay": self.replay()
                elif action == "record": self.record()
                elif action == "compare": self.golden()
                elif action == "report": self.report()
                elif action == "tools": self.tools()
            except (ValueError, IndexError) as exc:
                print("Input error:", exc)


def run(root: Path) -> int:
    return TerminalLab(root).main()
