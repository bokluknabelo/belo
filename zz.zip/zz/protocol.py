# -*- coding: utf-8 -*-
"""EMV APDU protocol classes, TLV helpers, and byte-level operations."""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional, List, Tuple

@dataclass
class CommandAPDU:
    cla: int = 0x00
    ins: int = 0x00
    p1: int = 0x00
    p2: int = 0x00
    data: bytes = b""
    le: int = 0

    @classmethod
    def from_bytes(cls, raw: bytes) -> Optional["CommandAPDU"]:
        if len(raw) < 4:
            return None
        lc = raw[4] if len(raw) > 4 else 0
        if lc == 0:
            return cls(cla=raw[0], ins=raw[1], p1=raw[2], p2=raw[3])
        if 5 + lc > len(raw):
            return None
        le = 0
        data_end = 5 + lc
        if len(raw) > data_end:
            le = raw[data_end]
        return cls(cla=raw[0], ins=raw[1], p1=raw[2], p2=raw[3],
                   data=raw[5:data_end], le=le)

    def to_bytes(self) -> bytes:
        if self.data:
            return bytes([self.cla, self.ins, self.p1, self.p2,
                          len(self.data)]) + self.data + (bytes([self.le]) if self.le else b"")
        return bytes([self.cla, self.ins, self.p1, self.p2, 0])

    @property
    def ins_name(self) -> str:
        names = {
            0xA4: "SELECT", 0xA8: "GPO", 0xB2: "READ RECORD",
            0x20: "VERIFY", 0xAE: "GENERATE AC", 0xCA: "GET DATA",
            0x82: "EXTERNAL AUTH",
        }
        return names.get(self.ins, f"0x{self.ins:02X}")

@dataclass
class ResponseAPDU:
    data: bytes = b""
    sw1: int = 0x90
    sw2: int = 0x00

    @classmethod
    def from_bytes(cls, raw: bytes) -> "ResponseAPDU":
        if len(raw) < 2:
            return cls(sw1=0x6F, sw2=0x00)
        return cls(data=raw[:-2], sw1=raw[-2], sw2=raw[-1])

    def to_bytes(self) -> bytes:
        return self.data + bytes([self.sw1, self.sw2])

    @property
    def sw(self) -> bytes:
        return bytes([self.sw1, self.sw2])

    @property
    def is_ok(self) -> bool:
        return self.sw1 == 0x90 and self.sw2 == 0x00

def craft_verify_success() -> ResponseAPDU:
    """Return SW=9000 for VERIFY bypass."""
    return ResponseAPDU(sw1=0x90, sw2=0x00)

def sw(status: bytes) -> ResponseAPDU:
    return ResponseAPDU(sw1=status[0], sw2=status[1])

SW9000 = b"\x90\x00"
SW6F00 = b"\x6F\x00"

# --- TLV helpers -----------------------------------------------------------

def find_tlv(data: bytes, target_tag: int) -> Optional[bytes]:
    i, n = 0, len(data)
    while i < n:
        tag_first = data[i]; i += 1
        if (tag_first & 0x1F) == 0x1F:
            if i >= n: return None
            tag = (tag_first << 8) | data[i]; i += 1
        else:
            tag = tag_first
        if i >= n: return None
        lf = data[i]; i += 1
        if lf & 0x80:
            nb = lf & 0x7F
            if nb == 0 or nb > 2 or i + nb > n: return None
            length = 0
            for _ in range(nb):
                length = (length << 8) | data[i]; i += 1
        else:
            length = lf
        if i + length > n: return None
        value = data[i:i + length]
        if tag == target_tag: return value
        if tag_first & 0x20:
            inner = find_tlv(value, target_tag)
            if inner is not None: return inner
        i += length
    return None

def build_tlv(tag: int, value: bytes) -> bytes:
    if tag > 0xFF:
        tag_bytes = struct.pack(">H", tag)
    else:
        tag_bytes = bytes([tag])
    length = len(value)
    if length < 0x80:
        length_bytes = bytes([length])
    elif length < 0x100:
        length_bytes = bytes([0x81, length])
    else:
        length_bytes = bytes([0x82, (length >> 8) & 0xFF, length & 0xFF])
    return tag_bytes + length_bytes + value

def parse_tlv_list(data: bytes) -> List[Tuple[int, bytes]]:
    """Parse all top-level TLV entries into a list of (tag, value)."""
    result = []
    i, n = 0, len(data)
    while i < n:
        tag_first = data[i]; i += 1
        if (tag_first & 0x1F) == 0x1F:
            if i >= n: break
            tag = (tag_first << 8) | data[i]; i += 1
        else:
            tag = tag_first
        if i >= n: break
        lf = data[i]; i += 1
        if lf & 0x80:
            nb = lf & 0x7F
            if nb == 0 or nb > 2 or i + nb > n: break
            length = 0
            for _ in range(nb):
                length = (length << 8) | data[i]; i += 1
        else:
            length = lf
        if i + length > n: break
        result.append((tag, data[i:i + length]))
        i += length
    return result