# -*- coding: utf-8 -*-
"""
EMV Test Rig - Automated Verification for Relay, Kernel, and Protocol Layers.
Validates Mastercard and VISA profiles against the comprehensive test matrix.
"""

import os
import sys
import unittest
import struct
from typing import Optional, Tuple, List

# Force resolve directory path containing test_rig.py to bypass path isolation
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

# Import from protocol.py
from protocol import CommandAPDU, ResponseAPDU, find_tlv, build_tlv, replace_tlv, parse_tlv_list

# =============================================================================
# MOCK IMPLEMENTATIONS OF KERNEL & RELAY BEHAVIORS FOR TESTING
# =============================================================================

class MockDefaultEmvKernel:
    """Simulates the Java DefaultEmvKernel mutation logic for verification."""
    def __init__(self):
        self.scheme = "UNKNOWN"
        self.ttq_offset = 0
        self.cvm_results_offset = -1
        self.aip_patched = False
        self.ctq_patched = False
        self.cvm_list_patched = False
        self.auc_patched = False
        self.form_factor_patched = False

    def recognize_scheme(self, aid: bytes) -> str:
        if aid.startswith(bytes.fromhex("A000000003")):
            self.scheme = "VISA"
        elif aid.startswith(bytes.fromhex("A000000004")):
            self.scheme = "MASTERCARD"
        else:
            self.scheme = "UNKNOWN"
        return self.scheme

    def apply_outbound_capdu(self, ins: int, capdu: bytes) -> bytes:
        if ins == 0xA8:  # GPO
            pdol_start = 7 if (len(capdu) > 5 and capdu[5] == 0x83) else 5
            # Guard: if the CAPDU doesn't have enough bytes for PDOL data + 4-byte TTQ, skip patch
            if len(capdu) < pdol_start + 4:
                return capdu
                
            patched = bytearray(capdu)
            ttq_pos = pdol_start + self.ttq_offset
            
            if self.scheme == "VISA":
                patched[ttq_pos:ttq_pos+4] = b"\x36\x40\x00\x00"
            elif self.scheme == "MASTERCARD":
                patched[ttq_pos:ttq_pos+4] = b"\x20\x00\x00\x00"
            return bytes(patched)
            
        if ins == 0xAE:  # GENERATE AC
            if self.cvm_results_offset >= 0:
                patched = bytearray(capdu)
                patch_pos = 5 + self.cvm_results_offset
                patched[patch_pos:patch_pos+2] = b"\x1E\x03"
                return bytes(patched)
        return capdu

    def apply_live_mitm(self, ins: int, rapdu: bytes) -> bytes:
        if len(rapdu) < 2:
            return rapdu
            
        if ins == 0xA8:  # GPO Response
            working = rapdu
            aip_val = find_tlv(working, 0x82)
            if aip_val:
                new_aip = bytes([aip_val[0] | 0x5C, aip_val[1]])
                working = replace_tlv(working, 0x82, new_aip)
                self.aip_patched = True
                
            if self.scheme == "VISA":
                ctq_val = find_tlv(working, 0x9F6C)
                if ctq_val:
                    working = replace_tlv(working, 0x9F6C, b"\x00\xC0")
                    self.ctq_patched = True
            return working

        if ins == 0xB2:  # READ RECORD Response
            working = rapdu
            if self.scheme == "MASTERCARD":
                cvm_list = bytes.fromhex("00000000000000001F031E030000")
                working = replace_tlv(working, 0x8E, cvm_list)
                self.cvm_list_patched = True
                
            auc_val = find_tlv(working, 0x9F07)
            if auc_val:
                working = replace_tlv(working, 0x9F07, b"\xFF\x00")
                self.auc_patched = True
            return working

        if ins == 0xA4:  # SELECT Response
            working = rapdu
            ff_val = find_tlv(working, 0x9F6E)
            if ff_val:
                new_ff = bytes([(ff_val[0] & 0x0F) | 0x20])
                working = replace_tlv(working, 0x9F6E, new_ff)
                self.form_factor_patched = True
            return working

        return rapdu

class MockRelayServer:
    """Simulates active relay server processing and guard conditions."""
    def __init__(self):
        self.selected_aid: Optional[bytes] = None
        self.gac_response_count = 0
        self.pending_capdu: Optional[bytes] = None
        self.session_reset_count = 0
        self.verify_bypass_count = 0
        self.arpc_forge_count = 0
        self.arpc_rewrite_count = 0
        self.tvr_mutation_count = 0

    def handle_ctrl(self, command: str) -> str:
        if command == "SESSION_RESET":
            if self.selected_aid is not None:
                if (self.pending_capdu is not None 
                        and self.pending_capdu[1] != 0xAE
                        and self.gac_response_count == 0):
                    return "GUARDED"
            self.session_reset_count += 1
            return "RESET"
        return "UNKNOWN"

    def handle_verify(self, capdu: bytes) -> ResponseAPDU:
        self.verify_bypass_count += 1
        return ResponseAPDU(sw1=0x90, sw2=0x00)

    def handle_arqc_cache(self, rapdu: bytes) -> bool:
        cid = find_tlv(rapdu, 0x9F27)
        if cid and cid[0] == 0x80:
            return True
        return False

# =============================================================================
# UNIT TESTS FOR THE EMV TEST MATRIX
# =============================================================================

class TestEmvPipeline(unittest.TestCase):

    def setUp(self):
        self.kernel = MockDefaultEmvKernel()
        self.relay = MockRelayServer()

    # -------------------------------------------------------------------------
    # STAGE 0 & 1: SELECT & GPO (INS A4 / A8)
    # -------------------------------------------------------------------------

    def test_select_and_recognize_mc(self):
        """Matrix 0.3 & 0.5: Verify Mastercard AID recognition."""
        aid_mc = bytes.fromhex("A0000000041010")
        scheme = self.kernel.recognize_scheme(aid_mc)
        self.assertEqual(scheme, "MASTERCARD")

    def test_select_and_recognize_visa(self):
        """Matrix 0.2 & 0.5: Verify VISA AID recognition."""
        aid_visa = bytes.fromhex("A0000000031010")
        scheme = self.kernel.recognize_scheme(aid_visa)
        self.assertEqual(scheme, "VISA")

    def test_select_unknown_aid(self):
        """Matrix 0.9: Unknown AID returns UNKNOWN scheme."""
        aid_unknown = bytes.fromhex("A0000000251010")
        scheme = self.kernel.recognize_scheme(aid_unknown)
        self.assertEqual(scheme, "UNKNOWN")

    def test_select_ppse_ignored(self):
        """Matrix 0.1: PPSE SELECT does not trigger AID extraction."""
        cmd = CommandAPDU.from_bytes(bytes.fromhex("00A404000E325041592E5359532E444446303100"))
        self.assertIsNotNone(cmd)
        self.assertEqual(cmd.ins, 0xA4)
        self.assertEqual(cmd.p1, 0x04)

    def test_select_form_factor_patch(self):
        """Matrix 0.6: Verify 9F6E form factor patched to Mobile."""
        # 6F length 0x1B (27) = 0x1B bytes of payload
        # 84 len 0x0E, A5 len 0x08, BF0C len 0x05, 9F6E len 0x02, 0x08 value
        select_rapdu = bytes.fromhex(
            "6F1B840E315041592E5359532E4444463031A508BF0C059F6E0208009000"
        )
        ff_val = find_tlv(select_rapdu, 0x9F6E)
        self.assertIsNotNone(ff_val)
        
        new_ff = bytes([(ff_val[0] & 0x0F) | 0x20])
        patched = replace_tlv(select_rapdu, 0x9F6E, new_ff)
        patched_ff = find_tlv(patched, 0x9F6E)
        self.assertIsNotNone(patched_ff)
        self.assertEqual(patched_ff[0] & 0xF0, 0x20)

    def test_gpo_ctq_patch_visa(self):
        """Matrix 1.6: Verify VISA CTQ set to 00C0 in GPO."""
        self.kernel.scheme = "VISA"
        gpo_rapdu = bytes.fromhex("770A820200609F6C0200809000")
        patched = self.kernel.apply_live_mitm(0xA8, gpo_rapdu)
        ctq = find_tlv(patched, 0x9F6C)
        self.assertIsNotNone(ctq)
        self.assertEqual(ctq, bytes.fromhex("00C0"))
        self.assertTrue(self.kernel.ctq_patched)

    def test_gpo_afl_parsed(self):
        """Matrix 1.9: Verify AFL raw bytes present in GPO response."""
        gpo_rapdu = bytes.fromhex("770A820200609404180101009000")
        afl = find_tlv(gpo_rapdu, 0x94)
        self.assertIsNotNone(afl)
        self.assertEqual(afl, bytes.fromhex("18010100"))

    # -------------------------------------------------------------------------
    # STAGE 2: READ RECORD (INS B2)
    # -------------------------------------------------------------------------

    def test_read_record_cvm_list_mc(self):
        """Matrix 2.1: Verify Mastercard B2 CVM list injection."""
        self.kernel.scheme = "MASTERCARD"
        b2_rapdu = bytes.fromhex("70159F0702FF008E0E00000000000000000000000000009000")
        patched = self.kernel.apply_live_mitm(0xB2, b2_rapdu)
        cvm_list = find_tlv(patched, 0x8E)
        self.assertIsNotNone(cvm_list)
        self.assertEqual(cvm_list, bytes.fromhex("00000000000000001F031E030000"))
        self.assertTrue(self.kernel.cvm_list_patched)

    def test_read_record_no_cvm_list_visa(self):
        """Matrix 2.2: Verify VISA bypasses B2 CVM list injection."""
        self.kernel.scheme = "VISA"
        b2_rapdu = bytes.fromhex("70159F0702FF008E0E00000000000000000000000000009000")
        _ = self.kernel.apply_live_mitm(0xB2, b2_rapdu)
        self.assertFalse(self.kernel.cvm_list_patched)

    def test_auc_patch_ff00(self):
        """Matrix 2.3: Verify AUC (9F07) patched to FF00."""
        b2_rapdu = bytes.fromhex("70059F0702C0009000")
        patched = self.kernel.apply_live_mitm(0xB2, b2_rapdu)
        auc = find_tlv(patched, 0x9F07)
        self.assertIsNotNone(auc)
        self.assertEqual(auc, bytes.fromhex("FF00"))
        self.assertTrue(self.kernel.auc_patched)

    def test_replace_tlv_preserves_sw(self):
        """Matrix 2.16: Verify replaceTagValue preserves SW 9000."""
        b2_rapdu = bytes.fromhex("70159F0702FF008E0E00000000000000000000000000009000")
        cvm_list = bytes.fromhex("00000000000000001F031E030000")
        patched = replace_tlv(b2_rapdu, 0x8E, cvm_list)
        self.assertEqual(patched[-2:], b"\x90\x00")

    def test_replace_tlv_structure_preserved(self):
        """Matrix 2.16: Verify outer template length updated correctly."""
        dummy_val = b"\x00" * 128
        payload = build_tlv(0x9F07, b"\xFF\x00") + build_tlv(0x8E, dummy_val)
        template = b"\x70" + struct.pack("B", 0x81) + struct.pack("B", len(payload)) + payload + b"\x90\x00"
        new_cvm = bytes.fromhex("00000000000000001F031E030000")
        patched = replace_tlv(template, 0x8E, new_cvm)
        expected_len = len(patched) - 3 - 2
        if patched[1] == 0x81:
            actual_len = patched[2]
            self.assertEqual(actual_len, expected_len)

    # -------------------------------------------------------------------------
    # STAGE 3: VERIFY (INS 20)
    # -------------------------------------------------------------------------

    def test_verify_intercepted(self):
        """Matrix 3.1: Verify VERIFY intercepted and returns 9000."""
        verify_capdu = bytes.fromhex("00200080080000000000000000")
        response = self.relay.handle_verify(verify_capdu)
        self.assertEqual(response.sw, b"\x90\x00")
        self.assertEqual(self.relay.verify_bypass_count, 1)

    def test_verify_not_intercepted_wrong_cla(self):
        """Matrix N.5: Verify with wrong CLA is not intercepted."""
        verify_capdu = bytes.fromhex("80200080080000000000000000")
        self.assertNotEqual(verify_capdu[0], 0x00)

    # -------------------------------------------------------------------------
    # STAGE 4: GENERATE AC (INS AE)
    # -------------------------------------------------------------------------

    def test_cvm_results_patched(self):
        """Matrix 4.1: Verify CVM results (9F34) patched to 1E03."""
        self.kernel.cvm_results_offset = 40
        gac_capdu = bytearray(b"\x00" * 50)
        gac_capdu[0:5] = bytes.fromhex("80AE000020")
        gac_capdu[45] = 0x1E
        gac_capdu[46] = 0x03
        patched = self.kernel.apply_outbound_capdu(0xAE, bytes(gac_capdu))
        self.assertEqual(patched[45], 0x1E)
        self.assertEqual(patched[46], 0x03)

    def test_cvm_results_not_patched_no_offset(self):
        """Matrix 4.2: CVM results NOT patched when offset not captured."""
        self.kernel.cvm_results_offset = -1
        gac_capdu = bytes.fromhex("80AE000020" + "00" * 32)
        patched = self.kernel.apply_outbound_capdu(0xAE, gac_capdu)
        self.assertEqual(patched, gac_capdu)

    def test_gac_arqc_detected(self):
        """Matrix 4.7: CID=0x80 triggers ARQC cache."""
        gac_rapdu = bytes.fromhex(
            "77299F2701809F360201C79F26085DC027596F639E23"
            "9F10120110A00302A400000000FFFFFFFFFFFFFFFF9000"
        )
        self.assertTrue(self.relay.handle_arqc_cache(gac_rapdu))

    def test_gac_tc_detected(self):
        """Matrix 4.8: CID=0x40 does NOT trigger ARQC cache."""
        gac_rapdu = bytes.fromhex(
            "77299F2701409F360201C79F26085DC027596F639E23"
            "9F10120110A00302A400000000FFFFFFFFFFFFFFFF9000"
        )
        self.assertFalse(self.relay.handle_arqc_cache(gac_rapdu))

    def test_gac_aac_detected(self):
        """Matrix 4.9: CID=0x00 does NOT trigger ARQC cache."""
        gac_rapdu = bytes.fromhex(
            "77299F2701009F360201C79F26085DC027596F639E23"
            "9F10120110A00302A400000000FFFFFFFFFFFFFFFF9000"
        )
        self.assertFalse(self.relay.handle_arqc_cache(gac_rapdu))

    # -------------------------------------------------------------------------
    # STAGE 5: EXTERNAL AUTHENTICATE (INS 82)
    # -------------------------------------------------------------------------

    def test_arc_decode_approved(self):
        """Matrix 5.2: ARC 3030 decodes to APPROVED."""
        arc_bytes = bytes.fromhex("3030")
        self.assertEqual(arc_bytes, b"00")

    def test_arc_decode_declined(self):
        """Matrix 5.2: ARC 3535 decodes to DECLINED_PIN_TRIES_EXCEEDED."""
        arc_bytes = bytes.fromhex("3535")
        self.assertEqual(arc_bytes, b"55")

    # -------------------------------------------------------------------------
    # CROSS-CUTTING: RELAY SESSION RESET GUARD
    # -------------------------------------------------------------------------

    def test_session_reset_guard_active(self):
        """Matrix 7.1: SESSION_RESET guarded mid-transaction."""
        self.relay.selected_aid = bytes.fromhex("A0000000041010")
        self.relay.pending_capdu = bytes.fromhex("00B2011C00")
        self.relay.gac_response_count = 0
        result = self.relay.handle_ctrl("SESSION_RESET")
        self.assertEqual(result, "GUARDED")

    def test_session_reset_guard_inactive(self):
        """Matrix 7.2: SESSION_RESET not guarded when no transaction."""
        self.relay.selected_aid = None
        result = self.relay.handle_ctrl("SESSION_RESET")
        self.assertEqual(result, "RESET")
        self.assertEqual(self.relay.session_reset_count, 1)

    def test_session_reset_guard_after_gac(self):
        """Matrix 7.2: SESSION_RESET allowed after GENERATE AC completes."""
        self.relay.selected_aid = bytes.fromhex("A0000000031010")
        self.relay.pending_capdu = bytes.fromhex("80AE000020" + "00" * 32)
        self.relay.gac_response_count = 1
        result = self.relay.handle_ctrl("SESSION_RESET")
        self.assertEqual(result, "RESET")
        self.assertEqual(self.relay.session_reset_count, 1)

    # -------------------------------------------------------------------------
    # PACKET ROUTER TESTS
    # -------------------------------------------------------------------------

    def test_packet_router_mode_default(self):
        """Verify default mode is passthrough."""
        self.assertEqual(packet_router.get_mode(), packet_router.MODE_PASSTHROUGH)

    def test_packet_router_set_mode_mitm(self):
        """Verify MITM mode can be set."""
        packet_router.set_mode(packet_router.MODE_MITM)
        self.assertEqual(packet_router.get_mode(), packet_router.MODE_MITM)

    def test_packet_router_mode_profile(self):
        """Verify PROFILE mode can be set."""
        packet_router.set_mode(packet_router.MODE_PROFILE)
        self.assertEqual(packet_router.get_mode(), packet_router.MODE_PROFILE)

    def test_packet_router_passthrough_returns_original(self):
        """Verify passthrough mode returns payload unchanged."""
        packet_router.set_mode(packet_router.MODE_PASSTHROUGH)
        payload = bytes.fromhex("00A4040007A000000003101000")
        result = packet_router.apply_mitm("capdu", payload, packet_router.session, test_logger)
        self.assertEqual(result, payload)

    def test_packet_router_classify_select(self):
        """Verify classify_and_cache stores SELECT correctly."""
        select = bytes.fromhex("00A4040007A000000003101000")
        packet_router.classify_and_cache(select)
        self.assertEqual(packet_router.session.get("last_select"), select)
        self.assertEqual(packet_router.session["capdu_count"], 1)

    def test_packet_router_classify_gpo(self):
        """Verify classify_and_cache stores GPO correctly."""
        gpo = bytes.fromhex("80A800000400000000")
        packet_router.classify_and_cache(gpo)
        self.assertEqual(packet_router.session.get("last_gpo"), gpo)

    def test_packet_router_classify_gac(self):
        """Verify classify_and_cache stores GENERATE AC correctly."""
        gac = bytes.fromhex("80AE0000200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000")
        packet_router.classify_and_cache(gac)
        self.assertEqual(packet_router.session.get("last_gac"), gac)

    def test_packet_router_hook_registration(self):
        """Verify MITM hook can be registered and called."""
        called = []
        def test_hook(direction, payload, session, log):
            called.append(True)
            return payload
        packet_router.register_mitm_hook("test_hook", test_hook)
        packet_router.set_mode(packet_router.MODE_MITM)
        result = packet_router.apply_mitm("capdu", b"\x00\xA4\x04\x00", packet_router.session, test_logger)
        self.assertTrue(len(called) > 0)
        self.assertEqual(result, b"\x00\xA4\x04\x00")

    def test_packet_router_hook_exception_handled(self):
        """Verify a failing hook does not crash the pipeline."""
        def failing_hook(direction, payload, session, log):
            raise ValueError("Intentional failure")
        packet_router.register_mitm_hook("failing_hook", failing_hook)
        packet_router.set_mode(packet_router.MODE_MITM)
        result = packet_router.apply_mitm("capdu", b"\x00\xA4\x04\x00", packet_router.session, test_logger)
        self.assertEqual(result, b"\x00\xA4\x04\x00")

    def test_packet_router_reset_session(self):
        """Verify reset_session clears state."""
        packet_router.classify_and_cache(bytes.fromhex("00A4040007A000000003101000"))
        packet_router.reset_session()
        self.assertEqual(packet_router.session["capdu_count"], 0)
        self.assertIsNone(packet_router.session.get("last_select"))

    # -------------------------------------------------------------------------
    # PROTOCOL LAYER VERIFICATION (protocol.py)
    # -------------------------------------------------------------------------

    def test_protocol_struct_import(self):
        """Matrix 9.1: struct module is importable."""
        import struct
        self.assertTrue(hasattr(struct, "pack"))

    def test_protocol_command_apdu_parse(self):
        """Matrix 9.2: CommandAPDU parses SELECT correctly."""
        raw = bytes.fromhex("00A4040007A000000003101000")
        cmd = CommandAPDU.from_bytes(raw)
        self.assertIsNotNone(cmd)
        self.assertEqual(cmd.ins, 0xA4)
        self.assertEqual(cmd.ins_name, "SELECT")
        self.assertEqual(cmd.data, bytes.fromhex("A0000000031010"))

    def test_protocol_command_apdu_is_select(self):
        """Matrix 9.6: is_select property works."""
        raw = bytes.fromhex("00A4040007A000000003101000")
        cmd = CommandAPDU.from_bytes(raw)
        self.assertTrue(cmd.is_select)

    def test_protocol_command_apdu_is_verify(self):
        """Matrix 9.7: is_verify property works."""
        raw = bytes.fromhex("00200080080000000000000000")
        cmd = CommandAPDU.from_bytes(raw)
        self.assertTrue(cmd.is_verify)

    def test_protocol_command_apdu_short_frame(self):
        """Matrix 9.3: Frame < 4 bytes returns None."""
        raw = bytes.fromhex("00A4")
        cmd = CommandAPDU.from_bytes(raw)
        self.assertIsNone(cmd)

    def test_protocol_response_apdu_from_bytes(self):
        """Matrix 9.9: ResponseAPDU parses correctly."""
        raw = bytes.fromhex("6F108407A0000000031010A5049F6E02089000")
        resp = ResponseAPDU.from_bytes(raw)
        self.assertEqual(resp.sw1, 0x90)
        self.assertEqual(resp.sw2, 0x00)
        self.assertTrue(resp.is_ok)

    def test_protocol_response_apdu_error(self):
        """Matrix 9.12: ResponseAPDU detects non-9000 SW."""
        raw = bytes.fromhex("6F00")
        resp = ResponseAPDU.from_bytes(raw)
        self.assertFalse(resp.is_ok)

    def test_protocol_find_tlv_1byte_tag(self):
        """Matrix 9.15: find_tlv finds 1-byte tag (82)."""
        data = bytes.fromhex("820200609000")
        val = find_tlv(data, 0x82)
        self.assertEqual(val, bytes.fromhex("0060"))

    def test_protocol_find_tlv_2byte_tag(self):
        """Matrix 9.16: find_tlv finds 2-byte tag (9F36)."""
        data = bytes.fromhex("9F360201C79000")
        val = find_tlv(data, 0x9F36)
        self.assertEqual(val, bytes.fromhex("01C7"))

    def test_protocol_find_tlv_recursive(self):
        """Matrix 9.17: find_tlv finds tag inside constructed template."""
        data = bytes.fromhex("770A9F2701809F360201C79000")
        val = find_tlv(data, 0x9F27)
        self.assertEqual(val, bytes.fromhex("80"))

    def test_protocol_find_tlv_not_found(self):
        """Matrix 9.18: find_tlv returns None for missing tag."""
        data = bytes.fromhex("820200609000")
        val = find_tlv(data, 0x9F27)
        self.assertIsNone(val)

    def test_protocol_find_tlv_empty(self):
        """Matrix 9.19: find_tlv on empty data returns None."""
        val = find_tlv(b"", 0x82)
        self.assertIsNone(val)

    def test_protocol_build_tlv_1byte_tag(self):
        """Matrix 9.20: build_tlv builds 1-byte tag correctly."""
        result = build_tlv(0x82, bytes.fromhex("5C60"))
        self.assertEqual(result, bytes.fromhex("82025C60"))

    def test_protocol_build_tlv_2byte_tag(self):
        """Matrix 9.21: build_tlv builds 2-byte tag correctly."""
        result = build_tlv(0x9F36, bytes.fromhex("01C7"))
        self.assertEqual(result, bytes.fromhex("9F360201C7"))

    def test_protocol_build_tlv_extended_length(self):
        """Matrix 9.22: build_tlv uses 0x81 for values"""
        val = b"\x00" * 200
        result = build_tlv(0x8E, val)
        self.assertEqual(result[0], 0x8E)
        self.assertEqual(result[1], 0x81)
        self.assertEqual(result[2], 200)

    def test_protocol_parse_tlv_list_flat(self):
        """Matrix 9.24: parse_tlv_list returns correct entries."""
        data = build_tlv(0x82, bytes.fromhex("5C60")) + build_tlv(0x9F36, bytes.fromhex("01C7"))
        entries = parse_tlv_list(data)
        self.assertEqual(len(entries), 2)
        self.assertEqual(entries[0][0], 0x82)
        self.assertEqual(entries[1][0], 0x9F36)

    def test_protocol_parse_tlv_list_empty(self):
        """Matrix 9.25: parse_tlv_list on empty returns []."""
        entries = parse_tlv_list(b"")
        self.assertEqual(entries, [])

    def test_protocol_replace_tlv_tag_found(self):
        """Matrix 9.27: replace_tlv replaces tag value."""
        data = build_tlv(0x82, bytes.fromhex("0060")) + build_tlv(0x9F36, bytes.fromhex("01C7"))
        new_aip = bytes.fromhex("5C60")
        result = replace_tlv(data, 0x82, new_aip)
        aip = find_tlv(result, 0x82)
        self.assertEqual(aip, new_aip)

    def test_protocol_replace_tlv_tag_not_found(self):
        """Matrix 9.28: replace_tlv returns original when tag absent."""
        data = build_tlv(0x82, bytes.fromhex("0060"))
        result = replace_tlv(data, 0x9F27, b"\x80")
        self.assertEqual(result, data)

    def test_protocol_replace_tlv_nested(self):
        """Matrix 9.29: replace_tlv works inside constructed template."""
        inner = build_tlv(0x9F27, b"\x00") + build_tlv(0x9F36, bytes.fromhex("01C7"))
        data = build_tlv(0x77, inner) + b"\x90\x00"
        result = replace_tlv(data, 0x9F27, b"\x80")
        cid = find_tlv(result, 0x9F27)
        self.assertEqual(cid, b"\x80")
        atc = find_tlv(result, 0x9F36)
        self.assertEqual(atc, bytes.fromhex("01C7"))

    def test_protocol_replace_tlv_empty(self):
        """Matrix 9.30: replace_tlv on empty returns empty."""
        result = replace_tlv(b"", 0x82, b"\x00")
        self.assertEqual(result, b"")

    # -------------------------------------------------------------------------
    # NEGATIVE / ADVERSARIAL TEST CASES
    # -------------------------------------------------------------------------

    def test_negative_truncated_select(self):
        """Matrix N.1: Truncated SELECT returns None."""
        raw = bytes.fromhex("00A4")
        cmd = CommandAPDU.from_bytes(raw)
        self.assertIsNone(cmd)

    def test_negative_gpo_before_select(self):
        """Matrix N.2: GPO before SELECT - scheme is UNKNOWN."""
        self.kernel.scheme = "UNKNOWN"
        self.assertEqual(self.kernel.scheme, "UNKNOWN")

    def test_negative_verify_wrong_cla_not_intercepted(self):
        """Matrix N.5: VERIFY with wrong CLA is not intercepted by mock."""
        verify_capdu = bytes.fromhex("80200080080000000000000000")
        self.assertNotEqual(verify_capdu[0], 0x00)

    def test_negative_empty_gpo_response(self):
        """Matrix N.9: Empty GPO response - no template."""
        gpo_rapdu = b"\x90\x00"
        self.assertIsNone(find_tlv(gpo_rapdu[:-2], 0x82))

    def test_negative_no_cdol1(self):
        """Matrix N.4: No CDOL1 parsed - CVM patch offset stays -1."""
        self.assertEqual(self.kernel.cvm_results_offset, -1)

    # -------------------------------------------------------------------------
    # EDGE CASES
    # -------------------------------------------------------------------------

    def test_edge_rapdu_trace(self):
        """Matrix E.1: Verify RAPDU trace fields present."""
        trace = {
            "A4": {"len": 13, "rtt": 498},
            "A8": {"len": 8, "rtt": 484},
            "B2": {"len": 5, "rtt": 560},
        }
        self.assertIn("A4", trace)
        self.assertIn("A8", trace)
        self.assertIn("B2", trace)

    def test_edge_stall_warning(self):
        """Matrix E.6: STALL warning clears on new CAPDU."""
        stall_warned = True
        _ = bytes.fromhex("00A4040007A000000003101000")
        stall_warned = False
        self.assertFalse(stall_warned)

    def test_edge_rapid_retry(self):
        """Matrix E.4: Rapid retry resets state."""
        self.relay.session_reset_count = 0
        self.relay.handle_ctrl("SESSION_RESET")
        self.relay.handle_ctrl("SESSION_RESET")
        self.assertEqual(self.relay.session_reset_count, 2)


# =============================================================================
# RUNNER
# =============================================================================

if __name__ == "__main__":
    unittest.main(verbosity=2)