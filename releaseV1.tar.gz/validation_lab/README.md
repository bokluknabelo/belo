# Relay Protocol Laboratory

Run the interactive laboratory from the repository root:

```bash
python -m validation_lab
```

Run it non-interactively in CI or before a development handoff:

```bash
python -m validation_lab --run complete --report
```

The application imports production Python through adapters and inspects the production Java source contract. Validators register through `validation_lab.core.registry.register`, so a new module can add a validator without changing the runner or UI. Structured sessions, golden baselines, and Markdown reports are stored under `.validation_lab/`.

Project-specific plugins can be dropped into `validation_plugins/*.py`. They are discovered automatically and may register validators with the shared registry.

The deterministic fault link supports loss, corruption, duplication, delayed delivery, and dropped acknowledgements. Recorded event streams omit wall-clock timing during golden comparisons, making replay comparisons stable across machines.
