#!/usr/bin/env python3
"""Offline protocol-laboratory report generator for relay.log."""

from __future__ import annotations

import argparse
import os
import re
import statistics
import sys
from collections import Counter
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Iterable, Optional

from emv_tags import describe_value, tag_info
from protocol import CommandAPDU, ResponseAPDU


LOG_RE = re.compile(r"^(?P<time>\d{2}:\d{2}:\d{2}\.\d{3}) \[(?P<level>\w+)] (?P<message>.*)$")
APDU_RE = re.compile(
    r"^APDU (?P<direction>\S+) (?P<kind>CAPDU|RAPDU) (?P<label>.+?) "
    # The runtime logger masks PAN nibbles with X. They still occupy one
    # hexadecimal nibble and must not cause the complete APDU event to vanish.
    r"len=(?P<length>\d+): (?P<hex>[0-9A-Fa-fXx ]+?)(?: \[(?P<note>[^]]+)])?$"
)
LOGCAT_APDU_RE = re.compile(r"\b(?P<kind>CAPDU|RAPDU):\s*(?P<hex>(?:[0-9A-Fa-f]{2}[ \t]*)+)")


@dataclass
class TLVNode:
    tag: str
    value: bytes
    offset: int
    header_length: int
    children: list["TLVNode"] = field(default_factory=list)

    @property
    def total_length(self) -> int:
        return self.header_length + len(self.value)


@dataclass
class APDUEvent:
    line: int
    timestamp: str
    milliseconds: int
    direction: str
    kind: str
    label: str
    declared_length: int
    raw: bytes
    note: str = ""
    logged_hex: str = ""
    command: Optional[CommandAPDU] = None
    response: Optional[ResponseAPDU] = None
    tlv: list[TLVNode] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    @property
    def display_hex(self) -> str:
        return self.logged_hex or self.raw.hex().upper()


@dataclass
class Exchange:
    number: int
    transaction: int
    transaction_exchange: int
    command: APDUEvent
    epoch: Optional[int] = None
    response: Optional[APDUEvent] = None

    @property
    def latency_ms(self) -> Optional[int]:
        if not self.response:
            return None
        delta = self.response.milliseconds - self.command.milliseconds
        return delta if delta >= 0 else delta + 86_400_000


def parse_ber_tlv(data: bytes, base_offset: int = 0) -> tuple[list[TLVNode], list[str]]:
    """Strict BER-TLV parser that preserves nesting and reports every truncation."""
    nodes: list[TLVNode] = []
    errors: list[str] = []
    cursor = 0
    while cursor < len(data):
        start = cursor
        first = data[cursor]
        cursor += 1
        tag_bytes = bytearray([first])
        if first & 0x1F == 0x1F:
            while True:
                if cursor >= len(data):
                    errors.append(f"offset {base_offset + start}: truncated high-tag-number tag")
                    return nodes, errors
                octet = data[cursor]
                cursor += 1
                tag_bytes.append(octet)
                if not octet & 0x80:
                    break
                if len(tag_bytes) > 4:
                    errors.append(f"offset {base_offset + start}: tag exceeds four bytes")
                    return nodes, errors
        if cursor >= len(data):
            errors.append(f"offset {base_offset + start}: missing length for tag {tag_bytes.hex().upper()}")
            return nodes, errors
        first_length = data[cursor]
        cursor += 1
        if first_length & 0x80:
            count = first_length & 0x7F
            if count == 0:
                errors.append(f"offset {base_offset + start}: indefinite length is not valid in EMV")
                return nodes, errors
            if count > 4 or cursor + count > len(data):
                errors.append(f"offset {base_offset + start}: invalid or truncated long-form length")
                return nodes, errors
            length = int.from_bytes(data[cursor:cursor + count], "big")
            cursor += count
        else:
            length = first_length
        if cursor + length > len(data):
            available = len(data) - cursor
            errors.append(
                f"offset {base_offset + start}: tag {tag_bytes.hex().upper()} declares {length} byte(s), "
                f"only {available} remain"
            )
            return nodes, errors
        value = data[cursor:cursor + length]
        header_length = cursor - start
        children: list[TLVNode] = []
        if first & 0x20:
            children, child_errors = parse_ber_tlv(value, base_offset + cursor)
            errors.extend(child_errors)
        nodes.append(TLVNode(tag_bytes.hex().upper(), value, base_offset + start, header_length, children))
        cursor += length
    return nodes, errors


def parse_dol(value: bytes) -> tuple[list[tuple[str, int]], list[str]]:
    items: list[tuple[str, int]] = []
    errors: list[str] = []
    cursor = 0
    while cursor < len(value):
        start = cursor
        tag = bytearray([value[cursor]])
        cursor += 1
        if tag[0] & 0x1F == 0x1F:
            while cursor < len(value):
                octet = value[cursor]
                cursor += 1
                tag.append(octet)
                if not octet & 0x80:
                    break
            else:
                errors.append(f"DOL offset {start}: truncated tag")
                break
        if cursor >= len(value):
            errors.append(f"DOL offset {start}: missing requested length")
            break
        items.append((tag.hex().upper(), value[cursor]))
        cursor += 1
    return items, errors


def flatten(nodes: Iterable[TLVNode]) -> Iterable[TLVNode]:
    for node in nodes:
        yield node
        yield from flatten(node.children)


def clock_ms(text: str) -> int:
    parsed = datetime.strptime(text, "%H:%M:%S.%f")
    return ((parsed.hour * 60 + parsed.minute) * 60 + parsed.second) * 1000 + parsed.microsecond // 1000


def parse_apdu_line(line_number: int, timestamp: str, message: str) -> Optional[APDUEvent]:
    match = APDU_RE.match(message)
    if match:
        compact = match.group("hex").replace(" ", "")
        # Substitute masked nibbles only for structural decoding. Keep the
        # original masked representation for report output.
        decode_hex = re.sub(r"[Xx]", "0", compact)
        try:
            raw = bytes.fromhex(decode_hex)
        except ValueError as exc:
            return APDUEvent(line_number, timestamp, clock_ms(timestamp), match.group("direction"),
                             match.group("kind"), match.group("label"), int(match.group("length")), b"",
                             errors=[f"invalid hexadecimal APDU: {exc}"])
        event = APDUEvent(line_number, timestamp, clock_ms(timestamp), match.group("direction"),
                          match.group("kind"), match.group("label"), int(match.group("length")), raw,
                          match.group("note") or "", compact.upper())
    else:
        legacy = LOGCAT_APDU_RE.search(message)
        if not legacy:
            return None
        raw = bytes.fromhex(re.sub(r"\s", "", legacy.group("hex")))
        event = APDUEvent(line_number, timestamp, clock_ms(timestamp), "unknown", legacy.group("kind"),
                          "legacy logcat", len(raw), raw)
    if event.declared_length != len(event.raw):
        event.errors.append(f"log declares {event.declared_length} byte(s), decoded value has {len(event.raw)}")
    if event.kind == "CAPDU":
        event.command = CommandAPDU.from_bytes(event.raw)
        if event.command is None:
            event.errors.append("invalid ISO 7816 command APDU encoding")
    else:
        if len(event.raw) < 2:
            event.errors.append("response APDU has no complete status word")
        else:
            event.response = ResponseAPDU.from_bytes(event.raw)
            if event.response.data:
                event.tlv, tlv_errors = parse_ber_tlv(event.response.data)
                event.errors.extend(tlv_errors)
    return event


def format_tlv(nodes: list[TLVNode], depth: int = 0) -> list[str]:
    lines: list[str] = []
    for node in nodes:
        info = tag_info(node.tag)
        prefix = "  " * depth
        lines.append(
            f"{prefix}- {node.tag} {info.name}: length={len(node.value)} offset={node.offset} "
            f"value={node.value.hex().upper()}"
        )
        decoded = describe_value(node.tag, node.value)
        if decoded:
            lines.append(f"{prefix}  decoded: {decoded}")
        if info.category == "DOL":
            items, errors = parse_dol(node.value)
            for tag, size in items:
                lines.append(f"{prefix}  requests: {tag} {tag_info(tag).name}, length={size}")
            lines.extend(f"{prefix}  ERROR: {error}" for error in errors)
        lines.extend(format_tlv(node.children, depth + 1))
    return lines


class RelayAnalyzer:
    def __init__(self, source: Path):
        self.source = source
        self.events: list[APDUEvent] = []
        self.exchanges: list[Exchange] = []
        self.log_counts: Counter[str] = Counter()
        self.notable: list[tuple[int, str, str, str]] = []
        self.epochs: list[tuple[int, str, str]] = []
        self.unmatched_responses = 0

    def analyze(self) -> None:
        pending: list[Exchange] = []
        transaction = 0
        transaction_exchange = 0
        transaction_boundary = True
        current_epoch: Optional[int] = None
        for number, raw_line in enumerate(self.source.read_text(encoding="utf-8", errors="replace").splitlines(), 1):
            match = LOG_RE.match(raw_line)
            if not match:
                if raw_line.strip():
                    self.log_counts["unstructured"] += 1
                continue
            timestamp, level, message = match.group("time", "level", "message")
            self.log_counts[level] += 1
            event = parse_apdu_line(number, timestamp, message)
            if event:
                self.events.append(event)
                if event.kind == "CAPDU":
                    if transaction_boundary:
                        transaction += 1
                        transaction_exchange = 0
                        transaction_boundary = False
                    transaction_exchange += 1
                    exchange = Exchange(len(self.exchanges) + 1, transaction,
                                        transaction_exchange, event, current_epoch)
                    self.exchanges.append(exchange)
                    pending.append(exchange)
                elif pending:
                    pending.pop(0).response = event
                else:
                    self.unmatched_responses += 1
                continue
            epoch = re.search(r"Session epoch opened: (\d+) token=(\S+)", message)
            if epoch:
                current_epoch = int(epoch.group(1))
                self.epochs.append((current_epoch, epoch.group(2), timestamp))
                transaction_boundary = True
            elif message.startswith("Session reset ("):
                transaction_boundary = True
            if level in {"WARNING", "ERROR", "CRITICAL"} or any(marker in message for marker in (
                "Malformed frame", "Session reset", "REGISTER from", "RelayServer stopped", "SESSION_BEGIN",
                "MUTATE", "ARQC-CACHED", "GAC-PARSE",
            )):
                self.notable.append((number, timestamp, level, message))

    def report(self) -> str:
        errors = [(event, error) for event in self.events for error in event.errors]
        complete = [exchange for exchange in self.exchanges if exchange.response]
        transaction_count = max((exchange.transaction for exchange in self.exchanges), default=0)
        latencies = [exchange.latency_ms for exchange in complete if exchange.latency_ms is not None]
        status = Counter(
            exchange.response.response.sw.hex().upper()
            for exchange in complete if exchange.response and exchange.response.response
        )
        instruction_flow = [
            exchange.command.command.ins_name
            for exchange in self.exchanges if exchange.command.command
        ]
        flow_findings: list[str] = []
        gpo_cryptogram = False
        for exchange in complete:
            command = exchange.command.command
            response = exchange.response
            if command and command.ins == 0xA8 and response:
                response_tags = {node.tag: node.value for node in flatten(response.tlv)}
                gpo_cryptogram = all(tag in response_tags for tag in ("9F26", "9F27", "9F36"))
                if gpo_cryptogram:
                    cid = response_tags["9F27"][0] & 0xC0 if response_tags["9F27"] else None
                    cryptogram_name = {0x00: "AAC", 0x40: "TC", 0x80: "ARQC"}.get(cid, "unknown AC")
                    flow_findings.append(
                        f"PASS: GPO response generated {cryptogram_name} (9F26/9F27/9F36 present); "
                        "GENERATE AC is not required for this contactless execution path."
                    )
                break
        expected_stages = ["SELECT", "GPO", "READ RECORD"]
        if not gpo_cryptogram:
            expected_stages.append("GENERATE AC")
        stage_positions: list[int] = []
        for stage in expected_stages:
            try:
                stage_positions.append(instruction_flow.index(stage))
            except ValueError:
                flow_findings.append(f"MISSING protocol stage: {stage}")
        if len(stage_positions) == len(expected_stages) and stage_positions == sorted(stage_positions):
            flow_findings.append(f"PASS: observed transaction order is {' -> '.join(expected_stages)}.")
        elif len(stage_positions) == len(expected_stages):
            flow_findings.append(f"FAIL: protocol stages are out of order: {' -> '.join(instruction_flow)}")
        mutation_count = sum("MUTATE" in message for _, _, _, message in self.notable)
        malformed_count = sum("Malformed frame" in message for _, _, _, message in self.notable)
        unregistered_heartbeat_count = sum("HEARTBEAT from unregistered" in message for _, _, _, message in self.notable)
        if mutation_count:
            flow_findings.append(f"NOTICE: {mutation_count} server-side mutation event(s) changed relayed EMV data.")
        if malformed_count:
            flow_findings.append(f"WARNING: {malformed_count} malformed network frame(s) were rejected.")
        if unregistered_heartbeat_count:
            flow_findings.append(
                f"WARNING: {unregistered_heartbeat_count} heartbeat(s) arrived from unregistered endpoints."
            )
        lines = [
            "RELAY PROTOCOL ANALYSIS", "=" * 80,
            f"Input: {self.source.resolve()}",
            f"Generated: {datetime.now().astimezone().isoformat(timespec='seconds')}", "",
            "SUMMARY", "-" * 80,
            f"APDU log events: {len(self.events)} ({sum(e.kind == 'CAPDU' for e in self.events)} CAPDU, "
            f"{sum(e.kind == 'RAPDU' for e in self.events)} RAPDU)",
            f"Exchanges: {len(complete)} complete, {len(self.exchanges) - len(complete)} awaiting RAPDU, "
            f"{self.unmatched_responses} unmatched RAPDU",
            f"Transactions: {transaction_count}",
            f"Session epochs observed: {len(self.epochs)}",
            f"APDU structural errors: {len(errors)}",
            f"Status words: {', '.join(f'{key}={value}' for key, value in sorted(status.items())) or 'none'}",
        ]
        if latencies:
            lines.extend([
                f"Response latency: min={min(latencies)} ms, mean={statistics.mean(latencies):.1f} ms, "
                f"median={statistics.median(latencies):.1f} ms, max={max(latencies)} ms",
            ])
        lines.extend(["", "SESSION EPOCHS", "-" * 80])
        lines.extend(f"{timestamp} epoch={epoch} token={token}" for epoch, token, timestamp in self.epochs)
        if not self.epochs:
            lines.append("None logged. APDU correlation below is based on arrival order.")
        lines.extend(["", "APDU EXCHANGES", "-" * 80])
        displayed_transaction = 0
        for exchange in self.exchanges:
            command = exchange.command
            parsed = command.command
            title = parsed.ins_name if parsed else command.label
            if exchange.transaction != displayed_transaction:
                displayed_transaction = exchange.transaction
                epoch_text = f"epoch={exchange.epoch}" if exchange.epoch is not None else "epoch=unknown"
                lines.extend(["", f"TRANSACTION TX{displayed_transaction} {epoch_text}", "~" * 80])
            exchange_id = f"TX{exchange.transaction}-E{exchange.transaction_exchange}"
            lines.extend(["", f"Exchange {exchange_id}: {title}",
                          f"  CAPDU line={command.line} time={command.timestamp} direction={command.direction} "
                          f"bytes={len(command.raw)} raw={command.display_hex}"])
            if parsed:
                lines.append(f"  header: CLA={parsed.cla:02X} INS={parsed.ins:02X} P1={parsed.p1:02X} P2={parsed.p2:02X} "
                             f"Lc={len(parsed.data)} Le={parsed.le if parsed.le is not None else '-'} "
                             f"extended={'yes' if parsed.extended else 'no'}")
                if parsed.data:
                    lines.append(f"  command data: {parsed.data.hex().upper()}")
                    if parsed.ins == 0xA4:
                        try:
                            lines.append(f"  SELECT target: {parsed.data.decode('ascii')}")
                        except UnicodeDecodeError:
                            lines.append(f"  SELECT AID: {parsed.data.hex().upper()}")
                    elif parsed.ins == 0xA8:
                        nodes, tlv_errors = parse_ber_tlv(parsed.data)
                        lines.extend(f"    {line}" for line in format_tlv(nodes))
                        lines.extend(f"    ERROR: {error}" for error in tlv_errors)
            lines.extend(f"  ERROR: {error}" for error in command.errors)
            response = exchange.response
            if not response or not response.response:
                lines.append("  RAPDU: MISSING")
                continue
            lines.append(f"  RAPDU line={response.line} time={response.timestamp} direction={response.direction} "
                         f"latency={exchange.latency_ms} ms bytes={len(response.raw)} "
                         f"SW={response.response.sw.hex().upper()} raw={response.display_hex}")
            if response.tlv:
                lines.extend(f"    {line}" for line in format_tlv(response.tlv))
            lines.extend(f"  ERROR: {error}" for error in response.errors)
        lines.extend(["", "STRUCTURAL FINDINGS", "-" * 80])
        if errors:
            lines.extend(f"line {event.line} {event.kind}: {error}" for event, error in errors)
        else:
            lines.append("PASS: all logged APDUs, declared lengths, status words, and BER-TLV containers are structurally valid.")
        lines.extend(["", "BEHAVIORAL FINDINGS", "-" * 80, *flow_findings])
        lines.extend(["", "NOTABLE SERVER EVENTS", "-" * 80])
        lines.extend(f"line {line} {timestamp} [{level}] {message}" for line, timestamp, level, message in self.notable)
        if not self.notable:
            lines.append("None.")
        lines.extend(["", "LOG LEVEL COUNTS", "-" * 80,
                      ", ".join(f"{key}={value}" for key, value in sorted(self.log_counts.items())), ""])
        return "\n".join(lines)


def atomic_write(destination: Path, content: str) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name(f".{destination.name}.{os.getpid()}.tmp")
    try:
        temporary.write_text(content, encoding="utf-8")
        os.replace(temporary, destination)
    finally:
        if temporary.exists():
            temporary.unlink()


def main(argv: Optional[list[str]] = None) -> int:
    cli = argparse.ArgumentParser(description="Analyze relay.log and write a detailed EMV protocol report")
    cli.add_argument("input", nargs="?", default="relay.log", type=Path, help="input log (default: relay.log)")
    cli.add_argument("-o", "--output", default=Path("parsed.log"), type=Path, help="report path (default: parsed.log)")
    cli.add_argument("--stdout", action="store_true", help="also print the complete report")
    args = cli.parse_args(argv)
    if not args.input.is_file():
        cli.error(f"input log does not exist or is not a file: {args.input}")
    analyzer = RelayAnalyzer(args.input)
    analyzer.analyze()
    report = analyzer.report()
    try:
        atomic_write(args.output, report)
    except OSError as exc:
        print(f"parser: could not write {args.output}: {exc}", file=sys.stderr)
        return 1
    if args.stdout:
        print(report)
    print(f"Parsed {len(analyzer.events)} APDU events into {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
