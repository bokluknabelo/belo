# -*- coding: utf-8 -*-
# tlv.py
# -*- coding: utf-8 -*-
"""TLV parsing and building - uses protocol.py if available, else fallback."""

from __future__ import annotations
from typing import Optional, List, Tuple
import struct

try:
    from protocol import find_tlv as _proto_find, build_tlv as _proto_build
    from protocol import parse_tlv_list as _proto_parse, replace_tlv as _proto_replace
    _HAS_PROTOCOL = True
except ImportError:
    _HAS_PROTOCOL = False

# --- Fallback implementations (BER-TLV, supports multi-byte tags) ---

def _parse_tag(data: bytes, offset: int) -> Tuple[int, int]:
    if offset >= len(data):
        return -1, offset
    first = data[offset]
    offset += 1
    if (first & 0x1F) != 0x1F:
        return first, offset
    tag = first
    while offset < len(data):
        byte = data[offset]
        tag = (tag << 8) | byte
        offset += 1
        if not (byte & 0x80):
            break
    else:
        return -1, offset
    return tag, offset

def _parse_length(data: bytes, offset: int) -> Tuple[int, int]:
    if offset >= len(data):
        return -1, offset
    first = data[offset]
    offset += 1
    if not (first & 0x80):
        return first, offset
    count = first & 0x7F
    if count == 0 or count > 4 or offset + count > len(data):
        return -1, offset
    length = int.from_bytes(data[offset:offset + count], "big")
    return length, offset + count

def _is_constructed(tag: int) -> bool:
    top = tag
    while top > 0xFF:
        top >>= 8
    return bool(top & 0x20)

if not _HAS_PROTOCOL:
    def find_tlv(data: bytes, target_tag: int) -> Optional[bytes]:
        i = 0
        while i < len(data):
            tag, i = _parse_tag(data, i)
            length, i = _parse_length(data, i)
            if tag < 0 or length < 0 or i + length > len(data):
                return None
            value = data[i:i + length]
            if tag == target_tag:
                return value
            if _is_constructed(tag):
                inner = find_tlv(value, target_tag)
                if inner is not None:
                    return inner
            i += length
        return None

    def build_tlv(tag: int, value: bytes) -> bytes:
        tag_bytes = tag.to_bytes(max(1, (tag.bit_length() + 7) // 8), "big")
        length = len(value)
        if length < 0x80:
            length_bytes = bytes([length])
        else:
            encoded = length.to_bytes((length.bit_length() + 7) // 8, "big")
            length_bytes = bytes([0x80 | len(encoded)]) + encoded
        return tag_bytes + length_bytes + value

    def parse_tlv_list(data: bytes) -> List[Tuple[int, bytes]]:
        result = []
        i = 0
        while i < len(data):
            tag, i = _parse_tag(data, i)
            length, i = _parse_length(data, i)
            if tag < 0 or length < 0 or i + length > len(data):
                break
            result.append((tag, data[i:i + length]))
            i += length
        return result

    def replace_tlv(data: bytes, target_tag: int, new_value: bytes) -> bytes:
        parsed = parse_tlv_list(data)
        mutated = False
        updated = []
        for tag, value in parsed:
            if tag == target_tag:
                updated.append((tag, new_value))
                mutated = True
            elif _is_constructed(tag):
                inner = replace_tlv(value, target_tag, new_value)
                if inner != value:
                    updated.append((tag, inner))
                    mutated = True
                else:
                    updated.append((tag, value))
            else:
                updated.append((tag, value))
        if not mutated:
            return data
        return b"".join(build_tlv(tag, v) for tag, v in updated)
else:
    from protocol import find_tlv, build_tlv, parse_tlv_list, replace_tlv
