# -*- coding: utf-8 -*-
#!/usr/bin/env python3

"""EMV card emulator - connects to relay server, speaks APDUs."""


import socket

import struct

import logging

import sys

import time

from typing import Optional, Tuple


SID_REGISTER = 0x00

SID_CAPDU = 0x04

SID_RAPDU = 0x05

SID_ACK = 0x05

SID_HEARTBEAT = 0x06

SID_CTRL = 0x0F


log = logging.getLogger("Emulator")

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")



def build_frame(sid: int, payload: bytes) -> bytes:

    total = len(payload) + 1

    return struct.pack(">I", total) + bytes([sid]) + payload



def parse_frame(data: bytes) -> Optional[Tuple[int, bytes]]:

    if len(data) < 5:

        return None

    declared = struct.unpack(">I", data[:4])[0]

    if declared != len(data) - 4:

        return None

    return data[4], data[5:]



class Emulator:

    def __init__(self, host: str = "127.0.0.1", port: int = 5566):

        self.host = host

        self.port = port

        self.sock: Optional[socket.socket] = None

        self.running = False


    def connect(self) -> None:

        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

        self.sock.settimeout(2.0)


        # Register as EMULATOR

        self._send_frame(SID_REGISTER, b"EMULATOR")

        ack = self._recv_frame()

        if ack is None or ack[0] != SID_ACK:

            log.error("Failed to register as EMULATOR")

            sys.exit(1)

        log.info("Registered as EMULATOR")


    def _send_frame(self, sid: int, payload: bytes) -> None:

        frame = build_frame(sid, payload)

        self.sock.sendto(frame, (self.host, self.port))


    def _recv_frame(self) -> Optional[Tuple[int, bytes]]:

        try:

            data, _ = self.sock.recvfrom(4096)

            return parse_frame(data)

        except socket.timeout:

            return None


    def send_capdu(self, capdu: bytes) -> Optional[bytes]:

        self._send_frame(SID_CAPDU, capdu)

        while True:

            frame = self._recv_frame()

            if frame is None:

                log.warning("Timeout waiting for RAPDU")

                return None

            sid, payload = frame

            if sid == SID_RAPDU:

                return payload

            if sid == SID_CTRL:

                log.info(f"CTRL: {payload.decode(errors='replace')}")


    def run_interactive(self) -> None:

        self.running = True

        log.info("Interactive mode. Type hex APDU commands (e.g., 00A4040007A000000003101000)")

        while self.running:

            try:

                line = input("capdu> ").strip()

                if not line:

                    continue

                if line.lower() in ("exit", "quit"):

                    break

                capdu = bytes.fromhex(line)

                rapdu = self.send_capdu(capdu)

                if rapdu:

                    print(f"rapdu: {rapdu.hex().upper()}")

                else:

                    print("No response")

            except KeyboardInterrupt:

                break

            except ValueError as e:

                print(f"Bad hex: {e}")


    def close(self) -> None:

        self.running = False

        if self.sock:

            self.sock.close()



def main() -> None:

    import argparse

    parser = argparse.ArgumentParser(description="EMV card emulator")

    parser.add_argument("--host", default="127.0.0.1")

    parser.add_argument("--port", type=int, default=5566)

    parser.add_argument("--apdu", help="Single hex APDU to send, then exit")

    args = parser.parse_args()


    emu = Emulator(host=args.host, port=args.port)

    emu.connect()


    if args.apdu:

        capdu = bytes.fromhex(args.apdu)

        rapdu = emu.send_capdu(capdu)

        if rapdu:

            print(rapdu.hex().upper())

        else:

            print("No response", file=sys.stderr)

    else:

        emu.run_interactive()


    emu.close()



if __name__ == "__main__":

    main()