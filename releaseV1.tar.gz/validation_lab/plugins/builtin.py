from __future__ import annotations

from pathlib import Path
import ast
import json
import re
import socket
import statistics
import struct
import threading
import time

import packet_router
import protocol
import relserver3

from ..core import registry
from ..faults import DeterministicFaultLink, FaultProfile
from ..model import Event, Finding, Status


def finding(key: str, ok: bool, summary: str, evidence: str = "", warn: bool = False,
            recommendation: str = "") -> Finding:
    status = Status.PASS if ok else (Status.WARN if warn else Status.FAIL)
    return Finding(key, status, summary, evidence, recommendation)


@registry.register("startup", "Startup and configuration")
def startup(ctx):
    required = ["relserver3.py", "protocol.py", "packet_router.py", "java/RelayClient.java",
                "java/RelayFrameCodec.java", "java/hce/DefaultEmvKernel.java"]
    missing = [path for path in required if not (ctx.root / path).is_file()]
    for path in required:
        ctx.emit("startup", function="load", result=path,
                 severity="ERROR" if path in missing else "INFO")
    return finding("startup", not missing, "All production dependencies are present" if not missing
                   else f"Missing dependencies: {', '.join(missing)}")


@registry.register("python", "Python server validation")
def python_server(ctx):
    files = ["relserver3.py", "protocol.py", "packet_router.py"]
    errors = []
    for name in files:
        try:
            ast.parse(ctx.source(name), name)
            ctx.emit("python", function="ast.parse", result=name)
        except SyntaxError as exc:
            errors.append(f"{name}:{exc.lineno} {exc.msg}")
    server = relserver3.RelayServer()
    lifecycle = all(hasattr(server, name) for name in
                    ("start", "stop", "_handle_register", "_handle_capdu", "_handle_rapdu"))
    return [finding("python", not errors, "Python sources parse", "; ".join(errors)),
            finding("python", lifecycle, "RelayServer lifecycle surface is complete")]


@registry.register("java", "Java client validation")
def java_client(ctx):
    client = ctx.source("java/RelayClient.java")
    service = ctx.source("java/RelayForegroundService.java")
    reader = ctx.source("java/nfc/ReaderSessionManager.java")
    checks = {
        "typed registration ACK": '"REGISTER".equals(ackKind)' in client,
        "exact sequence lookup": "pendingApdus.get(seq)" in client,
        "wire trace preserves sequence": "traceTxFrame(sid, wireEpoch, seq" in client,
        "APDUs require session barrier": client.count("if (!isAckReceived())") >= 2,
        "reader callback": "handleIncomingCapdu(capdu, seq)" in service,
        "physical transceive": "isoDep.transceive(capdu)" in reader,
        "RAPDU callback": "client.sendRapdu(rapdu, seq)" in reader,
    }
    return [finding("java", value, label) for label, value in checks.items()]


@registry.register("cross_stack", "Cross-stack synchronization")
def cross_stack(ctx):
    sid_source = ctx.source("java/RelaySid.java")
    java_sids = {name: int(value, 16) for name, value in
                 re.findall(r"(REGISTER|CAPDU|RAPDU|ACK|HEARTBEAT|CTRL)\s*=\s*0x([0-9A-Fa-f]+)", sid_source)}
    python_sids = {name: getattr(relserver3, f"SID_{name}") for name in java_sids}
    mismatches = {name: (python_sids[name], value) for name, value in java_sids.items()
                  if python_sids[name] != value}
    java_limit = re.search(r"MAX_FRAME_SIZE\s*=\s*(\d+)", ctx.source("java/RelayFrameCodec.java"))
    limit_ok = bool(java_limit and int(java_limit.group(1)) == relserver3.MAX_FRAME_SIZE)
    return [finding("cross_stack", not mismatches, "SID constants align", str(mismatches)),
            finding("cross_stack", limit_ok, "Frame-size limits align")]


@registry.register("protocol", "Protocol and serialization")
def protocol_validation(ctx):
    vectors = [
        bytes.fromhex("00A40400"), bytes.fromhex("00B2010C00"),
        bytes.fromhex("00A4040002A00000"), bytes.fromhex("00DA00000000030102030010"),
    ]
    bad = []
    for raw in vectors:
        parsed = protocol.CommandAPDU.from_bytes(raw)
        if parsed is None or parsed.to_bytes() != raw:
            bad.append(raw.hex().upper())
        ctx.emit("protocol", packet="CAPDU", apdu=raw.hex().upper(),
                 function="CommandAPDU.roundtrip", result="FAIL" if raw.hex().upper() in bad else "PASS")
    frame = relserver3.build_frame(relserver3.SID_CAPDU, vectors[0], 42, epoch=9)
    frame_ok = relserver3.parse_frame(frame) == (relserver3.SID_CAPDU, 9, 42, vectors[0])
    return [finding("protocol", not bad, "APDU cases round-trip", ",".join(bad)),
            finding("protocol", frame_ok, "Frame encoding round-trips with epoch 9 and sequence 42")]


def registered_server(ctx):
    server = relserver3.RelayServer()
    server.reader_addr = ("reader", 1)
    server.emulator_addr = ("emulator", 2)
    sent = []
    server._send_frame = lambda addr, sid, payload: sent.append((addr, sid, payload))
    return server, sent


@registry.register("session", "Session lifecycle")
def session(ctx):
    server, sent = registered_server(ctx)
    server.state.selected_aid = b"stale"
    server.state.pending_capdu = b"stale"
    server._handle_ctrl(b"CARD_REMOVED", server.reader_addr)
    clean = server.state.selected_aid is None and server.state.pending_capdu is None
    server._handle_register(b"READER", ("replacement", 3))
    replaced = server.reader_addr == ("replacement", 3)
    return [finding("session", clean, "Card removal destroys transaction state"),
            finding("session", replaced, "Peer replacement establishes a clean owner")]


@registry.register("apdu", "APDU flow")
def apdu(ctx):
    server, sent = registered_server(ctx)
    capdu = bytes.fromhex("00A4040000")
    server._handle_capdu(relserver3.build_exchange_payload(7, capdu), server.emulator_addr)
    forwarded = sent and relserver3.parse_exchange_payload(sent[0][2]) == (7, capdu)
    sent.clear()
    server._handle_rapdu(relserver3.build_exchange_payload(7, b"\x90\x00"), server.reader_addr)
    returned = sent and relserver3.parse_exchange_payload(sent[0][2]) == (7, b"\x90\x00")
    consumed = server.state.pending_capdu is None
    for direction, value in (("EMU>RDR", capdu), ("RDR>EMU", b"\x90\x00")):
        ctx.emit("apdu", direction=direction, session="7", apdu=value.hex().upper(), result="forwarded")
    return [finding("apdu", forwarded, "CAPDU preserves exchange ID"),
            finding("apdu", returned and consumed, "RAPDU matches and consumes pending exchange")]


@registry.register("network", "Network behavior")
def network(ctx):
    raw = relserver3.build_frame(relserver3.SID_HEARTBEAT, b"", 0)
    strict = relserver3.parse_frame(raw + b"x") is None
    bounded = len(raw) <= relserver3.MAX_FRAME_SIZE
    server, sent = registered_server(ctx)
    server._handle_heartbeat(b"", ("unknown", 9))
    admission = not sent
    return [finding("network", strict, "Trailing bytes invalidate declared frame length"),
            finding("network", bounded, "Frame respects shared maximum"),
            finding("network", admission, "Unknown heartbeat is not acknowledged")]


@registry.register("timing", "Timing analysis")
def timing(ctx):
    samples = []
    raw = bytes.fromhex("00A4040000")
    for _ in range(1000):
        start = time.perf_counter_ns()
        relserver3.parse_frame(relserver3.build_frame(relserver3.SID_CAPDU, raw, 1))
        samples.append((time.perf_counter_ns() - start) / 1_000_000)
    p95 = sorted(samples)[int(len(samples) * .95)]
    ctx.emit("timing", function="frame_roundtrip", result=f"p95={p95:.4f}ms",
             metadata={"min_ms": min(samples), "mean_ms": statistics.mean(samples), "p95_ms": p95})
    return finding("timing", p95 < 1.0, f"Frame codec p95 {p95:.4f}ms", warn=p95 >= 1.0)


@registry.register("threads", "Thread synchronization")
def threads(ctx):
    client = ctx.source("java/RelayClient.java")
    reader = ctx.source("java/nfc/ReaderSessionManager.java")
    service = ctx.source("java/hce/RemoteHostApduService.java")
    checks = {
        "socket ownership lock": "synchronized (socketLock)" in client,
        "single APDU exchange semaphore": "apduExchangeSlot" in client,
        "serialized physical-card worker": "newSingleThreadExecutor" in reader,
        "stale HCE generation guard": "responseGeneration" in service,
        "session epoch barrier": "awaitSessionReady" in client,
    }
    return [finding("threads", ok, label) for label, ok in checks.items()]


@registry.register("state", "State-machine validator")
def state(ctx):
    enum_source = ctx.source("java/RelayState.java")
    states = set(re.findall(r"^\s*(IDLE|CONNECTING|REGISTERED|READY|ACTIVE|RESETTING|ERROR)\s*,?", enum_source, re.M))
    required = {"IDLE", "CONNECTING", "REGISTERED", "READY", "ACTIVE", "RESETTING", "ERROR"}
    service = ctx.source("java/RelayForegroundService.java")
    reached = set(re.findall(r"transitionTo\(RelayState\.([A-Z_]+)\)", service)) | {"IDLE"}
    dead = states - reached - {"ERROR"}
    return [finding("state", states == required, "Expected Java states are declared", str(states)),
            finding("state", not dead, "No unreachable declared states", str(dead), warn=bool(dead))]


@registry.register("callbacks", "Callback validator")
def callbacks(ctx):
    listener = ctx.source("java/RelayEventListener.java")
    client = ctx.source("java/RelayClient.java")
    service = ctx.source("java/RelayForegroundService.java")
    callbacks = re.findall(r"default void (on\w+)\(", listener)
    missing = [name for name in callbacks if name not in client or name not in service]
    return finding("callbacks", not missing, "Callbacks have producer and consumer mappings",
                   ", ".join(missing), warn=bool(missing))


@registry.register("objects", "Object lifecycle")
def objects(ctx):
    runtime = ctx.source("java/RelayRuntime.java")
    reader = ctx.source("java/nfc/ReaderSessionManager.java")
    server = ctx.source("relserver3.py")
    checks = {
        "runtime owns singleton dependencies": "static final RelayRuntime INSTANCE" in runtime,
        "IsoDep closes": "isoDep.close()" in reader,
        "server socket closes in finally": "finally:" in server and "self.stop()" in server,
        "router transport clears": "_sync_router_transport" in server,
    }
    return [finding("objects", ok, label) for label, ok in checks.items()]


@registry.register("config", "Configuration validator")
def config(ctx):
    java_codec = ctx.source("java/RelayFrameCodec.java")
    timeout_source = ctx.source("java/hce/RemoteHostApduService.java")
    frame = re.search(r"MAX_FRAME_SIZE\s*=\s*(\d+)", java_codec)
    deadline = re.search(r"HCE_RESPONSE_DEADLINE_MS\s*=\s*(\d+)L", timeout_source)
    return [finding("config", bool(frame and int(frame.group(1)) == relserver3.MAX_FRAME_SIZE),
                    "Shared frame size is configured"),
            finding("config", bool(deadline and int(deadline.group(1)) <= 5000),
                    "HCE deadline is bounded")]


@registry.register("stress", "Deterministic stress")
def stress(ctx):
    count = int(ctx.options.get("stress_count", 10000))
    failures = 0
    for seq in range(1, count + 1):
        value = struct.pack(">I", seq)
        parsed = relserver3.parse_frame(relserver3.build_frame(relserver3.SID_CAPDU, value, seq))
        if parsed != (relserver3.SID_CAPDU, 0, seq & 0xFFFF, value):
            failures += 1
    return finding("stress", failures == 0, f"{count} correlated frames validated", f"failures={failures}")


@registry.register("faults", "Fault injection")
def faults(ctx):
    frame = relserver3.build_frame(relserver3.SID_CAPDU, b"test", 9)
    link = DeterministicFaultLink(FaultProfile(loss=.2, corruption=.2, duplication=.2,
                                               delay_steps=1, drop_ack=True, seed=7))
    outputs = []
    for _ in range(20):
        outputs.extend(link.transmit(frame))
    outputs.extend(link.flush())
    detected = sum(relserver3.parse_frame(value) is None for value in outputs)
    ctx.emit("fault", function="deterministic_link", result=f"delivered={len(outputs)} corrupt={detected}")
    return finding("faults", len(outputs) > 0 and detected > 0,
                   "Loss, delay, duplication and corruption executed deterministically",
                   f"delivered={len(outputs)} detected_corruption={detected}")
