import unittest

from guard import (
    Guard, Phase, SessionState, SW_9000,
    INS_GENERATE_AC, INS_SELECT,
)


class GuardAdvanceTests(unittest.TestCase):
    def test_repeated_read_record_phase_is_sticky(self):
        guard = Guard()
        guard.record_sw(SW_9000)

        for phase in (
            Phase.PPSE_SELECTED,
            Phase.AID_SELECTED,
            Phase.GPO_RESPONDED,
            Phase.READ_RECORD_DONE,
        ):
            allowed, _ = guard.advance(phase)
            self.assertTrue(allowed)

        allowed, reason = guard.advance(Phase.READ_RECORD_DONE)

        self.assertTrue(allowed)
        self.assertEqual(guard.phase, Phase.READ_RECORD_DONE)
        self.assertEqual(reason, "Phase READ_RECORD_DONE already active (sticky)")

    def test_sticky_read_record_still_requires_success_status(self):
        guard = Guard()
        guard.phase = Phase.READ_RECORD_DONE
        guard.record_sw(b"\x6a\x83")

        allowed, _ = guard.advance(Phase.READ_RECORD_DONE)

        self.assertFalse(allowed)

    def test_other_phases_are_not_implicitly_sticky(self):
        guard = Guard()
        guard.phase = Phase.ARQC_RECEIVED
        guard.record_sw(SW_9000)

        allowed, _ = guard.advance(Phase.ARQC_RECEIVED)

        self.assertFalse(allowed)

    def test_forge_is_valid_after_external_authentication(self):
        guard = Guard()
        guard.phase = Phase.EXTERNAL_AUTH_DONE
        session = SessionState(arpc_forge_enabled=True, second_ae_pending=True)
        session.arqc_cache.atc = b"\x00\x01"
        session.arqc_cache.ac = b"12345678"
        session.arqc_cache.iad = b"iad"

        allowed, _ = guard.check_forge(session)

        self.assertTrue(allowed)

    def test_undefined_mutation_and_intercept_fail_closed(self):
        guard = Guard()
        session = SessionState(arpc_rewrite_enabled=True)

        self.assertFalse(guard.check_mutation(INS_SELECT, session)[0])
        self.assertFalse(guard.check_intercept(0xCA, session)[0])

    def test_generate_ac_rewrite_requires_online_phase(self):
        guard = Guard()
        session = SessionState(arpc_rewrite_enabled=True)

        self.assertFalse(guard.check_intercept(INS_GENERATE_AC, session)[0])
        guard.phase = Phase.ARQC_RECEIVED
        self.assertTrue(guard.check_intercept(INS_GENERATE_AC, session)[0])


if __name__ == "__main__":
    unittest.main()
