# -*- coding: utf-8 -*-
"""pytest configuration for relay server tests."""

import pytest
import socket
import time
import threading
from typing import Generator, Tuple

from relserver import RelayServer
from protocol import CommandAPDU, ResponseAPDU

@pytest.fixture(scope="function")
def relay_server() -> Generator[RelayServer, None, None]:
    """Start a RelayServer on a dynamic port for testing."""
    import random
    port = random.randint(16000, 17000)
    server = RelayServer(host="127.0.0.1", port=port)
    thread = threading.Thread(target=server.start, daemon=True)
    thread.start()
    time.sleep(0.1)  # Wait for server to bind
    yield server
    server.stop()

@pytest.fixture(scope="function")
def emulator_socket(relay_server: RelayServer) -> Generator[socket.socket, None, None]:
    """Create a UDP socket registered as EMULATOR."""
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.settimeout(2.0)

    from relserver import build_frame, SID_REGISTER, SID_ACK, parse_frame
    # Register as EMULATOR
    sock.sendto(build_frame(SID_REGISTER, b"EMULATOR"), ("127.0.0.1", relay_server.port))
    data, _ = sock.recvfrom(4096)
    parsed = parse_frame(data)
    assert parsed is not None and parsed[0] == SID_ACK, "Failed to register EMULATOR"
    yield sock
    sock.close()

@pytest.fixture(scope="function")
def reader_socket(relay_server: RelayServer) -> Generator[socket.socket, None, None]:
    """Create a UDP socket registered as READER."""
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.settimeout(2.0)

    from relserver import build_frame, SID_REGISTER, SID_ACK, parse_frame
    sock.sendto(build_frame(SID_REGISTER, b"READER"), ("127.0.0.1", relay_server.port))
    data, _ = sock.recvfrom(4096)
    parsed = parse_frame(data)
    assert parsed is not None and parsed[0] == SID_ACK, "Failed to register READER"
    yield sock
    sock.close()

@pytest.fixture
def sample_select_apdu() -> bytes:
    """Visa SELECT PPSE command."""
    return bytes.fromhex("00A404000E325041592E5359532E444446303100")

@pytest.fixture
def sample_gpo_apdu() -> bytes:
    """GENERATE PROCESSING OPTIONS command."""
    return bytes.fromhex("80A8000023831F0102000000000000000000000000000000000000000000000000000000000000000000000000")

@pytest.fixture
def sample_verify_apdu() -> bytes:
    """VERIFY command with PIN."""
    return bytes.fromhex("002000008008FFFFFFFFFFFFFFFF")

@pytest.fixture
def sample_gac_apdu() -> bytes:
    """GENERATE AC command (first)."""
    return bytes.fromhex("80AE00002300000000000000000000000000000000000000000000000000000000000000000000000000000000000000")