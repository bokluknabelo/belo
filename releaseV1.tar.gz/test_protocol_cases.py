import pytest

from protocol import CommandAPDU


@pytest.mark.parametrize("raw", [
    bytes.fromhex("00A40400"),
    bytes.fromhex("00B2010C00"),
    bytes.fromhex("00A4040002A000"),
    bytes.fromhex("00A4040002A00000"),
    bytes.fromhex("00CA0000000000"),
    bytes.fromhex("00DA0000000003010203"),
    bytes.fromhex("00DA00000000030102030010"),
])
def test_command_apdu_round_trip(raw):
    parsed = CommandAPDU.from_bytes(raw)
    assert parsed is not None
    assert parsed.to_bytes() == raw


@pytest.mark.parametrize("raw", [
    b"\x00\xA4\x04",
    bytes.fromhex("00A4040002A0"),
    bytes.fromhex("00DA00000000030102"),
    bytes.fromhex("00DA000000000301020300"),
])
def test_malformed_command_apdu_is_rejected(raw):
    assert CommandAPDU.from_bytes(raw) is None
