import socket

import packet_router
import relserver3
import relserver


class FakeSocket:
    def __init__(self):
        self.closed = False

    def setsockopt(self, *args):
        pass

    def bind(self, address):
        self.address = address

    def settimeout(self, timeout):
        self.timeout = timeout

    def close(self):
        self.closed = True


def make_registered_server():
    server = relserver3.RelayServer()
    server.reader_addr = ("reader", 1)
    server.emulator_addr = ("emulator", 2)
    sent = []
    server._send_frame = lambda addr, sid, payload: sent.append((addr, sid, payload))
    return server, sent


def test_start_always_closes_socket(monkeypatch):
    fake = FakeSocket()
    monkeypatch.setattr(socket, "socket", lambda *args: fake)
    server = relserver3.RelayServer()
    monkeypatch.setattr(server, "_run_loop", lambda: None)

    server.start()

    assert fake.closed
    assert server.sock is None
    assert server.running is False
    assert packet_router._singleton._sock is None


def test_first_gac_is_forwarded_and_second_armed_gac_is_forged(monkeypatch):
    server, sent = make_registered_server()
    gac = bytes.fromhex("80AE800000")
    server.state.gpo_template = relserver3.TEMPLATE_77
    server.state.tvr_mutation_enabled = False
    server.state.arpc_rewrite_enabled = False
    server.state.arpc_forge_enabled = True

    server._handle_capdu(gac, server.emulator_addr)

    assert sent == [(server.reader_addr, relserver3.SID_CAPDU, gac)]
    assert server.state.pending_capdu == gac

    arqc = bytes.fromhex(
        "77299F2701809F360201C79F26085DC027596F639E23"
        "9F10120110A00302A400000000FFFFFFFFFFFFFFFF9000"
    )
    sent.clear()
    server._handle_rapdu(arqc, server.reader_addr)
    assert server.state.second_ae_pending is True

    sent.clear()
    monkeypatch.setattr(server, "_handle_second_gac_forge",
                        lambda payload: sent.append(("forged", payload)))
    server._handle_capdu(gac, server.emulator_addr)

    assert sent == [("forged", gac)]


def test_capdu_mitm_runs_before_cache_and_forward(monkeypatch):
    server, sent = make_registered_server()
    original = bytes.fromhex("00A4040000")
    changed = bytes.fromhex("00A4000000")
    router = packet_router._singleton
    old_mode = router.get_mode()
    old_hooks = dict(router._mitm_hooks)
    try:
        router._mitm_hooks.clear()
        packet_router.register_mitm_hook(
            "capdu-test",
            lambda direction, payload, session, log: changed
            if direction == "capdu" else payload,
        )
        packet_router.set_mode(packet_router.MODE_MITM)

        server._handle_capdu(original, server.emulator_addr)

        assert sent[-1] == (server.reader_addr, relserver3.SID_CAPDU, changed)
        assert server.state.pending_capdu == changed
        assert packet_router.session["last_capdu"] == changed
    finally:
        router._mitm_hooks.clear()
        router._mitm_hooks.update(old_hooks)
        packet_router.set_mode(old_mode)
        packet_router.reset_session()


def test_card_and_peer_boundaries_reset_state():
    server, _ = make_registered_server()
    server.state.selected_aid = b"old-card"
    server.state.pending_capdu = b"old-command"

    server._handle_ctrl(b"CARD_REMOVED", server.reader_addr)

    assert server.state.selected_aid is None
    assert server.state.pending_capdu is None
    assert server.state.card_present is False

    server.state.selected_aid = b"old-card"
    server._handle_register(b"DEREGISTER", server.reader_addr)

    assert server.reader_addr is None
    assert server.state.selected_aid is None
    assert packet_router._singleton._reader_addr is None


def test_replacing_registered_peer_resets_transaction():
    server, _ = make_registered_server()
    server.state.selected_aid = b"old-card"

    server._handle_register(b"READER", ("new-reader", 3))

    assert server.reader_addr == ("new-reader", 3)
    assert server.state.selected_aid is None
    assert packet_router._singleton._reader_addr == ("new-reader", 3)


def test_transport_state_has_one_owner():
    server, _ = make_registered_server()
    server.sock = object()
    server._sync_router_transport()

    router = packet_router._singleton
    assert router._sock is server.sock
    assert router._reader_addr == server.reader_addr
    assert router._emulator_addr == server.emulator_addr


def test_role_reversed_apdus_are_rejected():
    server, sent = make_registered_server()

    server._handle_capdu(bytes.fromhex("00A4040000"), server.reader_addr)
    server._handle_rapdu(bytes.fromhex("9000"), server.emulator_addr)

    assert sent == []


def test_reader_rapdu_consumes_pending_request():
    server, sent = make_registered_server()
    server.state.pending_capdu = bytes.fromhex("00A4040000")

    server._handle_rapdu(bytes.fromhex("9000"), server.reader_addr)

    assert sent[-1] == (server.emulator_addr, relserver3.SID_RAPDU, b"\x90\x00")
    assert server.state.pending_capdu is None


def test_unregistered_heartbeat_is_not_acknowledged():
    server, sent = make_registered_server()

    server._handle_heartbeat(b"", ("unknown", 9))

    assert sent == []


def test_java_frame_format_round_trip_preserves_sequence():
    frame = relserver.build_frame(relserver.SID_CAPDU, b"\x00\xA4", 0x1234)
    assert frame == bytes.fromhex("0000000504123400A4")
    assert relserver.parse_frame(frame) == (relserver.SID_CAPDU, 0x1234, b"\x00\xA4")


def test_correlated_apdu_round_trip_uses_same_exchange_id():
    server = relserver.RelayServer()
    server.reader_addr = ("reader", 1)
    server.emulator_addr = ("emulator", 2)
    sent = []
    server._send_frame = lambda addr, sid, payload: sent.append((addr, sid, payload))

    server._handle_packet(
        relserver.build_frame(relserver.SID_CAPDU, bytes.fromhex("00A4040000"), 17),
        server.emulator_addr,
    )
    assert relserver.parse_exchange_payload(sent[0][2]) == (17, bytes.fromhex("00A4040000"))

    sent.clear()
    server._handle_packet(
        relserver.build_frame(relserver.SID_RAPDU, bytes.fromhex("9000"), 17),
        server.reader_addr,
    )
    assert relserver.parse_exchange_payload(sent[0][2]) == (17, bytes.fromhex("9000"))
    assert server.state.pending_capdu is None


def test_oversized_frame_is_not_sent():
    server = relserver3.RelayServer()
    sent = []
    server.sock = type("Socket", (), {"sendto": lambda self, frame, addr: sent.append(frame)})()
    server._send_frame(("peer", 1), relserver3.SID_CTRL,
                       b"x" * (relserver3.MAX_FRAME_PAYLOAD + 1))
    assert sent == []


def test_large_control_response_is_chunked_with_bounded_frames():
    server = relserver3.RelayServer()
    sent = []
    server._send_frame = lambda addr, sid, payload: sent.append((sid, payload))
    server._send_ctrl_bytes(("peer", 1), b"x" * 20000)
    assert len(sent) > 1
    assert all(sid == relserver3.SID_CTRL for sid, _ in sent)
    assert all(payload.startswith(b"CHUNK ") for _, payload in sent)
    assert all(len(payload) <= relserver3.MAX_FRAME_PAYLOAD for _, payload in sent)


def test_session_epoch_barrier_is_idempotent_and_rejects_stale_apdu():
    server = relserver3.RelayServer()
    server.reader_addr = ("reader", 1)
    server.emulator_addr = ("emulator", 2)
    sent = []
    server._send_frame = lambda addr, sid, payload: sent.append((addr, sid, payload))

    begin = relserver3.build_frame(relserver3.SID_CTRL, b"SESSION_BEGIN 77", epoch=0)
    server._handle_packet(begin, server.emulator_addr)
    epoch = server.active_epoch
    assert epoch > 0
    assert any(payload == f"SESSION_ACK {epoch} 77".encode() for _, _, payload in sent)

    sent.clear()
    server._handle_packet(begin, server.emulator_addr)
    assert server.active_epoch == epoch

    stale = relserver3.build_frame(relserver3.SID_CAPDU, bytes.fromhex("00A4040000"),
                                   seq=1, epoch=epoch - 1)
    sent.clear()
    server._handle_packet(stale, server.emulator_addr)
    assert not any(sid == relserver3.SID_CAPDU for _, sid, _ in sent)
