#!/usr/bin/env python3
"""Convenience entry point for the interactive Relay Protocol Laboratory."""

from validation_lab.__main__ import main


if __name__ == "__main__":
    raise SystemExit(main())
