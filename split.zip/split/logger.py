# -*- coding: utf-8 -*-
# logger.py
# -*- coding: utf-8 -*-
"""Logging configuration, PAN masking, APDU history."""

from __future__ import annotations
import os
import logging
import time
import json
from collections import deque
from threading import Lock
from logging.handlers import RotatingFileHandler
from typing import Dict, Any

from constants import LOG_FILE, LOG_LEVEL, APDU_HISTORY_SIZE, INS_MAP

log = logging.getLogger("RelayServer")

# --- APDU history ---
_apdu_history: deque = deque(maxlen=APDU_HISTORY_SIZE)
_apdu_history_lock = Lock()

# --- PAN masking ---
def _mask_sensitive_hex(hex_str: str) -> str:
    """Mask PAN digits in EMV tags 5A and 57 while retaining BIN/last four."""
    try:
        raw = bytes.fromhex(hex_str)
    except ValueError:
        return hex_str
    chars = list(hex_str.upper())

    def mask_value(value: bytes, byte_offset: int, track2: bool) -> None:
        digits = value.hex().upper()
        pan_end = digits.find("D") if track2 else len(digits.rstrip("F"))
        if pan_end < 0:
            pan_end = len(digits)
        for index in range(6, max(6, pan_end - 4)):
            chars[byte_offset * 2 + index] = "X"

    def scan(data: bytes, base: int = 0) -> None:
        i = 0
        while i < len(data):
            first = data[i]
            tag = first
            i += 1
            if first & 0x1F == 0x1F:
                while i < len(data):
                    byte = data[i]
                    tag = (tag << 8) | byte
                    i += 1
                    if not byte & 0x80:
                        break
            if i >= len(data):
                return
            length = data[i]
            i += 1
            if length & 0x80:
                count = length & 0x7F
                if not count or i + count > len(data):
                    return
                length = int.from_bytes(data[i:i + count], "big")
                i += count
            if i + length > len(data):
                return
            value = data[i:i + length]
            if tag in (0x5A, 0x57):
                mask_value(value, base + i, tag == 0x57)
            elif first & 0x20:
                scan(value, base + i)
            i += length

    scan(raw)
    return "".join(chars)

def _record_apdu(direction: str, kind: str, ins_name: str,
                 payload: bytes, note: str = "") -> None:
    hex_str = _mask_sensitive_hex(payload.hex().upper())
    entry: Dict[str, Any] = {
        "ts": round(time.time(), 3),
        "direction": direction, "kind": kind, "ins": ins_name,
        "hex": hex_str, "len": len(payload), "note": note,
    }
    with _apdu_history_lock:
        _apdu_history.append(entry)
    suffix = f" [{note}]" if note else ""
    log.debug(f"APDU {direction} {kind} {ins_name} len={len(payload)}: {hex_str}{suffix}")

def configure_logging() -> None:
    """Attach runtime handlers once."""
    # Otherwise this named logger inherits the root WARNING level and drops
    # successful connection messages before they can reach either handler.
    log.setLevel(logging.DEBUG)
    if any(getattr(handler, "_relay_runtime_handler", False) for handler in log.handlers):
        return
    formatter = logging.Formatter(
        "%(asctime)s.%(msecs)03d [%(levelname)s] %(message)s", datefmt="%H:%M:%S")
    stdout = logging.StreamHandler()
    stdout._relay_runtime_handler = True
    stdout.setFormatter(formatter)
    stdout.setLevel(getattr(logging, LOG_LEVEL, logging.INFO))
    log.addHandler(stdout)
    try:
        file_handler = RotatingFileHandler(LOG_FILE, maxBytes=5 * 1024 * 1024, backupCount=5)
        file_handler._relay_runtime_handler = True
        file_handler.setFormatter(formatter)
        file_handler.setLevel(logging.DEBUG)
        log.addHandler(file_handler)
        log.info(f"File logging enabled: {LOG_FILE}")
    except OSError as exc:
        log.warning(f"Could not open log file {LOG_FILE}: {exc} - stdout only")

    # Check for concatenated module files
    try:
        import protocol as _proto_check
        if hasattr(_proto_check, "PacketRouter"):
            raise ImportError("protocol.py and packet_router.py must be separate files")
    except ImportError:
        pass
    try:
        import packet_router as _pr_check
        if hasattr(_pr_check, "CommandAPDU"):
            raise ImportError("protocol.py and packet_router.py must be separate files")
    except ImportError:
        pass

# --- Convenience access for history ---
def get_apdu_history(n: int = 20) -> list:
    with _apdu_history_lock:
        return list(_apdu_history)[-n:]
