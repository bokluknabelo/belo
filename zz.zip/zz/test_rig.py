# -*- coding: utf-8 -*-
"""
Extensive test suite for the UDP EMV relay + high-offline emulator.
Covers: imports, constants, JSON logging, peer state, timeout sweep,
emulator APDU dispatch, relay SID routing, CAPDU forwarding,
RAPDU wrapping, emulator timeout, and full end-to-end flow.
"""
import io
import json
import logging
import socket
import struct
import subprocess
import sys
import threading
import time
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

import relserver2
import emulator

# ══════════════════════════════════════════════════════════════
# SECTION 1 - IMPORTS & MODULE STRUCTURE
# ══════════════════════════════════════════════════════════════
class TestImports:
    def test_relay_imports_cleanly(self):
        assert hasattr(relserver2, "_main_loop")
        assert hasattr(relserver2, "_peer_update")
        assert hasattr(relserver2, "_peer_timeout_sweep")
        assert hasattr(relserver2, "_forward_to_emulator")
        assert hasattr(relserver2, "JsonFormatter")
        assert hasattr(relserver2, "_setup_logging")

    def test_emulator_imports_cleanly(self):
        assert hasattr(emulator, "serve")
        assert hasattr(emulator, "pick_response")
        assert hasattr(emulator, "FCI")
        assert hasattr(emulator, "GPO")
        assert hasattr(emulator, "READ_REC")

# ══════════════════════════════════════════════════════════════
# SECTION 2 - PROTOCOL CONSTANTS
# ══════════════════════════════════════════════════════════════
class TestProtocolConstants:
    def test_sid_values(self):
        assert relserver2.SID_RAW == 0x00
        assert relserver2.SID_REGISTER == 0x01
        assert relserver2.SID_CAPDU == 0x02
        assert relserver2.SID_RAPDU == 0x03
        assert relserver2.SID_ACK == 0x04
        assert relserver2.SID_HEARTBEAT == 0x05
        assert relserver2.SID_CTRL == 0x06

    def test_role_flags(self):
        assert relserver2.ROLE_EMULATOR_FLAG == 0x01
        assert relserver2.ROLE_READER_FLAG == 0x02

    def test_sid_values_unique(self):
        sids = [
            relserver2.SID_RAW, relserver2.SID_REGISTER, relserver2.SID_CAPDU,
            relserver2.SID_RAPDU, relserver2.SID_ACK, relserver2.SID_HEARTBEAT,
            relserver2.SID_CTRL,
        ]
        assert len(set(sids)) == len(sids)

# ══════════════════════════════════════════════════════════════
# SECTION 3 - JSON LOGGING
# ══════════════════════════════════════════════════════════════
class TestJsonFormatter:
    def _make_record(self, msg="hello", extra=None, level=logging.INFO):
        record = logging.LogRecord(
            name="test", level=level, pathname=__file__, lineno=1,
            msg=msg, args=(), exc_info=None,
        )
        if extra:
            for k, v in extra.items():
                setattr(record, k, v)
        return record

    def test_basic_fields(self):
        fmt = relserver2.JsonFormatter()
        rec = self._make_record("event")
        out = json.loads(fmt.format(rec))
        assert out["msg"] == "event"
        assert out["lvl"] == "INFO"
        assert out["logger"] == "test"
        assert "ts" in out

    def test_extra_fields_merged(self):
        fmt = relserver2.JsonFormatter()
        rec = self._make_record("event", extra={"peer_ip": "1.2.3.4", "role": "READER"})
        out = json.loads(fmt.format(rec))
        assert out["peer_ip"] == "1.2.3.4"
        assert out["role"] == "READER"

    def test_exception_captured(self):
        fmt = relserver2.JsonFormatter()
        try:
            raise ValueError("boom")
        except ValueError:
            rec = logging.LogRecord(
                name="test", level=logging.ERROR, pathname=__file__, lineno=1,
                msg="fail", args=(), exc_info=sys.exc_info(),
            )
        out = json.loads(fmt.format(rec))
        assert "exc" in out
        assert "ValueError" in out["exc"]

    def test_setup_logging_configures_root(self):
        relserver2._setup_logging("DEBUG")
        root = logging.getLogger()
        assert root.level == logging.DEBUG
        assert any(isinstance(h.formatter, relserver2.JsonFormatter) for h in root.handlers)

# ══════════════════════════════════════════════════════════════
# SECTION 4 - PEER STATE MACHINE
# ══════════════════════════════════════════════════════════════
class TestPeerState:
    def test_new_peer_registered(self, reset_relay_state):
        addr = ("10.0.0.1", 1234)
        relserver2._peer_update(addr, "READER")
        assert addr in relserver2._peers
        assert relserver2._peers[addr]["role"] == "READER"

    def test_existing_peer_timestamp_refreshed(self, reset_relay_state):
        addr = ("10.0.0.2", 5678)
        relserver2._peer_update(addr, "EMULATOR")
        first_ts = relserver2._peers[addr]["last"]
        time.sleep(0.01)
        relserver2._peer_update(addr)
        assert relserver2._peers[addr]["last"] > first_ts

    def test_role_resolved_from_unknown(self, reset_relay_state):
        addr = ("10.0.0.3", 9999)
        relserver2._peer_update(addr)  # UNKNOWN first
        assert relserver2._peers[addr]["role"] == "UNKNOWN"
        relserver2._peer_update(addr, "READER")
        assert relserver2._peers[addr]["role"] == "READER"

    def test_role_not_overwritten_once_set(self, reset_relay_state):
        addr = ("10.0.0.4", 1111)
        relserver2._peer_update(addr, "READER")
        relserver2._peer_update(addr, "EMULATOR")  # should be ignored
        assert relserver2._peers[addr]["role"] == "READER"

# ══════════════════════════════════════════════════════════════
# SECTION 5 - TIMEOUT SWEEP
# ══════════════════════════════════════════════════════════════
class TestTimeoutSweep:
    def test_dead_peer_removed(self, reset_relay_state):
        addr = ("10.0.0.5", 2222)
        with relserver2._peers_lock:
            relserver2._peers[addr] = {"role": "READER", "last": time.time() - 100}

        # Run one sweep iteration by hand
        now = time.time()
        with relserver2._peers_lock:
            dead = [
                a for a, info in relserver2._peers.items()
                if now - info["last"] > 45
            ]
            for a in dead:
                relserver2._peers.pop(a, None)

        assert addr not in relserver2._peers

    def test_fresh_peer_preserved(self, reset_relay_state):
        addr = ("10.0.0.6", 3333)
        with relserver2._peers_lock:
            relserver2._peers[addr] = {"role": "EMULATOR", "last": time.time()}
        now = time.time()
        with relserver2._peers_lock:
            dead = [
                a for a, info in relserver2._peers.items()
                if now - info["last"] > 45
            ]
        assert addr not in dead

# ══════════════════════════════════════════════════════════════
# SECTION 6 - EMULATOR APDU DISPATCH
# ══════════════════════════════════════════════════════════════
class TestEmulatorDispatch:
    def test_select_returns_fci(self):
        capdu = bytes.fromhex("00A404000E325041592E5359532E444446303100")
        rapdu = emulator.pick_response(capdu)
        assert rapdu == emulator.FCI
        assert rapdu.endswith(b"\x90\x00")

    def test_gpo_returns_gpo_template(self):
        capdu = bytes.fromhex("80A8000002830000")
        rapdu = emulator.pick_response(capdu)
        assert rapdu == emulator.GPO
        assert rapdu[0] == 0x77  # Template 77
        assert rapdu.endswith(b"\x90\x00")

    def test_read_record_returns_record(self):
        capdu = bytes.fromhex("00B2011C00")
        rapdu = emulator.pick_response(capdu)
        assert rapdu == emulator.READ_REC
        assert rapdu[0] == 0x70  # Template 70

    def test_unknown_ins_returns_6a82(self):
        capdu = bytes.fromhex("00FF000000")
        rapdu = emulator.pick_response(capdu)
        assert rapdu == b"\x6A\x82"

    def test_short_capdu_rejected(self):
        assert emulator.pick_response(b"") == b"\x6A\x82"
        assert emulator.pick_response(b"\x00") == b"\x6A\x82"

    def test_fci_contains_high_offline_tags(self):
        hex_fci = emulator.FCI.hex().upper()
        assert "8202" in hex_fci  # AIP tag
        assert "9F13040003E800" in hex_fci  # €2560 offline limit
        assert "9F0F050000000000" in hex_fci  # IAC-Online = 0
        assert "8E0C" in hex_fci  # CVM list

    def test_gpo_contains_tc_cid(self):
        hex_gpo = emulator.GPO.hex().upper()
        assert "9F270140" in hex_gpo  # CID = 0x40 (TC)

# ══════════════════════════════════════════════════════════════
# SECTION 7 - RELAY FORWARDER (unit, mocked emulator)
# ══════════════════════════════════════════════════════════════
class TestForwarder:
    def test_forwards_capdu_and_returns_rapdu(self):
        """Real UDP loopback: spin up a tiny emulator responder."""
        port = self._free_port()
        expected_rapdu = bytes.fromhex("6F1A840E325041592E5359532E4444463031A5089000")

        def responder():
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.bind(("127.0.0.1", port))
            s.settimeout(3.0)
            try:
                data, addr = s.recvfrom(4096)
                assert data == b"CAPDU_TEST"
                s.sendto(expected_rapdu, addr)
            finally:
                s.close()

        t = threading.Thread(target=responder, daemon=True)
        t.start()
        time.sleep(0.1)

        rapdu = relserver2._forward_to_emulator(b"CAPDU_TEST", "127.0.0.1", port, 2)
        assert rapdu == expected_rapdu
        t.join(timeout=2)

    def test_forwarder_timeout_returns_6f00(self):
        """No emulator listening → timeout → SW 6F00."""
        port = self._free_port()
        # Nothing bound to `port` → recvfrom will time out
        rapdu = relserver2._forward_to_emulator(b"NOEMU", "127.0.0.1", port, 1)
        assert rapdu == b"\x6F\x00"

    @staticmethod
    def _free_port():
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.bind(("127.0.0.1", 0))
        p = s.getsockname()[1]
        s.close()
        return p

# ══════════════════════════════════════════════════════════════
# SECTION 8 - END-TO-END: Relay + Emulator, real UDP
# ══════════════════════════════════════════════════════════════
class TestEndToEnd:
    """Boot both processes as subprocesses, send real UDP frames, assert responses."""

    @pytest.fixture
    def rig(self, tmp_path):
        emu_port = self._free_port()
        relay_port = self._free_port()

        emu_proc = subprocess.Popen(
            [sys.executable, "emulator.py", str(emu_port)],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
        )
        relay_proc = subprocess.Popen(
            [sys.executable, "relserver2.py",
             "--port", str(relay_port),
             "--emu-host", "127.0.0.1", "--emu-port", str(emu_port),
             "--peer-timeout", "5",
             "--socket-timeout", "0.5"],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
        )
        time.sleep(0.8)  # let both bind

        yield {"relay_port": relay_port, "emu_port": emu_port}

        for p in (relay_proc, emu_proc):
            p.terminate()
            try:
                p.wait(timeout=2)
            except subprocess.TimeoutExpired:
                p.kill()

    @staticmethod
    def _free_port():
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.bind(("127.0.0.1", 0))
        p = s.getsockname()[1]
        s.close()
        return p

    def _send(self, sock, port, sid, payload=b""):
        sock.sendto(bytes([sid]) + payload, ("127.0.0.1", port))

    def _recv(self, sock):
        data, _ = sock.recvfrom(4096)
        return data

    def test_raw_register_gets_ack(self, rig, udp_client):
        self._send(udp_client, rig["relay_port"], relserver2.SID_RAW, bytes([relserver2.ROLE_READER_FLAG]))
        resp = self._recv(udp_client)
        assert resp == bytes([relserver2.SID_ACK])

    def test_standard_register_gets_ack(self, rig, udp_client):
        self._send(udp_client, rig["relay_port"], relserver2.SID_REGISTER, bytes([relserver2.ROLE_EMULATOR_FLAG]))
        resp = self._recv(udp_client)
        assert resp == bytes([relserver2.SID_ACK])

    def test_capdu_select_returns_wrapped_fci(self, rig, udp_client):
        # First register
        self._send(udp_client, rig["relay_port"], relserver2.SID_REGISTER, bytes([relserver2.ROLE_READER_FLAG]))
        self._recv(udp_client)  # eat ACK

        # Send SELECT PPSE
        select_ppse = bytes.fromhex("00A404000E325041592E5359532E444446303100")
        self._send(udp_client, rig["relay_port"], relserver2.SID_CAPDU, select_ppse)
        resp = self._recv(udp_client)

        assert resp[0] == relserver2.SID_RAPDU
        assert resp[1:] == emulator.FCI

    def test_capdu_gpo_returns_wrapped_gpo(self, rig, udp_client):
        self._send(udp_client, rig["relay_port"], relserver2.SID_REGISTER, bytes([relserver2.ROLE_READER_FLAG]))
        self._recv(udp_client)

        gpo = bytes.fromhex("80A8000002830000")
        self._send(udp_client, rig["relay_port"], relserver2.SID_CAPDU, gpo)
        resp = self._recv(udp_client)

        assert resp[0] == relserver2.SID_RAPDU
        assert resp[1:] == emulator.GPO

    def test_capdu_read_record_returns_wrapped_record(self, rig, udp_client):
        self._send(udp_client, rig["relay_port"], relserver2.SID_REGISTER, bytes([relserver2.ROLE_READER_FLAG]))
        self._recv(udp_client)

        read = bytes.fromhex("00B2011C00")
        self._send(udp_client, rig["relay_port"], relserver2.SID_CAPDU, read)
        resp = self._recv(udp_client)

        assert resp[0] == relserver2.SID_RAPDU
        assert resp[1:] == emulator.READ_REC

    def test_capdu_unknown_ins_returns_6a82(self, rig, udp_client):
        self._send(udp_client, rig["relay_port"], relserver2.SID_REGISTER, bytes([relserver2.ROLE_READER_FLAG]))
        self._recv(udp_client)

        weird = bytes.fromhex("00FF000000")
        self._send(udp_client, rig["relay_port"], relserver2.SID_CAPDU, weird)
        resp = self._recv(udp_client)

        assert resp[0] == relserver2.SID_RAPDU
        assert resp[1:] == b"\x6A\x82"

    def test_heartbeat_no_reply_no_crash(self, rig, udp_client):
        """HEARTBEAT should refresh timer, not reply. Verify relay stays alive."""
        self._send(udp_client, rig["relay_port"], relserver2.SID_HEARTBEAT, b"")
        # No reply expected - just make sure follow-up CAPDU still works
        udp_client.settimeout(0.5)
        with pytest.raises(socket.timeout):
            self._recv(udp_client)

        # Now send a real CAPDU → should still work
        udp_client.settimeout(2.0)
        self._send(udp_client, rig["relay_port"], relserver2.SID_CAPDU, bytes.fromhex("00A404000E325041592E5359532E444446303100"))
        resp = self._recv(udp_client)
        assert resp[0] == relserver2.SID_RAPDU

    def test_ctrl_no_reply_no_crash(self, rig, udp_client):
        self._send(udp_client, rig["relay_port"], relserver2.SID_CTRL, b"\xDE\xAD")
        udp_client.settimeout(0.5)
        with pytest.raises(socket.timeout):
            self._recv(udp_client)

    def test_unknown_sid_logged_no_reply(self, rig, udp_client):
        # SID 0xEE is undefined
        udp_client.sendto(bytes([0xEE, 0x00]), ("127.0.0.1", rig["relay_port"]))
        udp_client.settimeout(0.5)
        with pytest.raises(socket.timeout):
            self._recv(udp_client)

# ══════════════════════════════════════════════════════════════
# SECTION 9 - CLI ARG PARSING
# ══════════════════════════════════════════════════════════════
class TestCliArgs:
    def test_relay_help_exits_zero(self):
        r = subprocess.run(
            [sys.executable, "relserver2.py", "--help"],
            capture_output=True, text=True, timeout=5,
        )
        assert r.returncode == 0
        assert "--emu-host" in r.stdout
        assert "--emu-port" in r.stdout
        assert "--port" in r.stdout
        assert "--log-level" in r.stdout

# ══════════════════════════════════════════════════════════════
# SECTION 10 - MUTATION / INTERCEPT SANITY
# ══════════════════════════════════════════════════════════════
class TestMutation:
    """Confirm the emulator profile bytes are what the terminal needs."""

    def test_fci_aip_offline_capable(self):
        # AIP tag 82, length 02, value 3C00 → CDA + DDA + EMV contactless
        hex_fci = emulator.FCI.hex().upper()
        idx = hex_fci.find("8202")
        assert idx >= 0
        aip = hex_fci[idx+4:idx+8]
        assert aip == "3C00", f"AIP should be 3C00, got {aip}"

    def test_fci_iac_online_zeroed(self):
        # 9F0F = IAC-Online, must be all zeros so terminal never forces online
        hex_fci = emulator.FCI.hex().upper()
        idx = hex_fci.find("9F0F05")
        assert idx >= 0
        iac = hex_fci[idx+6:idx+16]
        assert iac == "0000000000", f"IAC-Online must be 0, got {iac}"

    def test_fci_offline_limit_2560(self):
        # 9F13 = Lower Consecutive Offline Limit, 4 bytes = 0003E800 = €2560
        hex_fci = emulator.FCI.hex().upper()
        idx = hex_fci.find("9F1304")
        assert idx >= 0
        limit = hex_fci[idx+6:idx+14]
        assert limit == "0003E800", f"Offline limit must be 0003E800, got {limit}"

    def test_fci_cvm_no_cvm_required(self):
        # 8E CVM list: amount X=0, amount Y=0, then rules 1F03 (No CVM) 1E03 (No CVM if unattended)
        hex_fci = emulator.FCI.hex().upper()
        idx = hex_fci.find("8E0C")
        assert idx >= 0
        cvm = hex_fci[idx+4:idx+28]
        assert "1F03" in cvm and "1E03" in cvm, f"CVM list must contain No-CVM rules, got {cvm}"

    def test_gpo_aip_matches_fci(self):
        # GPO AIP must match FCI AIP or terminal will bail
        hex_gpo = emulator.GPO.hex().upper()
        hex_fci = emulator.FCI.hex().upper()
        gpo_idx = hex_gpo.find("8202")
        fci_idx = hex_fci.find("8202")
        assert hex_gpo[gpo_idx+4:gpo_idx+8] == hex_fci[fci_idx+4:fci_idx+8]

    def test_gpo_cid_is_tc_offline_approved(self):
        # 9F27 01 40 → CID = 0x40 = TC (offline approved)
        hex_gpo = emulator.GPO.hex().upper()
        idx = hex_gpo.find("9F2701")
        assert idx >= 0
        cid = hex_gpo[idx+6:idx+8]
        assert cid == "40", f"CID must be 40 (TC), got {cid}"

    def test_gpo_atc_present(self):
        # 9F36 02 = ATC (Application Transaction Counter), 2 bytes
        hex_gpo = emulator.GPO.hex().upper()
        assert "9F3602" in hex_gpo

    def test_gpo_ends_with_9000(self):
        assert emulator.GPO.endswith(b"\x90\x00")

    def test_fci_ends_with_9000(self):
        assert emulator.FCI.endswith(b"\x90\x00")

    def test_read_rec_ends_with_9000(self):
        assert emulator.READ_REC.endswith(b"\x90\x00")

# ══════════════════════════════════════════════════════════════
# SECTION 11 - SID FRAME CONSTRUCTION & PARSING
# ══════════════════════════════════════════════════════════════
class TestSidFrames:
    def test_capdu_frame_layout(self):
        capdu = bytes.fromhex("00A404000E325041592E5359532E444446303100")
        frame = bytes([relserver2.SID_CAPDU]) + capdu
        assert frame[0] == 0x02
        assert frame[1:] == capdu

    def test_rapdu_frame_layout(self):
        rapdu = emulator.FCI
        frame = bytes([relserver2.SID_RAPDU]) + rapdu
        assert frame[0] == 0x03
        assert frame[1:] == rapdu

    def test_register_frame_reader(self):
        frame = bytes([relserver2.SID_REGISTER, relserver2.ROLE_READER_FLAG])
        assert frame == b"\x01\x02"

    def test_register_frame_emulator(self):
        frame = bytes([relserver2.SID_REGISTER, relserver2.ROLE_EMULATOR_FLAG])
        assert frame == b"\x01\x01"

    def test_ack_frame_is_single_byte(self):
        frame = bytes([relserver2.SID_ACK])
        assert frame == b"\x04"
        assert len(frame) == 1

# ══════════════════════════════════════════════════════════════
# SECTION 12 - CONCURRENCY / THREAD SAFETY
# ══════════════════════════════════════════════════════════════
class TestConcurrency:
    def test_peer_update_thread_safe(self, reset_relay_state):
        """Hammer _peer_update from many threads, verify no corruption."""
        addrs = [("10.0.1.%d" % i, 4000 + i) for i in range(50)]

        def worker(addr):
            for _ in range(100):
                relserver2._peer_update(addr, "READER")

        threads = [threading.Thread(target=worker, args=(a,)) for a in addrs]
        for t in threads: t.start()
        for t in threads: t.join()

        assert len(relserver2._peers) == 50
        for a in addrs:
            assert relserver2._peers[a]["role"] == "READER"

    def test_sweep_and_update_concurrent(self, reset_relay_state):
        """Sweep thread + update thread must not deadlock or corrupt state."""
        stop = threading.Event()

        def updater():
            i = 0
            while not stop.is_set():
                relserver2._peer_update(("10.0.2.%d" % (i % 20), 5000), "EMULATOR")
                i += 1
                time.sleep(0.001)

        def sweeper():
            while not stop.is_set():
                now = time.time()
                with relserver2._peers_lock:
                    dead = [a for a, info in relserver2._peers.items() if now - info["last"] > 45]
                    for a in dead:
                        relserver2._peers.pop(a, None)
                time.sleep(0.005)

        t1 = threading.Thread(target=updater)
        t2 = threading.Thread(target=sweeper)
        t1.start(); t2.start()
        time.sleep(0.5)
        stop.set()
        t1.join(timeout=2); t2.join(timeout=2)

        # Nothing crashed, table is consistent
        assert isinstance(relserver2._peers, dict)

# ══════════════════════════════════════════════════════════════
# SECTION 13 - FULL SESSION FLOW (SELECT → GPO → READ → GEN AC)
# ══════════════════════════════════════════════════════════════
class TestFullSession:
    """Simulate a complete contactless EMV session through the rig."""

    @pytest.fixture
    def rig(self, tmp_path):
        emu_port = self._free_port()
        relay_port = self._free_port()

        emu = subprocess.Popen(
            [sys.executable, "emulator.py", str(emu_port)],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
        )
        relay = subprocess.Popen(
            [sys.executable, "relserver2.py",
             "--port", str(relay_port),
             "--emu-host", "127.0.0.1", "--emu-port", str(emu_port),
             "--peer-timeout", "5", "--socket-timeout", "0.5"],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
        )
        time.sleep(0.8)
        yield {"relay_port": relay_port, "emu_port": emu_port}
        for p in (relay, emu):
            p.terminate()
            try: p.wait(timeout=2)
            except subprocess.TimeoutExpired: p.kill()

    @staticmethod
    def _free_port():
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.bind(("127.0.0.1", 0))
        p = s.getsockname()[1]
        s.close()
        return p

    def _txn(self, sock, port, sid, payload=b""):
        sock.sendto(bytes([sid]) + payload, ("127.0.0.1", port))
        data, _ = sock.recvfrom(4096)
        return data

    def test_full_contactless_flow(self, rig, udp_client):
        port = rig["relay_port"]

        # 1) Register as READER
        ack = self._txn(udp_client, port, relserver2.SID_REGISTER, bytes([relserver2.ROLE_READER_FLAG]))
        assert ack == bytes([relserver2.SID_ACK])

        # 2) SELECT PPSE
        select_ppse = bytes.fromhex("00A404000E325041592E5359532E444446303100")
        resp = self._txn(udp_client, port, relserver2.SID_CAPDU, select_ppse)
        assert resp[0] == relserver2.SID_RAPDU
        assert resp[1:] == emulator.FCI

        # 3) SELECT AID (Mastercard)
        select_aid = bytes.fromhex("00A4040007A000000004101000")
        resp = self._txn(udp_client, port, relserver2.SID_CAPDU, select_aid)
        assert resp[0] == relserver2.SID_RAPDU
        assert resp[1:] == emulator.FCI  # emulator is stateless, returns FCI for any SELECT

        # 4) GPO
        gpo = bytes.fromhex("80A8000002830000")
        resp = self._txn(udp_client, port, relserver2.SID_CAPDU, gpo)
        assert resp[0] == relserver2.SID_RAPDU
        assert resp[1:] == emulator.GPO
        # Verify CID=TC in response
        assert b"\x9F\x27\x01\x40" in resp[1:]

        # 5) READ RECORD
        read = bytes.fromhex("00B2011C00")
        resp = self._txn(udp_client, port, relserver2.SID_CAPDU, read)
        assert resp[0] == relserver2.SID_RAPDU
        assert resp[1:] == emulator.READ_REC

        # 6) HEARTBEAT to keep session alive (no reply expected)
        udp_client.sendto(bytes([relserver2.SID_HEARTBEAT]), ("127.0.0.1", port))
        udp_client.settimeout(0.3)
        with pytest.raises(socket.timeout):
            udp_client.recvfrom(4096)

        # 7) Second CAPDU after heartbeat still works
        udp_client.settimeout(2.0)
        resp = self._txn(udp_client, port, relserver2.SID_CAPDU, select_ppse)
        assert resp[0] == relserver2.SID_RAPDU

    def test_two_peers_independent_sessions(self, rig):
        """Two clients (READER + EMULATOR) can register + transact independently."""
        port = rig["relay_port"]

        reader = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        reader.settimeout(2.0)
        emu_peer = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        emu_peer.settimeout(2.0)

        try:
            reader.sendto(bytes([relserver2.SID_REGISTER, relserver2.ROLE_READER_FLAG]), ("127.0.0.1", port))
            assert reader.recvfrom(4096)[0] == bytes([relserver2.SID_ACK])

            emu_peer.sendto(bytes([relserver2.SID_REGISTER, relserver2.ROLE_EMULATOR_FLAG]), ("127.0.0.1", port))
            assert emu_peer.recvfrom(4096)[0] == bytes([relserver2.SID_ACK])

            # Reader sends CAPDU, gets RAPDU back on its own socket
            reader.sendto(bytes([relserver2.SID_CAPDU]) + bytes.fromhex("00A404000E325041592E5359532E444446303100"),
                          ("127.0.0.1", port))
            data, _ = reader.recvfrom(4096)
            assert data[0] == relserver2.SID_RAPDU
        finally:
            reader.close()
            emu_peer.close()

# ══════════════════════════════════════════════════════════════
# SECTION 14 - REGRESSION GUARDS
# ══════════════════════════════════════════════════════════════
class TestRegressions:
    def test_sid_raw_zero_does_not_raise(self, reset_relay_state):
        """SID 0x00 was previously logged as unknown - must now register."""
        # Simulate the branch directly
        addr = ("10.0.9.9", 9999)
        # This is what the main loop does for SID_RAW:
        payload = bytes([relserver2.ROLE_READER_FLAG])
        role_flag = payload[0] if payload else 0x00
        role_str = {relserver2.ROLE_EMULATOR_FLAG: "EMULATOR",
                    relserver2.ROLE_READER_FLAG: "READER"}.get(role_flag, "UNKNOWN")
        relserver2._peer_update(addr, role_str)
        assert relserver2._peers[addr]["role"] == "READER"

    def test_empty_capdu_forwarded_gets_6a82_or_6f00(self):
        """Emulator should not crash on empty CAPDU."""
        assert emulator.pick_response(b"") == b"\x6A\x82"

    def test_forwarder_returns_bytes_not_none(self):
        """_forward_to_emulator must always return bytes, even on timeout."""
        port = TestForwarder._free_port()
        result = relserver2._forward_to_emulator(b"X", "127.0.0.1", port, 1)
        assert isinstance(result, bytes)
        assert len(result) >= 2

if __name__ == "__main__":
    sys.exit(pytest.main([__file__, "-v", "--tb=short"]))
