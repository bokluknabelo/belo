# -*- coding: utf-8 -*-

from pathlib import Path

SKIP_DIRS = {"venv", ".venv", "env", "__pycache__", "site-packages", "dist-packages"}

MAP = {
    "\ufeff": "",
    "\u2013": "-",
    "\u2014": "-",
    "\u2015": "-",
    "\u2212": "-",
    "\u2018": "'",
    "\u2019": "'",
    "\u201c": '"',
    "\u201d": '"',
    "\u00a0": " ",
    "\u2026": "...",
}

HEADER = "# -*- coding: utf-8 -*-"


def normalize(p: Path) -> bool:
    raw = p.read_bytes()

    try:
        s = raw.decode("utf-8")
    except UnicodeDecodeError:
        s = raw.decode("cp1252")

    for old, new in MAP.items():
        s = s.replace(old, new)

    s = s.replace("\r\n", "\n").replace("\r", "\n")

    lines = s.splitlines()
    if not lines or "coding:" not in lines[0]:
        s = HEADER + "\n" + s

    new_raw = s.encode("utf-8")

    if new_raw != raw:
        p.write_bytes(new_raw)
        return True

    return False


changed = 0

for f in Path(".").rglob("*.py"):
    if any(part in SKIP_DIRS for part in f.parts):
        continue

    try:
        if normalize(f):
            changed += 1
            print(f"fixed: {f}")
    except Exception as e:
        print(f"skip:  {f} ({e})")

print(f"Done. Files changed: {changed}")
