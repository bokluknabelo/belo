from pathlib import Path
import argparse

from . import plugins  # noqa: F401
from .core import LabContext, Runner, discover_plugins, registry
from .reporting import markdown_report
from .ui import COMPLETE_KEYS, run


def main() -> int:
    parser = argparse.ArgumentParser(description="Relay cross-language protocol laboratory")
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--run")
    parser.add_argument("--report", action="store_true")
    args = parser.parse_args()
    discover_plugins(args.root)
    if not args.run:
        return run(args.root)
    context = LabContext(args.root)
    if args.run != "complete" and args.run not in {item.key for item in registry.all()}:
        parser.error(f"unknown validator: {args.run}")
    keys = COMPLETE_KEYS if args.run == "complete" else [args.run]
    result = Runner(context).run(keys, args.run)
    print(result.status.value, result.counts(), result.run_id)
    for finding in result.findings:
        print(f"{finding.status.value:<5} {finding.validator:<12} {finding.summary}")
    if args.report:
        path = context.reports_dir / f"validation-{result.run_id}.md"
        print(markdown_report(result, path))
    return 1 if result.status.value == "FAIL" else 0


if __name__ == "__main__":
    raise SystemExit(main())
