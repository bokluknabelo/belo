# -*- coding: utf-8 -*-
"""Packet router with MITM support for relay server."""

from __future__ import annotations
from typing import Any, Optional, Callable, Dict
import logging

class PacketRouter:
    MODE_PASSTHROUGH = "passthrough"
    MODE_MITM = "mitm"
    MODE_PROFILE = "profile"

    def __init__(self):
        self._mode = self.MODE_PASSTHROUGH
        self.session: Dict[str, Any] = {
            "capdu_count": 0,
            "rapdu_count": 0,
            "last_capdu": None,
            "last_rapdu": None,
            "mitm_rules": [],
        }
        self._reader_addr: Optional[tuple] = None
        self._emulator_addr: Optional[tuple] = None
        self._last_capdu_to_emu: Optional[bytes] = None
        self._sock: Any = None
        self._mitm_hooks: Dict[str, Callable] = {}

    def get_mode(self) -> str:
        return self._mode

    def set_mode(self, mode: str) -> None:
        if mode not in (self.MODE_PASSTHROUGH, self.MODE_MITM, self.MODE_PROFILE):
            raise ValueError(f"Unknown mode: {mode}")
        self._mode = mode

    def register_mitm_hook(self, name: str, hook: Callable) -> None:
        """Register a named MITM hook function."""
        self._mitm_hooks[name] = hook

    def set_transport_state(self, *, sock: Any = None,
                            reader_addr: Optional[tuple] = None,
                            emulator_addr: Optional[tuple] = None) -> None:
        """Synchronize transport state owned by this router."""
        self._sock = sock
        self._reader_addr = reader_addr
        self._emulator_addr = emulator_addr

    def set_last_capdu_to_emulator(self, payload: Optional[bytes]) -> None:
        self._last_capdu_to_emu = payload

    def apply_mitm(self, direction: str, payload: bytes,
                   session: dict, log: logging.Logger) -> bytes:
        """Apply registered MITM hooks in order."""
        if self._mode == self.MODE_PASSTHROUGH:
            return payload

        result = payload
        for name, hook in self._mitm_hooks.items():
            try:
                result = hook(direction, result, session, log)
            except Exception as e:
                log.warning(f"MITM hook '{name}' failed: {e}")
        return result

    def classify_and_cache(self, payload: bytes) -> None:
        """Classify and cache APDU for later analysis."""
        self.session["capdu_count"] = self.session.get("capdu_count", 0) + 1
        self.session["last_capdu"] = payload

        if len(payload) >= 2:
            ins = payload[1]
            if ins == 0xA4:
                self.session["last_select"] = payload
            elif ins == 0xA8:
                self.session["last_gpo"] = payload
            elif ins == 0xAE:
                self.session["last_gac"] = payload

    def reset_session(self) -> None:
        self.session.clear()
        self.session["capdu_count"] = 0
        self.session["rapdu_count"] = 0
        self._last_capdu_to_emu = None

# Module-level singleton
_singleton = PacketRouter()

# Module-level attribute access
get_mode = _singleton.get_mode
set_mode = _singleton.set_mode
apply_mitm = _singleton.apply_mitm
classify_and_cache = _singleton.classify_and_cache
reset_session = _singleton.reset_session
register_mitm_hook = _singleton.register_mitm_hook
set_transport_state = _singleton.set_transport_state
set_last_capdu_to_emulator = _singleton.set_last_capdu_to_emulator
session = _singleton.session
MODE_PASSTHROUGH = _singleton.MODE_PASSTHROUGH
MODE_MITM = _singleton.MODE_MITM
MODE_PROFILE = _singleton.MODE_PROFILE
