from __future__ import annotations

from pathlib import Path
import json
import shutil


def list_json(path: Path) -> list[Path]:
    return sorted(path.glob("*.json"), key=lambda item: item.stat().st_mtime, reverse=True)


def load(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def normalize_session(payload: dict) -> list[dict]:
    keys = ("subsystem", "direction", "state", "packet", "apdu", "callback",
            "session", "function", "result", "severity")
    return [{key: event.get(key, "") for key in keys} for event in payload.get("events", [])]


def create_golden(session: Path, golden_dir: Path, name: str) -> Path:
    target = golden_dir / f"{name}.json"
    shutil.copyfile(session, target)
    return target


def compare(actual: Path, golden: Path) -> list[str]:
    left = normalize_session(load(actual))
    right = normalize_session(load(golden))
    differences = []
    size = max(len(left), len(right))
    for index in range(size):
        if index >= len(left):
            differences.append(f"event {index}: missing actual event")
        elif index >= len(right):
            differences.append(f"event {index}: unexpected actual event {left[index]}")
        elif left[index] != right[index]:
            differences.append(f"event {index}: actual={left[index]} golden={right[index]}")
    return differences
