from __future__ import annotations

from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Any
import threading
import time
import uuid


class Status(str, Enum):
    PASS = "PASS"
    FAIL = "FAIL"
    WARN = "WARN"
    INFO = "INFO"


@dataclass(frozen=True)
class Event:
    timestamp_ns: int
    thread: str
    subsystem: str
    direction: str = ""
    state: str = ""
    packet: str = ""
    apdu: str = ""
    callback: str = ""
    session: str = ""
    function: str = ""
    result: str = ""
    severity: str = "INFO"
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def now(cls, subsystem: str, **kwargs: Any) -> "Event":
        return cls(time.time_ns(), threading.current_thread().name, subsystem, **kwargs)

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class Finding:
    validator: str
    status: Status
    summary: str
    evidence: str = ""
    recommendation: str = ""
    duration_ms: float = 0.0


@dataclass
class RunResult:
    name: str
    run_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    started_ns: int = field(default_factory=time.time_ns)
    finished_ns: int = 0
    findings: list[Finding] = field(default_factory=list)
    events: list[Event] = field(default_factory=list)

    def finish(self) -> None:
        self.finished_ns = time.time_ns()

    @property
    def status(self) -> Status:
        values = {finding.status for finding in self.findings}
        if Status.FAIL in values:
            return Status.FAIL
        if Status.WARN in values:
            return Status.WARN
        return Status.PASS

    def counts(self) -> dict[str, int]:
        return {status.value: sum(f.status == status for f in self.findings) for status in Status}
