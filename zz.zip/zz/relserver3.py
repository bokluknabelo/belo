# -*- coding: utf-8 -*-
#!/usr/bin/env python3

"""

relserver.py - SID-framed UDP relay on port 5566.


Forwards raw CAPDU payloads to the emulator on port 9001

and wraps the RAPDU back in a SID_RAPDU frame.


Framing: [SID:1 byte][payload...]


SIDs:

    0x00  SID_RAW        - registration (payload[0] = role flag)

    0x01  SID_REGISTER   - explicit registration

    0x02  SID_CAPDU      - CAPDU from reader

    0x03  SID_RAPDU      - RAPDU back to reader

    0x04  SID_ACK        - ack (single byte)

    0x05  SID_HEARTBEAT  - keepalive

    0x06  SID_CTRL       - reserved

"""


import argparse

import socket

import sys

import threading

import time


SID_RAW       = 0x00

SID_REGISTER  = 0x01

SID_CAPDU     = 0x02

SID_RAPDU     = 0x03

SID_ACK       = 0x04

SID_HEARTBEAT = 0x05

SID_CTRL      = 0x06


ROLE_EMULATOR_FLAG = 0x01

ROLE_READER_FLAG   = 0x02


_peers = {}

_peers_lock = threading.Lock()


def log(msg):

    print(f"[{time.strftime('%H:%M:%S')}] {msg}", flush=True)


def peer_update(addr, role=None):

    with _peers_lock:

        entry = _peers.get(addr)

        now = time.time()

        if entry is None:

            _peers[addr] = {"role": role or "UNKNOWN", "last": now}

            log(f"peer_registered {addr[0]}:{addr[1]} role={role or 'UNKNOWN'}")

        else:

            entry["last"] = now

            if role and entry["role"] == "UNKNOWN":

                entry["role"] = role

                log(f"peer_role_resolved {addr[0]}:{addr[1]} role={role}")


def peer_sweep(timeout_seconds):

    while True:

        time.sleep(25)

        now = time.time()

        with _peers_lock:

            dead = [a for a, info in _peers.items() if now - info["last"] > timeout_seconds]

            for a in dead:

                role = _peers[a]["role"]

                log(f"peer_timed_out {a[0]}:{a[1]} role={role}")

                _peers.pop(a, None)


def forward_to_emulator(capdu, emu_host, emu_port, timeout_seconds):

    fwd = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    fwd.settimeout(timeout_seconds)

    try:

        fwd.sendto(capdu, (emu_host, emu_port))

        rapdu, _ = fwd.recvfrom(4096)

        return rapdu

    except socket.timeout:

        log("emulator_timeout")

        return b"\x6F\x00"

    finally:

        fwd.close()


def main_loop(bind_host, bind_port, emu_host, emu_port, peer_timeout, socket_timeout, emu_timeout):

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

    sock.bind((bind_host, bind_port))

    sock.settimeout(socket_timeout)


    log(f"relay listening on {bind_host}:{bind_port} -> emulator {emu_host}:{emu_port}")


    threading.Thread(target=peer_sweep, args=(peer_timeout,), daemon=True).start()


    while True:

        try:

            data, addr = sock.recvfrom(4096)

        except socket.timeout:

            continue

        if not data:

            continue


        sid = data[0]

        payload = data[1:]


        # Registration (both SID_RAW and SID_REGISTER treated the same)

        if sid in (SID_RAW, SID_REGISTER):

            role_flag = payload[0] if payload else 0x00

            role_str = {

                ROLE_EMULATOR_FLAG: "EMULATOR",

                ROLE_READER_FLAG: "READER",

            }.get(role_flag, "UNKNOWN")

            peer_update(addr, role_str)

            sock.sendto(bytes([SID_ACK]), addr)

            log(f"register_ack -> {addr[0]}:{addr[1]} role={role_str} sid=0x{sid:02X}")

            continue


        # Keepalive / control - just refresh timer

        if sid in (SID_ACK, SID_HEARTBEAT, SID_CTRL):

            peer_update(addr)

            continue


        # CAPDU - forward to emulator, wrap response

        if sid == SID_CAPDU:

            peer_update(addr)

            log(f"CAPDU RX from {addr[0]}:{addr[1]} ({len(payload)}b) hex={payload.hex().upper()}")

            rapdu = forward_to_emulator(payload, emu_host, emu_port, emu_timeout)

            frame = bytes([SID_RAPDU]) + rapdu

            sock.sendto(frame, addr)

            log(f"RAPDU TX to {addr[0]}:{addr[1]} ({len(rapdu)}b) hex={rapdu.hex().upper()}")

            continue


        log(f"unknown_sid 0x{sid:02X} from {addr[0]}:{addr[1]}")


if __name__ == "__main__":

    parser = argparse.ArgumentParser(description="SID-framed UDP relay -> emulator forwarder")

    parser.add_argument("--host", default="0.0.0.0", help="Bind host")

    parser.add_argument("--port", type=int, default=5566, help="Bind port")

    parser.add_argument("--emu-host", default="127.0.0.1", help="Emulator host (where emulator.py runs)")

    parser.add_argument("--emu-port", type=int, default=9001, help="Emulator port")

    parser.add_argument("--peer-timeout", type=int, default=45)

    parser.add_argument("--socket-timeout", type=float, default=1.0)

    parser.add_argument("--emu-timeout", type=float, default=3.0)

    args = parser.parse_args()


    try:

        main_loop(

            bind_host=args.host,

            bind_port=args.port,

            emu_host=args.emu_host,

            emu_port=args.emu_port,

            peer_timeout=args.peer_timeout,

            socket_timeout=args.socket_timeout,

            emu_timeout=args.emu_timeout,

        )

    except KeyboardInterrupt:

        log("shutdown")

        sys.exit(0)

