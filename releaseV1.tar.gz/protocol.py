# -*- coding: utf-8 -*-
"""EMV APDU protocol classes, TLV helpers, and byte-level operations."""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional, List, Tuple
import struct

@dataclass
class CommandAPDU:
    cla: int = 0x00
    ins: int = 0x00
    p1: int = 0x00
    p2: int = 0x00
    data: bytes = b""
    le: Optional[int] = None
    extended: bool = False

    @classmethod
    def from_bytes(cls, raw: bytes) -> Optional["CommandAPDU"]:
        if len(raw) < 4:
            return None
        head = dict(cla=raw[0], ins=raw[1], p1=raw[2], p2=raw[3])
        if len(raw) == 4:
            return cls(**head)
        if len(raw) == 5:
            le = raw[4] or 256
            return cls(**head, le=le)

        first_length = raw[4]
        if first_length != 0:
            lc = first_length
            data_end = 5 + lc
            if len(raw) == data_end:
                return cls(**head, data=raw[5:data_end])
            if len(raw) == data_end + 1:
                return cls(**head, data=raw[5:data_end], le=raw[data_end] or 256)
            return None

        if len(raw) < 7:
            return None
        value = int.from_bytes(raw[5:7], "big")
        if len(raw) == 7:
            return cls(**head, le=value or 65536, extended=True)
        if value == 0:
            return None
        data_end = 7 + value
        if len(raw) == data_end:
            return cls(**head, data=raw[7:data_end], extended=True)
        if len(raw) == data_end + 2:
            le = int.from_bytes(raw[data_end:data_end + 2], "big") or 65536
            return cls(**head, data=raw[7:data_end], le=le, extended=True)
        return None

    def to_bytes(self) -> bytes:
        header = bytes([self.cla, self.ins, self.p1, self.p2])
        use_extended = self.extended or len(self.data) > 255 or (self.le or 0) > 256
        if use_extended:
            if self.data:
                if len(self.data) > 65535:
                    raise ValueError("Extended APDU data exceeds 65535 bytes")
                out = header + b"\x00" + len(self.data).to_bytes(2, "big") + self.data
                if self.le is not None:
                    encoded_le = 0 if self.le == 65536 else self.le
                    if not 0 <= encoded_le <= 65535:
                        raise ValueError("Extended Le is out of range")
                    out += encoded_le.to_bytes(2, "big")
                return out
            if self.le is None:
                return header
            encoded_le = 0 if self.le == 65536 else self.le
            if not 0 <= encoded_le <= 65535:
                raise ValueError("Extended Le is out of range")
            return header + b"\x00" + encoded_le.to_bytes(2, "big")

        if self.data:
            out = header + bytes([len(self.data)]) + self.data
            if self.le is not None:
                if not 1 <= self.le <= 256:
                    raise ValueError("Short Le is out of range")
                out += bytes([0 if self.le == 256 else self.le])
            return out
        if self.le is None:
            return header
        if not 1 <= self.le <= 256:
            raise ValueError("Short Le is out of range")
        return header + bytes([0 if self.le == 256 else self.le])

    @property
    def ins_name(self) -> str:
        names = {
            0xA4: "SELECT", 0xA8: "GPO", 0xB2: "READ RECORD",
            0x20: "VERIFY", 0xAE: "GENERATE AC", 0xCA: "GET DATA",
            0x82: "EXTERNAL AUTH",
        }
        return names.get(self.ins, f"0x{self.ins:02X}")

    @property
    def is_select(self) -> bool:
        return self.ins == 0xA4

    @property
    def is_gpo(self) -> bool:
        return self.ins == 0xA8

    @property
    def is_read_record(self) -> bool:
        return self.ins == 0xB2

    @property
    def is_generate_ac(self) -> bool:
        return self.ins == 0xAE

    @property
    def is_verify(self) -> bool:
        return self.cla == 0x00 and self.ins == 0x20 and self.p1 == 0x00 and self.p2 == 0x80

    @property
    def select_aid(self) -> Optional[bytes]:
        if not self.is_select or self.p1 != 0x04:
            return None
        return self.data

@dataclass
class ResponseAPDU:
    data: bytes = b""
    sw1: int = 0x90
    sw2: int = 0x00

    @classmethod
    def from_bytes(cls, raw: bytes) -> "ResponseAPDU":
        if len(raw) < 2:
            return cls(sw1=0x6F, sw2=0x00)
        return cls(data=raw[:-2], sw1=raw[-2], sw2=raw[-1])

    def to_bytes(self) -> bytes:
        return self.data + bytes([self.sw1, self.sw2])

    @property
    def sw(self) -> bytes:
        return bytes([self.sw1, self.sw2])

    @property
    def is_ok(self) -> bool:
        return self.sw1 == 0x90 and self.sw2 == 0x00

def craft_verify_success() -> ResponseAPDU:
    """Return SW=9000 for VERIFY bypass."""
    return ResponseAPDU(sw1=0x90, sw2=0x00)

def sw(status: bytes) -> ResponseAPDU:
    return ResponseAPDU(sw1=status[0], sw2=status[1])

SW9000 = b"\x90\x00"
SW6F00 = b"\x6F\x00"

# --- TLV helpers -----------------------------------------------------------

def find_tlv(data: bytes, target_tag: int) -> Optional[bytes]:
    i, n = 0, len(data)
    while i < n:
        tag_first = data[i]; i += 1
        if (tag_first & 0x1F) == 0x1F:
            if i >= n: return None
            tag = (tag_first << 8) | data[i]; i += 1
        else:
            tag = tag_first
        if i >= n: return None
        lf = data[i]; i += 1
        if lf & 0x80:
            nb = lf & 0x7F
            if nb == 0 or nb > 2 or i + nb > n: return None
            length = 0
            for _ in range(nb):
                length = (length << 8) | data[i]; i += 1
        else:
            length = lf
        if i + length > n: return None
        value = data[i:i + length]
        if tag == target_tag: return value
        if tag_first & 0x20:
            inner = find_tlv(value, target_tag)
            if inner is not None: return inner
        i += length
    return None

def build_tlv(tag: int, value: bytes) -> bytes:
    if tag > 0xFF:
        tag_bytes = struct.pack(">H", tag)
    else:
        tag_bytes = bytes([tag])
    length = len(value)
    if length < 0x80:
        length_bytes = bytes([length])
    elif length < 0x100:
        length_bytes = bytes([0x81, length])
    else:
        length_bytes = bytes([0x82, (length >> 8) & 0xFF, length & 0xFF])
    return tag_bytes + length_bytes + value

def parse_tlv_list(data: bytes) -> List[Tuple[int, bytes]]:
    """Parse all top-level TLV entries into a list of (tag, value)."""
    result = []
    i, n = 0, len(data)
    while i < n:
        tag_first = data[i]; i += 1
        if (tag_first & 0x1F) == 0x1F:
            if i >= n: break
            tag = (tag_first << 8) | data[i]; i += 1
        else:
            tag = tag_first
        if i >= n: break
        lf = data[i]; i += 1
        if lf & 0x80:
            nb = lf & 0x7F
            if nb == 0 or nb > 2 or i + nb > n: break
            length = 0
            for _ in range(nb):
                length = (length << 8) | data[i]; i += 1
        else:
            length = lf
        if i + length > n: break
        result.append((tag, data[i:i + length]))
        i += length
    return result

def replace_tlv(data: bytes, target_tag: int, new_value: bytes) -> bytes:
    """
    Recursively searches for target_tag in the TLV data and replaces its value.
    Preserves the rest of the TLV structure and automatically updates parent lengths.
    Correctly handles both 1-byte and 2-byte constructed tags.
    """
    parsed = parse_tlv_list(data)
    mutated = False
    updated_list = []

    for tag, val in parsed:
        if tag == target_tag:
            updated_list.append((tag, new_value))
            mutated = True
        else:
            # Correctly identify constructed tags for both 1-byte and 2-byte tags
            is_constructed = False
            if tag > 0xFF:
                # 2-byte tag: constructed bit is in the high byte
                is_constructed = ((tag >> 8) & 0x20) == 0x20
            else:
                # 1-byte tag: constructed bit is in the tag byte itself
                is_constructed = (tag & 0x20) == 0x20

            if is_constructed:
                new_inner = replace_tlv(val, target_tag, new_value)
                if new_inner != val:
                    updated_list.append((tag, new_inner))
                    mutated = True
                else:
                    updated_list.append((tag, val))
            else:
                updated_list.append((tag, val))

    if not mutated:
        return data

    out = b""
    for tag, val in updated_list:
        out += build_tlv(tag, val)
    return out
