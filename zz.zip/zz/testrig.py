# -*- coding: utf-8 -*-
#!/usr/bin/env python3
"""Test rig for relay server - runs end-to-end transaction tests."""

from __future__ import annotations
import socket
import struct
import time
import sys
import logging
from typing import Optional, Tuple, List

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger("TestRig")

SID_REGISTER = 0x00
SID_CAPDU = 0x04
SID_RAPDU = 0x05
SID_ACK = 0x05
SID_HEARTBEAT = 0x06
SID_CTRL = 0x0F

def build_frame(sid: int, payload: bytes) -> bytes:
    return struct.pack(">I", len(payload) + 1) + bytes([sid]) + payload

def parse_frame(data: bytes) -> Optional[Tuple[int, bytes]]:
    if len(data) < 5: return None
    declared = struct.unpack(">I", data[:4])[0]
    if declared != len(data) - 4: return None
    return data[4], data[5:]

class TestRig:
    """End-to-end test harness for the relay server."""

    def __init__(self, host: str = "127.0.0.1", port: int = 5566):
        self.host = host
        self.port = port
        self.sock: Optional[socket.socket] = None
        self.results: List[dict] = []

    def connect(self, role: str = "EMULATOR") -> bool:
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.settimeout(3.0)

        frame = build_frame(SID_REGISTER, role.encode())
        self.sock.sendto(frame, (self.host, self.port))
        try:
            data, _ = self.sock.recvfrom(4096)
            parsed = parse_frame(data)
            if parsed and parsed[0] == SID_ACK:
                log.info(f"Registered as {role}")
                return True
        except socket.timeout:
            pass
        log.error(f"Failed to register as {role}")
        return False

    def send_capdu(self, capdu: bytes) -> Optional[bytes]:
        self.sock.sendto(build_frame(SID_CAPDU, capdu), (self.host, self.port))
        while True:
            try:
                data, _ = self.sock.recvfrom(4096)
                parsed = parse_frame(data)
                if parsed is None: continue
                sid, payload = parsed
                if sid == SID_RAPDU: return payload
                if sid == SID_CTRL: log.info(f"CTRL: {payload.decode(errors='replace')}")
            except socket.timeout: return None

    def send_rapdu(self, rapdu: bytes) -> None:
        self.sock.sendto(build_frame(SID_RAPDU, rapdu), (self.host, self.port))

    def send_ctrl(self, command: str) -> Optional[str]:
        self.sock.sendto(build_frame(SID_CTRL, command.encode()), (self.host, self.port))
        try:
            data, _ = self.sock.recvfrom(4096)
            parsed = parse_frame(data)
            if parsed and parsed[0] == SID_CTRL:
                return parsed[1].decode(errors="replace")
        except socket.timeout: pass
        return None

    def run_transaction(self, capdu_hex: str, expected_rapdu_prefix: str = "") -> bool:
        capdu = bytes.fromhex(capdu_hex)
        log.info(f"Sending CAPDU: {capdu_hex}")
        rapdu = self.send_capdu(capdu)
        if rapdu is None:
            log.error("No response received")
            self.results.append({"capdu": capdu_hex, "rapdu": None, "status": "FAIL"})
            return False

        rapdu_hex = rapdu.hex().upper()
        log.info(f"Received RAPDU: {rapdu_hex}")

        status = "PASS"
        if expected_rapdu_prefix and not rapdu_hex.startswith(expected_rapdu_prefix):
            status = "FAIL"
            log.error(f"Expected prefix {expected_rapdu_prefix}, got {rapdu_hex[:len(expected_rapdu_prefix)]}")

        self.results.append({"capdu": capdu_hex, "rapdu": rapdu_hex, "status": status})
        return status == "PASS"

    def run_reader_rapdu(self, rapdu_hex: str) -> None:
        """Send a RAPDU as if from the READER."""
        rapdu = bytes.fromhex(rapdu_hex)
        self.send_rapdu(rapdu)
        log.info(f"Sent RAPDU: {rapdu_hex}")

    def print_summary(self) -> None:
        passed = sum(1 for r in self.results if r["status"] == "PASS")
        failed = sum(1 for r in self.results if r["status"] == "FAIL")
        log.info(f"Results: {passed} passed, {failed} failed out of {len(self.results)}")
        for r in self.results:
            if r["status"] == "FAIL":
                log.warning(f"  FAIL: {r['capdu'][:32]}... -> {r.get('rapdu', 'NONE')}")

    def close(self) -> None:
        if self.sock: self.sock.close()

def main() -> None:
    import argparse
    parser = argparse.ArgumentParser(description="EMV relay test rig")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=5566)
    parser.add_argument("--role", choices=["EMULATOR", "READER"], default="EMULATOR")
    parser.add_argument("--capdu", help="Single CAPDU hex to send")
    parser.add_argument("--rapdu", help="Single RAPDU hex to send (use with --role READER)")
    parser.add_argument("--test", action="store_true", help="Run a sample transaction sequence")
    args = parser.parse_args()

    rig = TestRig(host=args.host, port=args.port)
    if not rig.connect(args.role):
        sys.exit(1)

    if args.capdu:
        rig.run_transaction(args.capdu)
        rig.print_summary()
    elif args.rapdu:
        rig.run_reader_rapdu(args.rapdu)
    elif args.test:
        # Sample test: SELECT PPSE
        rig.run_transaction("00A404000E325041592E5359532E444446303100")
        # GET STATUS
        status = rig.send_ctrl("STATUS")
        if status: log.info(f"Status: {status}")
        rig.print_summary()
    else:
        log.info("No command specified. Use --capdu, --rapdu, or --test")

    rig.close()

if __name__ == "__main__":
    main()