# -*- coding: utf-8 -*-
# test_harness.py
# -*- coding: utf-8 -*-
"""Interactive stress test harness for RelayServer + Guard.

Simulates full EMV transaction flows over localhost UDP.
Tests phase ordering, mutation correctness, forge timing,
guard denials, out-of-order attacks, and race conditions.

Usage:
    python test_harness.py [--port 5566] [--stress] [--verbose]
"""

from __future__ import annotations
import socket
import struct
import time
import json
import sys
import argparse
import threading
from typing import Optional, Tuple, List, Dict
from dataclasses import dataclass, field

from constants import (
    SID_REGISTER, SID_CAPDU, SID_RAPDU, SID_ACK, SID_HEARTBEAT, SID_CTRL,
    EXCHANGE_MAGIC, SW_9000, SW_6F00,
    TEMPLATE_77, TEMPLATE_80, CID_ARQC, CID_TC,
    build_frame, parse_frame, build_exchange_payload, parse_exchange_payload,
    PROTOCOL_VERSION,
)
from tlv import build_tlv
from guard import Phase

# ======================================================================
# Test APDU fixtures - real Mastercard transaction data
# ======================================================================

PPSE_SELECT = bytes.fromhex("00A404000E325041592E5359532E444446303100")

PPSE_RESPONSE = bytes.fromhex(
    "6F3C840E325041592E5359532E4444463031"
    "A52ABF0C2761254F07A000000004101050104465626974204D6173746572636172648701019F0A0400010101"
) + SW_9000

AID_SELECT_MC = bytes.fromhex("00A4040007A000000004101000")

AID_RESPONSE_MC = bytes.fromhex(
    "6F558407A0000000041010A54A50104465626974204D6173746572636172649F12104465626974204D617374657263617264"
    "8701019F1101015F2D02656EBF0C169F4D020B0A9F6E07082600003030009F0A0400010101"
) + SW_9000

GPO_CMD = bytes.fromhex("80A8000002830000")

# GPO response with AIP=0x1980 (CV bit set) - relay should clear it to 0x1880
GPO_RESPONSE_77 = bytes.fromhex(
    "770E82021980940810010101200103009000"
)

# GPO response template 80
GPO_RESPONSE_80 = bytes.fromhex(
    "800A19800801010120010300"
) + SW_9000

READ_RECORD_CMD = bytes.fromhex("00B2011400")
READ_RECORD_2_CMD = bytes.fromhex("00B2021400")

# READ RECORD with CVM list (Online PIN) and non-zero IACs
READ_RECORD_RESPONSE = bytes.fromhex(
    "7081A89F420208265F25032409015F24032909305A0853545600000081225F3401009F0702FFC0"
    "9F080200028C279F02069F03069F1A0295055F2A029A039C019F37049F35019F45029F4C089F34039F21039F7C14"
    "8D0C910A8A0295059F37049F4C08"
    "8E10000000000000000000001F0002030000"  # CVM: Online PIN required
    "9F0D05B4508400009F0E05000000000"
    "09F0F05B470848000"
    "5F280208269F4A01825713535456000000812"
    "2D29092210768807252828F"
) + SW_9000

GAC1_CMD = bytes.fromhex(
    "80AE8000420000000250000000000000000100800080800109782607190078CCF5C822"
    "00000000000000000000000001025212000000000000000000000000000000000000000000"
)

# GAC1 response: ARQC (CID=0x80)
GAC1_RESPONSE_ARQC = bytes.fromhex(
    "77299F2701809F3602001A9F2608359AFDB396F58E289F10120110A00303A400000000FFFFFFFFFFFFFFFF"
) + SW_9000

# GAC1 response: TC (CID=0x40) - offline approved, no forge expected
GAC1_RESPONSE_TC = bytes.fromhex(
    "77299F2701409F3602001A9F2608AABBCCDD11223344"
    "9F10120110A00303A400000000FFFFFFFFFFFFFFFF"
) + SW_9000

# GAC1 response: AAC (CID=0x00) - offline declined
GAC1_RESPONSE_AAC = bytes.fromhex(
    "77299F2701009F3602001A9F2608DEADBEEFCAFEBABE"
    "9F10120110A00303A400000000FFFFFFFFFFFFFFFF"
) + SW_9000

GAC2_CMD = bytes.fromhex(
    "80AE4000420000000250000000000000000100800080800109782607190078CCF5C822"
    "00000000000000000000000001025212000000000000000000000000000000000000000000"
)

VERIFY_CMD = bytes.fromhex("0020008008243132333400000000")

EXT_AUTH_CMD = bytes.fromhex(
    "00820000083031323334353637"
)

# ======================================================================
# Mock peer - simulates emulator or reader
# ======================================================================

@dataclass
class APDUExchange:
    """Records one CAPDU->RAPDU exchange."""
    capdu_hex: str
    rapdu_hex: str
    sw: str
    direction: str
    timestamp: float

class MockPeer:
    """UDP peer that sends/receives relay frames."""

    def __init__(self, name: str, server_host: str, server_port: int):
        self.name = name
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.settimeout(3.0)
        self.server_addr = (server_host, server_port)
        self.sock.bind(("0.0.0.0", 0))
        self.local_addr = self.sock.getsockname()
        self.epoch = 0
        self.seq = 0
        self.exchanges: List[APDUExchange] = []

    def close(self):
        self.sock.close()

    def send_raw(self, sid: int, payload: bytes, seq: int = 0, epoch: int = 0) -> None:
        frame = build_frame(sid, payload, seq, epoch or self.epoch)
        self.sock.sendto(frame, self.server_addr)

    def recv_raw(self, timeout: float = 3.0) -> Optional[Tuple[int, int, int, bytes]]:
        self.sock.settimeout(timeout)
        try:
            data, _ = self.sock.recvfrom(8192)
            return parse_frame(data)
        except socket.timeout:
            return None

    def recv_until_sid(self, target_sid: int, timeout: float = 3.0) -> Optional[bytes]:
        result = self.recv_until_frame(target_sid, timeout)
        return result[2] if result else None

    def recv_until_frame(self, target_sid: int,
                         timeout: float = 3.0) -> Optional[Tuple[int, int, bytes]]:
        deadline = time.time() + timeout
        while time.time() < deadline:
            result = self.recv_raw(timeout=deadline - time.time())
            if result is None:
                return None
            sid, epoch, seq, payload = result
            if sid == target_sid:
                return epoch, seq, payload
        return None

    def recv_ctrl_matching(self, predicate, timeout: float = 3.0) -> Optional[str]:
        """Ignore asynchronous CTRL notifications until the expected reply arrives."""
        deadline = time.time() + timeout
        while time.time() < deadline:
            payload = self.recv_until_sid(SID_CTRL, timeout=deadline - time.time())
            if payload is None:
                return None
            text = payload.decode("utf-8", errors="replace")
            if predicate(text):
                return text
        return None

    def register(self, mode: str, client_id: Optional[str] = None) -> bool:
        reg_str = f"{mode} V{PROTOCOL_VERSION}"
        if client_id:
            reg_str += f" ID={client_id}"
        self.send_raw(SID_REGISTER, reg_str.encode("ascii"))
        deadline = time.time() + 3.0
        while time.time() < deadline:
            result = self.recv_raw(timeout=deadline - time.time())
            if result is None:
                return False
            sid, _, _, payload = result
            if sid == SID_ACK:
                return True
            if sid == SID_CTRL and payload.startswith(b"ERR "):
                return False
        return False

    def session_begin(self, token: str = "TEST") -> Optional[int]:
        cmd = f"SESSION_BEGIN {token}".encode("utf-8")
        self.send_raw(SID_CTRL, cmd)
        text = self.recv_ctrl_matching(
            lambda value: value.startswith("SESSION_ACK ") or value.startswith("ERR "),
            timeout=3.0,
        )
        if text is None:
            return None
        if text.startswith("SESSION_ACK"):
            parts = text.split()
            if len(parts) >= 3 and parts[2] == token.upper():
                self.epoch = int(parts[1])
                return self.epoch
        return None

    def send_capdu(self, apdu: bytes) -> Optional[bytes]:
        self.seq += 1
        self.send_raw(SID_CAPDU, apdu, seq=self.seq, epoch=self.epoch)
        # Collect response (may get ACK first, then need RAPDU from reader mock)
        resp = self.recv_until_sid(SID_RAPDU, timeout=5.0)
        if resp:
            rapdu = resp
            sw = rapdu[-2:].hex().upper() if len(rapdu) >= 2 else "??"
            self.exchanges.append(APDUExchange(
                capdu_hex=apdu.hex().upper(),
                rapdu_hex=rapdu.hex().upper(),
                sw=sw,
                direction=f"{self.name}>RELAY",
                timestamp=time.time(),
            ))
            return rapdu
        return None

    def send_rapdu(self, rapdu: bytes, exchange_id: int) -> None:
        self.send_raw(SID_RAPDU, rapdu, seq=exchange_id, epoch=self.epoch)

    def wait_for_capdu(self, timeout: float = 5.0) -> Optional[Tuple[int, bytes]]:
        frame = self.recv_until_frame(SID_CAPDU, timeout=timeout)
        if frame:
            _, exchange_id, apdu = frame
            return exchange_id, apdu
        return None

    def send_ctrl(self, command: str) -> Optional[str]:
        self.send_raw(SID_CTRL, command.encode("utf-8"))
        if command.upper() == "STATUS":
            return self.recv_ctrl_matching(lambda text: text.lstrip().startswith("{"))
        return self.recv_ctrl_matching(
            lambda text: text.startswith("OK ") or text.startswith("ERR ")
        )

    def get_status(self) -> Optional[dict]:
        text = self.send_ctrl("STATUS")
        if text:
            try:
                return json.loads(text)
            except json.JSONDecodeError:
                return None
        return None

# ======================================================================
# Test result tracking
# ======================================================================

@dataclass
class TestResult:
    name: str
    passed: bool
    reason: str
    duration: float
    phase_before: str = ""
    phase_after: str = ""

class TestReport:
    def __init__(self):
        self.results: List[TestResult] = []

    def add(self, result: TestResult) -> None:
        self.results.append(result)
        status = "PASS" if result.passed else "FAIL"
        print(f"  [{status}] {result.name}: {result.reason} "
              f"({result.duration:.3f}s) "
              f"[{result.phase_before} -> {result.phase_after}]")

    def summary(self) -> None:
        total = len(self.results)
        passed = sum(1 for r in self.results if r.passed)
        failed = total - passed
        print(f"\n{'='*60}")
        print(f"RESULTS: {passed}/{total} passed, {failed} failed")
        if failed:
            print(f"\nFAILED TESTS:")
            for r in self.results:
                if not r.passed:
                    print(f"  - {r.name}: {r.reason}")
        print(f"{'='*60}")

# ======================================================================
# Relay transaction driver - drives both peers through the server
# ======================================================================

class TransactionDriver:
    """Orchestrates emulator + reader mocks through the relay server."""

    def __init__(self, host: str = "127.0.0.1", port: int = 5566):
        self.host = host
        self.port = port
        self.emulator = MockPeer("EMU", host, port)
        self.reader = MockPeer("RDR", host, port)
        self.report = TestReport()

    def setup(self) -> bool:
        """Register both peers and open a session."""
        if not self.emulator.register("EMULATOR"):
            print("[SETUP FAIL] Emulator registration failed")
            return False
        if not self.reader.register("READER"):
            print("[SETUP FAIL] Reader registration failed")
            return False
        epoch = self.emulator.session_begin("HARNESS")
        if epoch is None:
            print("[SETUP FAIL] Session begin failed")
            return False
        self.reader.epoch = epoch
        # Signal card present
        self.emulator.send_ctrl("CARD_PRESENT")
        time.sleep(0.1)
        return True

    def teardown(self) -> None:
        self.emulator.close()
        self.reader.close()

    def relay_apdu(self, capdu: bytes, rapdu: bytes,
                   label: str = "") -> Optional[bytes]:
        """Send CAPDU from emulator, respond with RAPDU from reader,
        return the (possibly mutated) RAPDU that emulator receives."""
        # Emulator sends CAPDU
        self.emulator.seq += 1
        self.emulator.send_raw(SID_CAPDU, capdu,
                               seq=self.emulator.seq,
                               epoch=self.emulator.epoch)

        # Reader receives forwarded CAPDU
        result = self.reader.wait_for_capdu(timeout=3.0)
        if result is None:
            # Might be intercepted (VERIFY bypass / forge) - check emulator
            emu_resp = self.emulator.recv_until_sid(SID_RAPDU, timeout=2.0)
            if emu_resp:
                return emu_resp
            return None

        exchange_id, forwarded_capdu = result

        # Reader sends RAPDU back
        self.reader.send_rapdu(rapdu, exchange_id)

        # Emulator receives (possibly mutated) RAPDU
        emu_resp = self.emulator.recv_until_sid(SID_RAPDU, timeout=3.0)
        if emu_resp:
            received_rapdu = emu_resp
            sw = received_rapdu[-2:].hex().upper() if len(received_rapdu) >= 2 else "??"
            self.emulator.exchanges.append(APDUExchange(
                capdu_hex=capdu.hex().upper(),
                rapdu_hex=received_rapdu.hex().upper(),
                sw=sw,
                direction=f"EMU>RDR ({label})",
                timestamp=time.time(),
            ))
            return received_rapdu
        return None

    def get_guard_phase(self) -> str:
        status = self.emulator.get_status()
        if status and "guard_phase" in status:
            return status["guard_phase"].get("phase", "UNKNOWN")
        return "UNKNOWN"

# ======================================================================
# Test suites
# ======================================================================

class TestSuite:
    """Collection of test scenarios."""

    def __init__(self, driver: TransactionDriver):
        self.d = driver
        self.report = driver.report

    def _test(self, name: str, passed: bool, reason: str,
              t0: float, phase_before: str = "", phase_after: str = "") -> None:
        self.report.add(TestResult(
            name=name, passed=passed, reason=reason,
            duration=time.time() - t0,
            phase_before=phase_before, phase_after=phase_after,
        ))

    # ------------------------------------------------------------------
    # Suite 1: Happy path - full Mastercard transaction
    # ------------------------------------------------------------------

    def test_happy_path_mastercard(self) -> None:
        print("\n--- Suite 1: Happy Path (Mastercard) ---")

        # PPSE SELECT
        t0 = time.time()
        phase_before = self.d.get_guard_phase()
        rapdu = self.d.relay_apdu(PPSE_SELECT, PPSE_RESPONSE, "PPSE")
        phase_after = self.d.get_guard_phase()
        self._test("PPSE SELECT",
                   rapdu is not None and rapdu[-2:] == SW_9000,
                   f"SW={rapdu[-2:].hex() if rapdu else 'None'}",
                   t0, phase_before, phase_after)

        # AID SELECT
        t0 = time.time()
        phase_before = phase_after
        rapdu = self.d.relay_apdu(AID_SELECT_MC, AID_RESPONSE_MC, "AID")
        phase_after = self.d.get_guard_phase()
        self._test("AID SELECT",
                   rapdu is not None and rapdu[-2:] == SW_9000,
                   f"SW={rapdu[-2:].hex() if rapdu else 'None'}",
                   t0, phase_before, phase_after)

        # GPO - verify AIP mutation (0x19 -> 0x18)
        t0 = time.time()
        phase_before = phase_after
        rapdu = self.d.relay_apdu(GPO_CMD, GPO_RESPONSE_77, "GPO")
        phase_after = self.d.get_guard_phase()
        aip_mutated = False
        if rapdu:
            hex_str = rapdu.hex().upper()
            # Check that 1980 was changed to 1880
            aip_mutated = "1880" in hex_str and "1980" not in hex_str
        self._test("GPO AIP mutation",
                   rapdu is not None and aip_mutated,
                   f"AIP correctly mutated" if aip_mutated else "AIP NOT mutated",
                   t0, phase_before, phase_after)

        # READ RECORD - verify CVM + IAC mutation
        t0 = time.time()
        phase_before = phase_after
        rapdu = self.d.relay_apdu(READ_RECORD_CMD, READ_RECORD_RESPONSE, "RR")
        phase_after = self.d.get_guard_phase()
        cvm_ok = False
        iac_ok = False
        if rapdu:
            hex_str = rapdu.hex().upper()
            # CVM should contain 1F031E03 (No CVM)
            cvm_ok = "1F031E03" in hex_str
            # IAC-Default and IAC-Online should be zeroed
            iac_ok = "9F0D050000000000" in hex_str
        self._test("READ RECORD CVM mutation",
                   cvm_ok,
                   "CVM -> No CVM" if cvm_ok else "CVM NOT mutated",
                   t0, phase_before, phase_after)
        self._test("READ RECORD IAC mutation",
                   iac_ok,
                   "IAC zeroed" if iac_ok else "IAC NOT zeroed",
                   t0, phase_before, phase_after)

        # A second record must keep READ_RECORD_DONE active and remain mutable.
        t0 = time.time()
        phase_before = phase_after
        rapdu = self.d.relay_apdu(READ_RECORD_2_CMD, READ_RECORD_RESPONSE, "RR2")
        phase_after = self.d.get_guard_phase()
        second_record_mutated = bool(rapdu and b"\x1f\x03\x1e\x03" in rapdu)
        second_record_ok = bool(
            second_record_mutated
            and phase_before == Phase.READ_RECORD_DONE.name
            and phase_after == Phase.READ_RECORD_DONE.name
        )
        self._test("Multiple READ RECORD phase is sticky",
                   second_record_ok,
                   f"phase={phase_after}, mutation={'yes' if second_record_mutated else 'no'}",
                   t0, phase_before, phase_after)

        # A failed repeated record must preserve the established phase but must
        # not be mutated merely because READ_RECORD_DONE is sticky.
        t0 = time.time()
        phase_before = phase_after
        failed_record = READ_RECORD_RESPONSE[:-2] + bytes.fromhex("6A83")
        rapdu = self.d.relay_apdu(READ_RECORD_2_CMD, failed_record, "RR2-FAILED")
        phase_after = self.d.get_guard_phase()
        failed_record_ok = (
            rapdu == failed_record
            and phase_before == Phase.READ_RECORD_DONE.name
            and phase_after == Phase.READ_RECORD_DONE.name
        )
        self._test("Failed repeated READ RECORD is not mutated",
                   failed_record_ok,
                   f"unchanged={rapdu == failed_record}, phase={phase_after}",
                   t0, phase_before, phase_after)

        # GENERATE AC (1st) - should return ARQC, arm forge
        t0 = time.time()
        phase_before = phase_after
        rapdu = self.d.relay_apdu(GAC1_CMD, GAC1_RESPONSE_ARQC, "GAC1")
        phase_after = self.d.get_guard_phase()
        status = self.d.emulator.get_status()
        forge_armed = status.get("second_ae_pending", False) if status else False
        self._test("1st GAC -> ARQC cached",
                   rapdu is not None and forge_armed,
                   f"Forge armed={forge_armed}",
                   t0, phase_before, phase_after)

        # GENERATE AC (2nd) - should be INTERCEPTED by forge
        t0 = time.time()
        phase_before = phase_after
        rapdu = self.d.relay_apdu(GAC2_CMD, b"", "GAC2-FORGE")
        phase_after = self.d.get_guard_phase()
        forge_fired = False
        if rapdu and len(rapdu) >= 2:
            # Forged response should contain CID=0x40 (TC)
            hex_str = rapdu.hex().upper()
            forge_fired = "9F270140" in hex_str and rapdu[-2:] == SW_9000
        self._test("2nd GAC forge fires",
                   forge_fired,
                   "TC forged" if forge_fired else "Forge did NOT fire",
                   t0, phase_before, phase_after)

        t0 = time.time()
        post_forge = self.d.relay_apdu(
            bytes.fromhex("80CA9F1700"), bytes.fromhex("01019000"), "POST-FORGE-GET-DATA"
        )
        post_forge_phase = self.d.get_guard_phase()
        self._test("Forge clears pending exchange",
                   post_forge == bytes.fromhex("01019000"),
                   f"response={'received' if post_forge else 'missing'}, phase={post_forge_phase}",
                   t0, phase_after, post_forge_phase)

    # ------------------------------------------------------------------
    # Suite 2: VERIFY bypass
    # ------------------------------------------------------------------

    def test_verify_bypass(self) -> None:
        print("\n--- Suite 2: VERIFY Bypass ---")

        # Reset and run through to READ RECORD phase
        self.d.emulator.send_ctrl("SESSION_RESET")
        time.sleep(0.1)
        epoch = self.d.emulator.session_begin("VERIFY_TEST")
        if epoch:
            self.d.reader.epoch = epoch
        self.d.emulator.send_ctrl("CARD_PRESENT")
        time.sleep(0.1)

        self.d.relay_apdu(PPSE_SELECT, PPSE_RESPONSE, "PPSE")
        self.d.relay_apdu(AID_SELECT_MC, AID_RESPONSE_MC, "AID")
        self.d.relay_apdu(GPO_CMD, GPO_RESPONSE_77, "GPO")
        self.d.relay_apdu(READ_RECORD_CMD, READ_RECORD_RESPONSE, "RR")

        # VERIFY - should be intercepted, not forwarded to reader
        t0 = time.time()
        phase_before = self.d.get_guard_phase()

        self.d.emulator.seq += 1
        self.d.emulator.send_raw(SID_CAPDU, VERIFY_CMD,
                                 seq=self.d.emulator.seq,
                                 epoch=self.d.emulator.epoch)

        # Reader should NOT receive this (intercepted)
        reader_got = self.d.reader.wait_for_capdu(timeout=1.5)

        # Emulator should get forged 9000
        emu_resp = self.d.emulator.recv_until_sid(SID_RAPDU, timeout=2.0)
        phase_after = self.d.get_guard_phase()

        intercepted = reader_got is None
        sw_ok = False
        if emu_resp:
            rapdu = emu_resp
            sw_ok = rapdu == SW_9000

        self._test("VERIFY intercepted (not forwarded)",
                   intercepted,
                   "Reader did NOT receive VERIFY" if intercepted else "Reader received VERIFY (FAIL)",
                   t0, phase_before, phase_after)
        self._test("VERIFY bypass returns 9000",
                   sw_ok,
                   "SW=9000" if sw_ok else f"Unexpected response",
                   t0, phase_before, phase_after)

    def test_external_auth_then_second_gac(self) -> None:
        print("\n--- Suite 2b: EXTERNAL AUTHENTICATE before 2nd GAC ---")

        self.d.emulator.send_ctrl("SESSION_RESET")
        time.sleep(0.1)
        epoch = self.d.emulator.session_begin("EXT_AUTH_TEST")
        if epoch:
            self.d.reader.epoch = epoch
        self.d.emulator.send_ctrl("CARD_PRESENT")
        time.sleep(0.1)

        self.d.relay_apdu(PPSE_SELECT, PPSE_RESPONSE, "PPSE")
        self.d.relay_apdu(AID_SELECT_MC, AID_RESPONSE_MC, "AID")
        self.d.relay_apdu(GPO_CMD, GPO_RESPONSE_77, "GPO")
        self.d.relay_apdu(READ_RECORD_CMD, READ_RECORD_RESPONSE, "RR")
        self.d.relay_apdu(GAC1_CMD, GAC1_RESPONSE_ARQC, "GAC1")

        t0 = time.time()
        ext_response = self.d.relay_apdu(EXT_AUTH_CMD, SW_9000, "EXT-AUTH")
        phase_after_auth = self.d.get_guard_phase()
        forged = self.d.relay_apdu(GAC2_CMD, b"", "GAC2-AFTER-EXT-AUTH")
        phase_after_gac = self.d.get_guard_phase()
        passed = bool(
            ext_response == SW_9000
            and phase_after_auth == Phase.EXTERNAL_AUTH_DONE.name
            and forged
            and b"\x9f\x27\x01\x40" in forged
            and phase_after_gac == Phase.SECOND_GAC_FORGED.name
        )
        self._test("External auth preserves 2nd GAC forge path",
                   passed,
                   f"auth_phase={phase_after_auth}, final_phase={phase_after_gac}",
                   t0, Phase.ARQC_RECEIVED.name, phase_after_gac)

    # ------------------------------------------------------------------
    # Suite 3: Guard denial - out-of-order attacks
    # ------------------------------------------------------------------

    def test_guard_out_of_order(self) -> None:
        print("\n--- Suite 3: Guard Out-of-Order Denial ---")

        # Reset session
        self.d.emulator.send_ctrl("SESSION_RESET")
        time.sleep(0.1)
        epoch = self.d.emulator.session_begin("OOO_TEST")
        if epoch:
            self.d.reader.epoch = epoch
        self.d.emulator.send_ctrl("CARD_PRESENT")
        time.sleep(0.1)

        # Attack 1: Send GENERATE AC before PPSE/AID/GPO
        t0 = time.time()
        phase_before = self.d.get_guard_phase()
        rapdu = self.d.relay_apdu(GAC1_CMD, GAC1_RESPONSE_ARQC, "GAC-EARLY")
        phase_after = self.d.get_guard_phase()
        # Guard should block the mutation (but relay may still forward)
        # Check that forge was NOT armed
        status = self.d.emulator.get_status()
        forge_armed = status.get("second_ae_pending", False) if status else False
        self._test("GAC before GPO - forge NOT armed",
                   not forge_armed,
                   f"Forge armed={forge_armed} (should be False)",
                   t0, phase_before, phase_after)

        # Attack 2: Send 2nd GAC without 1st GAC ARQC
        self.d.emulator.send_ctrl("SESSION_RESET")
        time.sleep(0.1)
        epoch = self.d.emulator.session_begin("OOO_TEST2")
        if epoch:
            self.d.reader.epoch = epoch
        self.d.emulator.send_ctrl("CARD_PRESENT")
        time.sleep(0.1)

        self.d.relay_apdu(PPSE_SELECT, PPSE_RESPONSE, "PPSE")
        self.d.relay_apdu(AID_SELECT_MC, AID_RESPONSE_MC, "AID")
        self.d.relay_apdu(GPO_CMD, GPO_RESPONSE_77, "GPO")
        self.d.relay_apdu(READ_RECORD_CMD, READ_RECORD_RESPONSE, "RR")

        t0 = time.time()
        phase_before = self.d.get_guard_phase()
        # Skip 1st GAC, send 2nd GAC directly
        rapdu = self.d.relay_apdu(GAC2_CMD, b"", "GAC2-NO-ARQC")
        phase_after = self.d.get_guard_phase()
        # Without ARQC cached, forge should NOT fire
        forge_output = False
        if rapdu:
            forge_output = b"\x9F\x27\x01\x40" in rapdu  # CID=TC in response
        self._test("2nd GAC without ARQC - forge blocked",
                   not forge_output,
                   "Forge did NOT fire" if not forge_output else "Forge FIRED (BAD)",
                   t0, phase_before, phase_after)

    # ------------------------------------------------------------------
    # Suite 4: TC on 1st GAC - forge should NOT arm
    #hon
    def test_tc_no_forge(self) -> None:
        print("\n--- Suite 4: TC on 1st GAC - forge NOT armed ---")

        # Reset session
        self.d.emulator.send_ctrl("SESSION_RESET")
        time.sleep(0.1)
        epoch = self.d.emulator.session_begin("TC_TEST")
        if epoch:
            self.d.reader.epoch = epoch
        self.d.emulator.send_ctrl("CARD_PRESENT")
        time.sleep(0.1)

        self.d.relay_apdu(PPSE_SELECT, PPSE_RESPONSE, "PPSE")
        self.d.relay_apdu(AID_SELECT_MC, AID_RESPONSE_MC, "AID")
        self.d.relay_apdu(GPO_CMD, GPO_RESPONSE_77, "GPO")
        self.d.relay_apdu(READ_RECORD_CMD, READ_RECORD_RESPONSE, "RR")

        t0 = time.time()
        phase_before = self.d.get_guard_phase()
        # Send 1st GAC with TC response (CID=0x40)
        rapdu = self.d.relay_apdu(GAC1_CMD, GAC1_RESPONSE_TC, "GAC1-TC")
        phase_after = self.d.get_guard_phase()
        status = self.d.emulator.get_status()
        forge_armed = status.get("second_ae_pending", False) if status else False
        self._test("TC on 1st GAC - forge NOT armed",
                   not forge_armed,
                   f"Forge armed={forge_armed} (should be False)",
                   t0, phase_before, phase_after)

    # ------------------------------------------------------------------
    # Suite 5: AAC on 1st GAC - forge should NOT arm
    # ------------------------------------------------------------------

    def test_aac_no_forge(self) -> None:
        print("\n--- Suite 5: AAC on 1st GAC - forge NOT armed ---")

        self.d.emulator.send_ctrl("SESSION_RESET")
        time.sleep(0.1)
        epoch = self.d.emulator.session_begin("AAC_TEST")
        if epoch:
            self.d.reader.epoch = epoch
        self.d.emulator.send_ctrl("CARD_PRESENT")
        time.sleep(0.1)

        self.d.relay_apdu(PPSE_SELECT, PPSE_RESPONSE, "PPSE")
        self.d.relay_apdu(AID_SELECT_MC, AID_RESPONSE_MC, "AID")
        self.d.relay_apdu(GPO_CMD, GPO_RESPONSE_77, "GPO")
        self.d.relay_apdu(READ_RECORD_CMD, READ_RECORD_RESPONSE, "RR")

        t0 = time.time()
        phase_before = self.d.get_guard_phase()
        rapdu = self.d.relay_apdu(GAC1_CMD, GAC1_RESPONSE_AAC, "GAC1-AAC")
        phase_after = self.d.get_guard_phase()
        status = self.d.emulator.get_status()
        forge_armed = status.get("second_ae_pending", False) if status else False
        self._test("AAC on 1st GAC - forge NOT armed",
                   not forge_armed,
                   f"Forge armed={forge_armed} (should be False)",
                   t0, phase_before, phase_after)

    # ------------------------------------------------------------------
    # Suite 6: Guard toggle enforcement (disable forge, should not fire)
    # ------------------------------------------------------------------

    def test_forge_toggle_off(self) -> None:
        print("\n--- Suite 6: Forge toggle OFF - forge blocked ---")

        self.d.emulator.send_ctrl("SESSION_RESET")
        time.sleep(0.1)
        epoch = self.d.emulator.session_begin("TOGGLE_TEST")
        if epoch:
            self.d.reader.epoch = epoch
        self.d.emulator.send_ctrl("CARD_PRESENT")
        time.sleep(0.1)

        # Disable forge via CTRL
        resp = self.d.emulator.send_ctrl("ARPC_FORGE OFF")
        print(f"  Toggle response: {resp}")

        self.d.relay_apdu(PPSE_SELECT, PPSE_RESPONSE, "PPSE")
        self.d.relay_apdu(AID_SELECT_MC, AID_RESPONSE_MC, "AID")
        self.d.relay_apdu(GPO_CMD, GPO_RESPONSE_77, "GPO")
        self.d.relay_apdu(READ_RECORD_CMD, READ_RECORD_RESPONSE, "RR")
        self.d.relay_apdu(GAC1_CMD, GAC1_RESPONSE_ARQC, "GAC1-ARQC")

        t0 = time.time()
        phase_before = self.d.get_guard_phase()
        rapdu = self.d.relay_apdu(GAC2_CMD, b"", "GAC2-FORGE-OFF")
        phase_after = self.d.get_guard_phase()
        # With forge disabled, the relay should forward to reader
        # (but reader has no response, so emulator gets nothing or timeout)
        forge_fired = False
        if rapdu:
            forge_fired = b"\x9F\x27\x01\x40" in rapdu
        self._test("Forge disabled - no forge response",
                   not forge_fired,
                   "Forge did NOT fire" if not forge_fired else "Forge FIRED (BAD)",
                   t0, phase_before, phase_after)

        # Re-enable for other tests
        self.d.emulator.send_ctrl("ARPC_FORGE ON")

    # ------------------------------------------------------------------
    # Suite 7: Stress test - rapid session begins
    # ------------------------------------------------------------------

    def test_stress_session_begin(self, count: int = 50) -> None:
        print(f"\n--- Suite 7: Stress test - {count} rapid SESSION_BEGIN ---")

        success = 0
        failure = 0
        t0 = time.time()
        for i in range(count):
            token = f"STRESS{i}"
            epoch = self.d.emulator.session_begin(token)
            if epoch:
                success += 1
                self.d.reader.epoch = epoch
            else:
                failure += 1
            time.sleep(0.01)

        duration = time.time() - t0
        rate_limit_enforced = success > 0 and failure > 0
        self._test(f"Session begin rate limit ({count} rapid requests)",
                   rate_limit_enforced,
                   f"{success} accepted, {failure} rate-limited in {duration:.3f}s",
                   t0)

    # ------------------------------------------------------------------
    # Suite 8: Concurrent emulator/reader registration
    # ------------------------------------------------------------------

    def test_concurrent_registration(self) -> None:
        print("\n--- Suite 8: Concurrent registration stress ---")

        # Create extra peers that try to register simultaneously
        extra_peers = []
        for i in range(5):
            peer = MockPeer(f"EXTRA{i}", self.d.host, self.d.port)
            extra_peers.append(peer)

        t0 = time.time()
        # Each competing registration must be rejected while the slot is occupied.
        accepted = 0
        for peer in extra_peers:
            accepted += int(peer.register("READER"))

        # Verify identity, not merely that some reader occupies the slot.
        status = self.d.reader.get_status()
        reader_peer = status.get("reader_peer") if status else None
        original_persists = bool(
            reader_peer
            and reader_peer[1] == self.d.reader.local_addr[1]
            and accepted == 0
        )

        for peer in extra_peers:
            peer.close()

        self._test("Concurrent registration - original reader persists",
                   original_persists,
                   f"reader_peer={reader_peer}, competing_accepted={accepted}",
                   t0)

    # ------------------------------------------------------------------
    # Suite 9: Guard phase transition error handling
    # ------------------------------------------------------------------

    def test_guard_phase_errors(self) -> None:
        print("\n--- Suite 9: Guard phase transition error handling ---")

        # Reset
        self.d.emulator.send_ctrl("SESSION_RESET")
        time.sleep(0.1)
        epoch = self.d.emulator.session_begin("GUARD_ERR")
        if epoch:
            self.d.reader.epoch = epoch
        self.d.emulator.send_ctrl("CARD_PRESENT")
        time.sleep(0.1)

        # Send GPO without AID SELECT - guard should block mutation
        t0 = time.time()
        phase_before = self.d.get_guard_phase()
        rapdu = self.d.relay_apdu(GPO_CMD, GPO_RESPONSE_77, "GPO-NO-AID")
        phase_after = self.d.get_guard_phase()
        # Guard should prevent phase advance without proper AID selection
        phase_ok = phase_after == phase_before
        self._test("GPO without AID - guard blocks phase advance",
                   phase_ok,
                   f"Phase stayed at {phase_after}" if phase_ok else f"Phase jumped to {phase_after}",
                   t0, phase_before, phase_after)

    def test_udp_address_rebind(self) -> None:
        """A stable client ID may reclaim a role after its UDP port changes."""
        print("\n--- Suite 10: UDP address rebinding ---")
        first = MockPeer("REBIND1", self.d.host, self.d.port)
        rebound = MockPeer("REBIND2", self.d.host, self.d.port)
        stranger = MockPeer("STRANGER", self.d.host, self.d.port)
        t0 = time.time()
        # An identified client must first be able to migrate the currently
        # occupied legacy role left by an older APK.
        initial_ok = first.register("READER", "android-client")
        rebound_ok = rebound.register("READER", "android-client")
        stranger_rejected = not stranger.register("READER", "different-client")
        status = rebound.get_status()
        current = status.get("reader_peer") if status else None
        port_moved = bool(current and current[1] == rebound.local_addr[1])
        self._test("Stable client identity survives UDP port change",
                   initial_ok and rebound_ok and stranger_rejected and port_moved,
                   f"reader_peer={current}, unrelated_rejected={stranger_rejected}", t0)
        rebound.register("DEREGISTER")
        first.close()
        rebound.close()
        stranger.close()

    # ------------------------------------------------------------------
    # Run all suites
    # ------------------------------------------------------------------

    def run_all(self) -> None:
        self.test_happy_path_mastercard()
        self.test_verify_bypass()
        self.test_external_auth_then_second_gac()
        self.test_guard_out_of_order()
        self.test_tc_no_forge()
        self.test_aac_no_forge()
        self.test_forge_toggle_off()
        self.test_stress_session_begin(count=50)
        self.test_concurrent_registration()
        self.test_guard_phase_errors()
        self.test_udp_address_rebind()
        self.report.summary()

def main() -> None:
    parser = argparse.ArgumentParser(description="EMV Relay Test Harness")
    parser.add_argument("--port", type=int, default=5566, help="Relay server port")
    parser.add_argument("--stress", action="store_true", help="Run stress tests only")
    parser.add_argument("--verbose", action="store_true", help="Verbose output")
    args = parser.parse_args()

    print(f"[*] Connecting to relay on 127.0.0.1:{args.port}")
    driver = TransactionDriver(port=args.port)
    if not driver.setup():
        print("[!] Setup failed. Is the relay server running?")
        sys.exit(1)

    print("[*] Setup complete. Starting test suites...")
    suite = TestSuite(driver)
    suite.run_all()
    driver.teardown()
    print("[*] Harness finished.")

if __name__ == "__main__":
    main()
