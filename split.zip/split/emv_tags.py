"""EMV tag metadata and safe, human-readable value decoders."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Dict, Optional


@dataclass(frozen=True)
class TagInfo:
    name: str
    category: str = "EMV"
    decoder: Optional[Callable[[bytes], str]] = None


def _ascii(value: bytes) -> str:
    return value.decode("ascii", errors="replace").rstrip("\x00 ")


def _bcd(value: bytes) -> str:
    return value.hex().upper().rstrip("F")


def _integer(value: bytes) -> str:
    return str(int.from_bytes(value, "big"))


def _date(value: bytes) -> str:
    digits = value.hex().upper()
    return f"20{digits[0:2]}-{digits[2:4]}-{digits[4:6]}" if len(digits) == 6 else digits


def _track2(value: bytes) -> str:
    text = value.hex().upper().rstrip("F").replace("D", "=")
    pan, separator, rest = text.partition("=")
    if not separator:
        return text
    expiry = rest[:4]
    service = rest[4:7]
    return f"PAN={pan}, expiry={expiry}, service-code={service}, discretionary={rest[7:]}"


def _cid(value: bytes) -> str:
    if not value:
        return "empty"
    kind = {0x00: "AAC", 0x40: "TC", 0x80: "ARQC"}.get(value[0] & 0xC0, "RFU")
    return f"{kind}; advice={'yes' if value[0] & 0x08 else 'no'}"


def _hex(value: bytes) -> str:
    return value.hex().upper()


TAGS: Dict[str, TagInfo] = {
    "4F": TagInfo("Application Identifier (AID)", decoder=_hex),
    "50": TagInfo("Application Label", decoder=_ascii),
    "56": TagInfo("Track 1 Data"), "57": TagInfo("Track 2 Equivalent Data", decoder=_track2),
    "5A": TagInfo("Application PAN", decoder=_bcd),
    "5F20": TagInfo("Cardholder Name", decoder=_ascii),
    "5F24": TagInfo("Application Expiration Date", decoder=_date),
    "5F25": TagInfo("Application Effective Date", decoder=_date),
    "5F28": TagInfo("Issuer Country Code", decoder=_bcd),
    "5F2A": TagInfo("Transaction Currency Code", decoder=_bcd),
    "5F2D": TagInfo("Language Preference", decoder=_ascii),
    "5F30": TagInfo("Service Code", decoder=_bcd),
    "5F34": TagInfo("PAN Sequence Number", decoder=_integer),
    "61": TagInfo("Application Template", "Template"),
    "6F": TagInfo("File Control Information Template", "Template"),
    "70": TagInfo("READ RECORD Response Template", "Template"),
    "77": TagInfo("Response Message Template Format 2", "Template"),
    "80": TagInfo("Response Message Template Format 1", "Template"),
    "82": TagInfo("Application Interchange Profile (AIP)"),
    "83": TagInfo("Command Template"), "84": TagInfo("Dedicated File Name", decoder=_hex),
    "87": TagInfo("Application Priority Indicator", decoder=_integer),
    "8A": TagInfo("Authorization Response Code", decoder=_ascii),
    "8C": TagInfo("Card Risk Management Data Object List 1 (CDOL1)", "DOL"),
    "8D": TagInfo("Card Risk Management Data Object List 2 (CDOL2)", "DOL"),
    "8E": TagInfo("Cardholder Verification Method List"),
    "8F": TagInfo("Certification Authority Public Key Index", decoder=_integer),
    "90": TagInfo("Issuer Public Key Certificate", "Security"),
    "91": TagInfo("Issuer Authentication Data", "Security"),
    "92": TagInfo("Issuer Public Key Remainder", "Security"),
    "93": TagInfo("Signed Static Application Data", "Security"),
    "94": TagInfo("Application File Locator (AFL)"),
    "95": TagInfo("Terminal Verification Results (TVR)"),
    "9A": TagInfo("Transaction Date", decoder=_date), "9C": TagInfo("Transaction Type"),
    "9F02": TagInfo("Amount, Authorised"), "9F03": TagInfo("Amount, Other"),
    "9F07": TagInfo("Application Usage Control"), "9F08": TagInfo("Application Version Number"),
    "9F0A": TagInfo("Application Selection Registered Proprietary Data"),
    "9F0D": TagInfo("Issuer Action Code - Default"), "9F0E": TagInfo("Issuer Action Code - Denial"),
    "9F0F": TagInfo("Issuer Action Code - Online"), "9F10": TagInfo("Issuer Application Data"),
    "9F11": TagInfo("Issuer Code Table Index", decoder=_integer),
    "9F12": TagInfo("Application Preferred Name", decoder=_ascii),
    "9F19": TagInfo("Token Requestor ID"),
    "9F1A": TagInfo("Terminal Country Code", decoder=_bcd), "9F21": TagInfo("Transaction Time"),
    "9F24": TagInfo("Payment Account Reference"),
    "9F26": TagInfo("Application Cryptogram", "Security"), "9F27": TagInfo("Cryptogram Information Data", decoder=_cid),
    "9F32": TagInfo("Issuer Public Key Exponent", "Security"),
    "9F34": TagInfo("Cardholder Verification Method Results"),
    "9F35": TagInfo("Terminal Type"), "9F36": TagInfo("Application Transaction Counter", decoder=_integer),
    "9F37": TagInfo("Unpredictable Number"), "9F42": TagInfo("Application Currency Code", decoder=_bcd),
    "9F45": TagInfo("Data Authentication Code", "Security"), "9F46": TagInfo("ICC Public Key Certificate", "Security"),
    "9F47": TagInfo("ICC Public Key Exponent", "Security"), "9F48": TagInfo("ICC Public Key Remainder", "Security"),
    "9F49": TagInfo("Dynamic Data Authentication Data Object List (DDOL)", "DOL"),
    "9F4A": TagInfo("Static Data Authentication Tag List", "Tag List"),
    "9F4B": TagInfo("Signed Dynamic Application Data", "Security"),
    "9F4C": TagInfo("ICC Dynamic Number"), "9F4D": TagInfo("Log Entry"),
    "9F6C": TagInfo("Card Transaction Qualifiers (CTQ)"),
    "9F6E": TagInfo("Third Party Data"), "9F7C": TagInfo("Merchant Custom Data"),
    "A5": TagInfo("FCI Proprietary Template", "Template"),
    "BF0C": TagInfo("FCI Issuer Discretionary Data", "Template"),
}


def tag_info(tag: str) -> TagInfo:
    return TAGS.get(tag.upper(), TagInfo(f"Unknown tag {tag.upper()}", "Unknown"))


def describe_value(tag: str, value: bytes) -> Optional[str]:
    decoder = tag_info(tag).decoder
    if not decoder:
        return None
    try:
        return decoder(value)
    except (IndexError, ValueError):
        return "invalid encoded value"
