from __future__ import annotations

from pathlib import Path
from datetime import datetime, timezone
import json

from .model import RunResult


def markdown_report(result: RunResult, destination: Path) -> Path:
    counts = result.counts()
    lines = [
        f"# Validation Report: {result.name}", "",
        f"- Run ID: `{result.run_id}`",
        f"- Generated: {datetime.now(timezone.utc).isoformat()}",
        f"- Overall status: **{result.status.value}**",
        f"- Summary: {json.dumps(counts, sort_keys=True)}", "",
        "## Findings", "",
    ]
    for item in result.findings:
        lines.extend([
            f"### [{item.status.value}] {item.validator}: {item.summary}", "",
            f"- Duration: {item.duration_ms:.3f} ms",
            f"- Evidence: {item.evidence or '—'}",
            f"- Recommended correction: {item.recommendation or '—'}", "",
        ])
    lines.extend(["## Event Trace", "", "```jsonl"])
    lines.extend(json.dumps(event.as_dict(), sort_keys=True) for event in result.events)
    lines.append("```")
    destination.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return destination
